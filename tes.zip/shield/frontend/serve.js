/**
 * Frontend static file server
 * Serves HTML/CSS/JS files from ./public
 * Run on port 3000
 */
const http = require("http");
const fs = require("fs");
const path = require("path");

const HOST = "127.0.0.1";
const PORT = Number(process.env.FRONTEND_PORT || 3000);
const PUBLIC = path.join(__dirname, "public");

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".woff2": "font/woff2"
};

const server = http.createServer((req, res) => {
  let pathname = new URL(req.url, `http://${HOST}`).pathname;
  // SPA fallback
  if (!path.extname(pathname)) pathname = "/index.html";
  const filePath = path.resolve(PUBLIC, `.${pathname}`);
  if (!filePath.startsWith(PUBLIC)) { res.writeHead(403); res.end("Forbidden"); return; }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      // Try index.html fallback for SPA routes
      fs.readFile(path.join(PUBLIC, "index.html"), (e2, d2) => {
        if (e2) { res.writeHead(404); res.end("Not found"); return; }
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
        res.end(d2);
      });
      return;
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
    res.end(data);
  });
});

server.listen(PORT, HOST, () => {
  console.log(`\n🎨 AI Bug Bounty Frontend`);
  console.log(`   URL: http://${HOST}:${PORT}`);
  console.log(`   Backend API: http://127.0.0.1:4000\n`);
});
