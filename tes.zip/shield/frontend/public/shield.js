/* ═══════════════════════════════════════════════════════
   WebShield — Frontend (No AI, Maximum Bug Detection)
   ═══════════════════════════════════════════════════════ */

const API_HOST = window.location.hostname === "localhost" ? "127.0.0.1" : (window.location.hostname || "127.0.0.1");
const API = window.API_BASE_URL || `http://${API_HOST}:4000`;
const MAX_SCAN_TARGETS = 10;

let currentPage = "dashboard";
let _lastScan   = null;
let _allFindings = [];

/* ─── Loader ──────────────────────────────────────────── */
let _ls = 0;
function stepLoader() {
  const prog = document.getElementById("loaderProgress");
  const sub  = document.getElementById("loaderSub");
  _ls++;
  if (prog) prog.style.width = (_ls * 34) + "%";
  if (sub && _ls === 1) sub.textContent = "Menghubungkan ke backend...";
  if (sub && _ls === 2) sub.textContent = "Siap memindai kerentanan...";
  if (_ls < 3) setTimeout(stepLoader, 500);
  else setTimeout(() => document.getElementById("loader").classList.add("hide"), 350);
}
setTimeout(stepLoader, 250);

/* ─── Theme ───────────────────────────────────────────── */
document.documentElement.setAttribute("data-theme", localStorage.getItem("ws-theme") || "dark");
document.getElementById("themeToggle")?.addEventListener("click", () => {
  const next = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", next);
  localStorage.setItem("ws-theme", next);
});
document.getElementById("mobileMenuBtn")?.addEventListener("click", () => {
  document.getElementById("sidebar")?.classList.toggle("open");
});

/* ─── API ─────────────────────────────────────────────── */
async function apiFetch(path, opts = {}) {
  const res = await fetch(API + path, { headers: { "Content-Type": "application/json" }, ...opts });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request gagal.");
  return data;
}

async function checkBackend() {
  try {
    await apiFetch("/api/health");
    document.getElementById("statusDot").className  = "status-dot ok";
    document.getElementById("statusLabel").textContent = "Online";
  } catch {
    document.getElementById("statusDot").className  = "status-dot err";
    document.getElementById("statusLabel").textContent = "Offline";
  }
}
checkBackend();

/* ─── Utils ───────────────────────────────────────────── */
function esc(s) { return String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }
function jsA(v) { return esc(JSON.stringify(v)).replace(/'/g,"&#39;"); }
function parseScanTargets(value) {
  const targets = [];
  const seen = new Set();
  for (const part of String(value || "").split(/[\s,;]+/)) {
    const target = part.trim();
    if (!target) continue;
    const key = scanTargetKey(target);
    if (seen.has(key)) continue;
    seen.add(key);
    targets.push(target);
  }
  return targets;
}
function scanTargetKey(target) {
  try {
    const url = /^[a-z][a-z0-9+.-]*:\/\//i.test(target) ? new URL(target) : new URL(`https://${target}`);
    return `${url.hostname.toLowerCase()}:${url.port || ""}`;
  } catch {
    return target.replace(/^https?:\/\//i, "").split(/[/?#]/)[0].toLowerCase();
  }
}
function fmt(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("id-ID",{day:"2-digit",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"});
}
const SEV_COLOR = { critical:"#ef4444",high:"#f97316",medium:"#f59e0b",low:"#10b981",info:"#3b82f6" };
function sevColor(s) { return SEV_COLOR[(s||"info").toLowerCase()] || "#64748b"; }
function badge(s) {
  s = (s||"info").toLowerCase().replace(/\s+/g,"-");
  const L = {false_positive:"False+",in_progress:"In Progress",acknowledged:"Acknowledged"};
  return `<span class="badge badge-${s}">${L[s]||(s.charAt(0).toUpperCase()+s.slice(1))}</span>`;
}
function scoreClass(score) {
  if (score >= 85) return "#10b981";
  if (score >= 70) return "#6ee7b7";
  if (score >= 50) return "#f59e0b";
  if (score >= 30) return "#f97316";
  return "#ef4444";
}
function scoreLabelText(score) {
  if (score >= 85) return "Aman";
  if (score >= 70) return "Cukup Aman";
  if (score >= 50) return "Perlu Perhatian";
  if (score >= 30) return "Rentan";
  return "KRITIS";
}
function toast(msg, type="info") {
  const el = document.createElement("div");
  el.className = `toast toast-${type}`;
  el.textContent = msg;
  document.getElementById("toastContainer").appendChild(el);
  setTimeout(() => el.remove(), 3500);
}
function showModal(title, body) {
  document.getElementById("modalTitle").textContent = title;
  document.getElementById("modalBody").innerHTML = body;
  document.getElementById("modal").style.display = "grid";
}
function closeModal() { document.getElementById("modal").style.display = "none"; }
document.getElementById("modalClose")?.addEventListener("click", closeModal);
document.getElementById("modal")?.addEventListener("click", e => { if (e.target.id==="modal") closeModal(); });

/* ─── Navigation ──────────────────────────────────────── */
const PAGE_TITLES = {
  dashboard:"Dashboard", domains:"My Domains", scanner:"Scan Domain",
  vulnerabilities:"Vulnerabilities", "fix-guide":"Fix Guide",
  "code-scanner":"Code Scanner", "audit-log":"Audit Log", settings:"Settings"
};
document.querySelectorAll(".nav-item").forEach(item => {
  item.addEventListener("click", e => {
    e.preventDefault();
    navigateTo(item.dataset.page);
    document.getElementById("sidebar")?.classList.remove("open");
  });
});
async function navigateTo(page) {
  currentPage = page;
  document.querySelectorAll(".nav-item").forEach(i => i.classList.toggle("active", i.dataset.page === page));
  document.getElementById("topbarTitle").textContent = PAGE_TITLES[page] || page;
  const main = document.getElementById("mainContent");
  main.innerHTML = `<div class="page-loading">Memuat...</div>`;
  try {
    const fn = {dashboard, domains, scanner, vulnerabilities, fixGuide, codeScanner, auditLog, settings}[
      page.replace(/-([a-z])/g, (_,c) => c.toUpperCase())
    ];
    main.innerHTML = fn ? await fn() : `<div class="alert alert-warning">Halaman tidak ditemukan.</div>`;
    attachPageListeners(page);
    updateVulnBadge();
  } catch(e) {
    main.innerHTML = `<div class="alert alert-danger">Error: ${esc(e.message)}</div>`;
  }
}
async function updateVulnBadge() {
  try {
    const stats = await apiFetch("/api/stats");
    const n = (stats.findingsBySeverity?.critical||0) + (stats.findingsBySeverity?.high||0);
    const b = document.getElementById("vulnBadge");
    if (b) { b.textContent = n; b.style.display = n>0?"inline":"none"; }
  } catch {}
}

/* ══════════════════════════════════════════════════════
   DASHBOARD
══════════════════════════════════════════════════════ */
async function dashboard() {
  let s = {totalDomains:0,totalScans:0,totalOpenFindings:0,totalFixed:0,findingsBySeverity:{},avgSecurityScore:null,domainScores:[],recentScans:[],recentFindings:[],fixHistory:[]};
  try { s = await apiFetch("/api/stats"); } catch {}

  const sev = s.findingsBySeverity || {};
  const sevTotal = Math.max(1, Object.values(sev).reduce((a,b)=>a+b,0));
  const scoreNum = s.avgSecurityScore != null ? s.avgSecurityScore : "—";
  const scoreCol = s.avgSecurityScore != null ? scoreClass(s.avgSecurityScore) : "#64748b";

  const recentScans = (s.recentScans||[]).map(sc => `
    <tr>
      <td><span class="text-mono" style="color:var(--blue);font-size:12px">${esc(sc.hostname||sc.target)}</span></td>
      <td><span style="font-family:var(--font-display);font-weight:800;font-size:18px;color:${scoreClass(sc.score||0)}">${sc.score!=null?sc.score:"—"}</span></td>
      <td>${sc.criticalCount>0?`<span style="color:var(--red);font-weight:700">${sc.criticalCount}C</span> `:""}<span style="color:var(--text2)">${sc.findingsCount||0} total</span></td>
      <td class="td-muted">${fmt(sc.scannedAt)}</td>
      <td><button class="btn btn-ghost btn-sm" onclick="navigateTo('vulnerabilities')">Lihat</button></td>
    </tr>`).join("") || `<tr><td colspan="5" style="text-align:center;padding:20px;color:var(--text3)">Belum ada scan</td></tr>`;

  const recentFinds = (s.recentFindings||[]).map(f => `
    <tr>
      <td><span class="badge badge-${f.severity}">${(f.severity||"").toUpperCase()}</span></td>
      <td style="max-width:220px;font-size:12px">${esc((f.title||"").slice(0,55))}${(f.title||"").length>55?"…":""}</td>
      <td class="td-muted text-mono" style="font-size:11px">${esc(f.hostname||f.target||"—")}</td>
      <td><button class="btn btn-ghost btn-sm" onclick="openFindingModal(${jsA(f)})">Detail</button></td>
    </tr>`).join("") || `<tr><td colspan="4" style="text-align:center;padding:20px;color:var(--green)">🎉 Tidak ada temuan terbuka!</td></tr>`;

  return `
  <div class="page-header">
    <h1>Dashboard</h1>
    <p>Ringkasan keamanan semua website Anda</p>
  </div>
  ${s.totalDomains===0?`<div class="alert alert-info">👋 <strong>Mulai dari sini:</strong> <a href="#" onclick="navigateTo('domains')" style="color:var(--blue);font-weight:600">Daftarkan domain →</a> lalu scan untuk temukan celah keamanan.</div>`:""}
  <div class="stats-grid">
    <div class="stat-card" style="border-color:${scoreCol}20">
      <div class="stat-label">Avg Security Score</div>
      <div class="stat-value" style="color:${scoreCol};font-size:40px">${scoreNum}</div>
      <div class="stat-sub" style="color:${scoreCol}">${s.avgSecurityScore!=null?scoreLabelText(s.avgSecurityScore):"Belum discan"}</div>
    </div>
    <div class="stat-card"><div class="stat-label">Domain</div><div class="stat-value" style="color:var(--blue)">${s.totalDomains}</div><div class="stat-sub">${s.totalScans} scan dilakukan</div></div>
    <div class="stat-card" style="${(sev.critical||0)>0?'border-color:#7f1d1d':''}">
      <div class="stat-label">Critical</div>
      <div class="stat-value" style="color:var(--red)">${sev.critical||0}</div>
      <div class="stat-sub">Harus segera fix</div>
    </div>
    <div class="stat-card" style="${(sev.high||0)>0?'border-color:#7c2d12':''}">
      <div class="stat-label">High</div>
      <div class="stat-value" style="color:#f97316">${sev.high||0}</div>
      <div class="stat-sub">Prioritas tinggi</div>
    </div>
    <div class="stat-card"><div class="stat-label">Medium + Low</div><div class="stat-value" style="color:var(--amber)">${(sev.medium||0)+(sev.low||0)}</div><div class="stat-sub">Perlu diperhatikan</div></div>
    <div class="stat-card"><div class="stat-label">Sudah Diperbaiki</div><div class="stat-value" style="color:var(--green)">${s.totalFixed}</div><div class="stat-sub">Dari ${s.totalOpenFindings+s.totalFixed} total</div></div>
  </div>

  <div class="dash-grid">
    <div class="card">
      <div class="card-header"><h2>Sebaran Temuan</h2><span>${s.totalOpenFindings} terbuka</span></div>
      ${["critical","high","medium","low","info"].map(sv => `
        <div style="margin-bottom:10px">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
            <span class="badge badge-${sv}">${sv.toUpperCase()}</span>
            <span style="font-family:var(--font-mono);font-size:12px;font-weight:700;color:${sevColor(sv)}">${sev[sv]||0}</span>
          </div>
          <div class="progress-bar">
            <div class="progress-fill" style="width:${((sev[sv]||0)/sevTotal*100).toFixed(1)}%;background:${sevColor(sv)}"></div>
          </div>
        </div>`).join("")}
    </div>
    <div class="card">
      <div class="card-header"><h2>Score Per Domain</h2></div>
      ${(s.domainScores||[]).length ? s.domainScores.map(d => `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--border)">
          <div>
            <div style="font-family:var(--font-mono);font-size:12px;color:var(--text2)">${esc(d.label||d.domain)}</div>
            ${d.score!=null?`<div style="font-size:11px;color:${scoreClass(d.score)}">${scoreLabelText(d.score)}</div>`:""}
          </div>
          <div style="font-family:var(--font-display);font-size:28px;font-weight:800;color:${d.score!=null?scoreClass(d.score):"var(--text3)"}">${d.score!=null?d.score:"—"}</div>
        </div>`).join("")
      : `<p style="text-align:center;padding:20px;color:var(--text3)">Scan domain dulu</p>`}
    </div>
    <div class="card full">
      <div class="card-header"><h2>Temuan Terbaru (Open)</h2><a href="#" onclick="navigateTo('vulnerabilities')" class="btn btn-ghost btn-sm">Semua →</a></div>
      <div class="table-wrap"><table><thead><tr><th>Severity</th><th>Temuan</th><th>Domain</th><th></th></tr></thead><tbody>${recentFinds}</tbody></table></div>
    </div>
    <div class="card full">
      <div class="card-header"><h2>Riwayat Scan</h2><a href="#" onclick="navigateTo('scanner')" class="btn btn-primary btn-sm">+ Scan Baru</a></div>
      <div class="table-wrap"><table><thead><tr><th>Domain</th><th>Score</th><th>Temuan</th><th>Waktu</th><th></th></tr></thead><tbody>${recentScans}</tbody></table></div>
    </div>
  </div>`;
}

/* ══════════════════════════════════════════════════════
   MY DOMAINS
══════════════════════════════════════════════════════ */
async function domains() {
  const items = await apiFetch("/api/my-domains");
  const cards = items.length ? items.map(d => {
    const sc = d.lastScore;
    const col = sc!=null ? scoreClass(sc) : "#64748b";
    const hasCrit = (d.criticalFindings||0) > 0;
    return `
    <div class="domain-card" style="border-top:3px solid ${col}">
      <div class="domain-name">${esc(d.domain)}</div>
      ${d.label?`<div class="domain-label">${esc(d.label)}</div>`:`<div style="height:8px"></div>`}
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
        <span style="font-family:var(--font-display);font-size:40px;font-weight:800;color:${col}">${sc!=null?sc:"—"}</span>
        <div>
          <div style="font-size:13px;font-weight:600;color:${col}">${sc!=null?scoreLabelText(sc):"Belum discan"}</div>
          <div style="font-size:11px;color:var(--text3);font-family:var(--font-mono)">${d.lastScanAt?fmt(d.lastScanAt):"—"}</div>
        </div>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px;font-size:11px;font-family:var(--font-mono)">
        ${(d.criticalFindings||0)>0?`<span style="color:var(--red);font-weight:700">${d.criticalFindings} CRITICAL</span>`:""}
        ${(d.highFindings||0)>0?`<span style="color:#f97316;font-weight:700">${d.highFindings} HIGH</span>`:""}
        <span style="color:var(--text3)">${d.openFindings||0} open · ${d.totalScans||0} scan</span>
      </div>
      <div style="display:flex;gap:6px;flex-wrap:wrap">
        <button class="btn btn-primary btn-sm" onclick="quickScan('${esc(d.domain)}')">⚡ Scan</button>
        <button class="btn btn-ghost btn-sm" onclick="filterVulns('${esc(d.domain)}')">⚠ Temuan</button>
        <button class="btn btn-danger btn-sm" onclick="deleteDomain('${d.id}','${esc(d.domain)}')">✕</button>
      </div>
    </div>`;
  }).join("") : `<div class="empty-state" style="grid-column:1/-1"><div class="empty-icon">🌐</div><p>Belum ada domain. Daftarkan website Anda.</p></div>`;

  return `
  <div class="page-header"><h1>My Domains</h1><p>Daftarkan website untuk dipantau</p></div>
  <div class="card" style="margin-bottom:20px">
    <div class="card-header"><h2>Daftarkan Domain</h2></div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Domain *</label>
        <input class="form-input" id="d-domain" placeholder="example.com">
        <div class="form-hint">Tanpa http://. Gunakan *.example.com untuk semua subdomain.</div>
      </div>
      <div class="form-group">
        <label class="form-label">Label (opsional)</label>
        <input class="form-input" id="d-label" placeholder="Website Utama, Blog, API Server...">
      </div>
    </div>
    <button class="btn btn-primary" id="addDomainBtn">+ Daftarkan</button>
  </div>
  <div class="domain-grid">${cards}</div>`;
}

function quickScan(domain) {
  navigateTo("scanner");
  setTimeout(() => { const el = document.getElementById("scanTarget"); if(el){el.value=domain;el.focus();} }, 300);
}
function filterVulns(domain) {
  navigateTo("vulnerabilities");
  setTimeout(() => { const el = document.getElementById("domainFilter"); if(el){el.value=domain;el.dispatchEvent(new Event("change"));} }, 400);
}
async function deleteDomain(id, domain) {
  if (!confirm(`Hapus domain "${domain}"?`)) return;
  try { await apiFetch(`/api/my-domains/${id}`,{method:"DELETE"}); toast("Domain dihapus","info"); navigateTo("domains"); }
  catch(e) { toast(e.message,"error"); }
}

/* ══════════════════════════════════════════════════════
   SCANNER
══════════════════════════════════════════════════════ */
async function scanner() {
  const myDomains = await apiFetch("/api/my-domains");
  const registeredDomains = myDomains.map(d => `<code>${esc(d.domain)}</code>`).join(", ");

  return `
  <div class="page-header"><h1>Scan Domain</h1><p>Passive scan: temukan celah keamanan di website Anda, setiap temuan dilengkapi lokasi spesifik</p></div>
  ${myDomains.length===0?`<div class="alert alert-warning">⚠️ Belum ada domain. <a href="#" onclick="navigateTo('domains')" style="color:var(--amber);font-weight:600">Daftarkan dulu →</a></div>`:""}
  <div class="card">
    <div class="form-group">
      <label class="form-label">Target Domain</label>
      <textarea class="form-textarea" id="scanTarget" placeholder="example.com&#10;api.example.com&#10;https://app.example.com" style="font-family:var(--font-mono);font-size:15px;min-height:110px"></textarea>
      <div class="form-hint">Bisa banyak target: pisahkan dengan Enter, koma, titik koma, atau spasi. Maksimal ${MAX_SCAN_TARGETS} target per scan.</div>
      ${registeredDomains ? `<div class="form-hint">Domain terdaftar: ${registeredDomains}</div>` : ""}
      <div class="form-hint">Hanya domain yang terdaftar di My Domains yang bisa discan.</div>
    </div>

    <div class="alert alert-info" style="margin-bottom:14px">
      ℹ️ <strong>305 paths dicek + 15 kategori scan</strong>: DNS Security, TLS/SSL, 30+ Security Headers, CORS, Cookies per-flag, Open Redirects, Sensitive Path Exposure (kritik: .env, .git, backup SQL, admin panels, DB UIs, CI/CD, cloud configs), JS Source Analysis, API Discovery, Version Disclosure, Subdomain Takeover, Cache Surface, HTTP Methods, GraphQL, JWT Analysis.
    </div>

    <button class="btn btn-primary btn-lg" id="runScanBtn">⚡ Mulai Scan</button>
  </div>
  <div id="scanResult"></div>`;
}

/* ══════════════════════════════════════════════════════
   VULNERABILITIES
══════════════════════════════════════════════════════ */
async function vulnerabilities() {
  const items = await apiFetch("/api/findings");
  _allFindings = items.slice().reverse();

  const domainSet = [...new Set(items.map(f => f.hostname||f.target).filter(Boolean))];
  const domOpts = domainSet.map(d => `<option value="${esc(d)}">${esc(d)}</option>`).join("");

  const catSet = [...new Set(items.map(f=>f.category).filter(Boolean))].sort();
  const catOpts = catSet.map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join("");

  return `
  <div class="page-header">
    <h1>Vulnerabilities</h1>
    <p>${items.length} temuan total — klik temuan untuk lihat lokasi bug yang spesifik</p>
  </div>

  <div class="card" style="padding:12px;margin-bottom:14px">
    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
      <select class="form-select" id="severityFilter" style="width:auto">
        <option value="all">Semua Severity</option>
        ${["critical","high","medium","low","info"].map(s=>`<option value="${s}">${s.toUpperCase()}</option>`).join("")}
      </select>
      <select class="form-select" id="statusFilter" style="width:auto">
        <option value="all">Semua Status</option>
        ${["open","in_progress","acknowledged","fixed","false_positive"].map(s=>`<option value="${s}">${s}</option>`).join("")}
      </select>
      <select class="form-select" id="domainFilter" style="width:auto">
        <option value="">Semua Domain</option>${domOpts}
      </select>
      <select class="form-select" id="catFilter" style="width:auto">
        <option value="">Semua Kategori</option>${catOpts}
      </select>
      <button class="btn btn-ghost btn-sm" id="clearFilters">Reset</button>
      <span style="margin-left:auto;font-size:11px;color:var(--text3);font-family:var(--font-mono)" id="filterCount">${items.length} findings</span>
    </div>
  </div>

  <div id="findingsContainer">${renderFindings(_allFindings)}</div>`;
}

function renderFindings(items) {
  if (!items.length) return `<div class="empty-state"><div class="empty-icon">🎉</div><p>Tidak ada temuan ditemukan!</p></div>`;
  return items.map(f => renderFindingCard(f)).join("");
}

function renderFindingCard(f) {
  const sev = (f.severity||"info").toLowerCase();
  const loc = buildLocation(f);
  const fixRec = f.fixRecommendations;

  return `
  <div class="finding-card sev-${sev}" data-sev="${sev}" data-status="${f.status||'open'}" data-domain="${esc(f.hostname||f.target||'')}" data-cat="${esc(f.category||'')}">
    <div class="finding-left">
      <div class="finding-sev-box ${sev}">${sev.toUpperCase()}</div>
      ${badge(f.status||"open")}
    </div>
    <div class="finding-body">
      <div class="finding-title">${esc(f.title)}</div>
      ${loc ? `<div class="bug-location">📍 <strong>Lokasi Bug:</strong> ${loc}</div>` : ""}
      <div class="finding-meta-row">
        <span class="cat-tag">${esc(f.category||"General")}</span>
        <span class="td-muted text-mono" style="font-size:10px">${fmt(f.createdAt)}</span>
      </div>
      ${f.evidence ? `<div class="evidence-box">${esc(f.evidence.slice(0,300))}</div>` : ""}
      ${f.recommendation ? `<div class="rec-box">💡 ${esc(f.recommendation.slice(0,200))}</div>` : ""}
      ${fixRec ? `<div class="fix-preview"><span class="fix-icon-sm">${fixRec.icon}</span><strong>${esc(fixRec.title)}</strong>: ${esc(fixRec.fixes[0]||"")}${fixRec.fixes.length>1?` <span style="color:var(--text3)">+${fixRec.fixes.length-1} langkah lagi</span>`:""}</div>` : ""}
      <div class="finding-actions">
        <button class="btn btn-primary btn-sm" onclick="openFindingModal(${jsA(f)})">🔍 Detail Lengkap</button>
        <button class="btn btn-success btn-sm" onclick="updateFinding('${f.id}','fixed')">✅ Fixed</button>
        <select class="form-select" style="padding:4px 8px;font-size:11px;width:auto" onchange="updateFinding('${f.id}',this.value);this.value=''">
          <option value="">Ubah Status...</option>
          <option value="in_progress">In Progress</option>
          <option value="acknowledged">Acknowledged</option>
          <option value="false_positive">False Positive</option>
          <option value="open">Reopen</option>
        </select>
      </div>
    </div>
  </div>`;
}

function buildLocation(f) {
  const parts = [];
  const base = f.hostname ? `https://${f.hostname}` : "";

  // Specific path-based location
  if (f.evidence) {
    const pathMatch = f.evidence.match(/GET\s+([^\s→]+)/);
    const urlMatch  = f.evidence.match(/https?:\/\/[^\s"',]+/);
    if (pathMatch && base) parts.push(`<code>${base}${pathMatch[1]}</code>`);
    else if (urlMatch) parts.push(`<code>${urlMatch[0]}</code>`);
  }

  // Header-based
  if (/security header|header.*tidak|HSTS|CSP|X-Frame|X-Content|Referrer|Permission/i.test(f.title)) {
    const headerMatch = f.evidence?.match(/header\s+([a-z-]+)\s+tidak/i) || f.evidence?.match(/^([a-z-]+)$/i);
    if (headerMatch) parts.push(`Header: <code>${headerMatch[1]}</code>`);
    if (base && !parts.length) parts.push(`<code>${base}/</code> — response headers`);
  }

  // Cookie-based
  if (/cookie/i.test(f.category||f.title)) {
    const cookieName = f.evidence?.match(/^([a-zA-Z0-9_.-]+)/)?.[1];
    if (cookieName) parts.push(`Cookie: <code>${cookieName}</code>`);
  }

  // DNS/Email
  if (/dns|spf|dmarc|caa|email|mail/i.test(f.category||f.title)) {
    parts.push(`DNS: <code>${f.hostname||""}</code>`);
  }

  // TLS/SSL
  if (/tls|ssl|cert|https/i.test(f.category||f.title)) {
    parts.push(`<code>${base||f.hostname||""}:443</code>`);
  }

  // JS file
  if (f.source && /\.js/.test(f.source)) {
    parts.push(`JS File: <code>${f.source}</code>`);
  }

  // Evidence has path
  if (!parts.length && f.evidence && base) {
    parts.push(`<code>${base}/</code>`);
  }

  return parts.join(" · ") || "";
}

function openFindingModal(f) {
  const loc = buildLocation(f);
  const fixRec = f.fixRecommendations;

  // Build hunting checklist
  const checklist = f.huntingChecklist || [];

  showModal(`[${(f.severity||"").toUpperCase()}] ${f.title}`, `
    <div style="margin-bottom:14px;display:flex;gap:8px;flex-wrap:wrap">
      ${badge(f.severity)} ${badge(f.status||"open")}
      <span class="badge badge-info">${esc(f.category||"General")}</span>
    </div>

    ${loc ? `
    <div class="detail-block" style="border-color:var(--blue)">
      <div class="detail-label" style="color:var(--blue)">📍 Lokasi Bug</div>
      <div style="font-size:13px;line-height:1.7">${loc}</div>
      <div style="font-size:11px;color:var(--text3);margin-top:4px">Domain: ${esc(f.hostname||f.target||"—")}</div>
    </div>` : ""}

    ${f.evidence ? `
    <div class="detail-block">
      <div class="detail-label">📋 Evidence</div>
      <div class="evidence-box" style="max-height:none">${esc(f.evidence)}</div>
    </div>` : ""}

    ${f.recommendation ? `
    <div class="detail-block" style="border-color:var(--amber)">
      <div class="detail-label" style="color:var(--amber)">⚡ Cara Fix</div>
      <div style="font-size:13px;color:var(--text2);line-height:1.7">${esc(f.recommendation)}</div>
    </div>` : ""}

    ${fixRec ? `
    <div class="detail-block" style="border-color:var(--green)">
      <div class="detail-label" style="color:var(--green)">${fixRec.icon} ${esc(fixRec.title)} — Langkah Fix</div>
      ${fixRec.fixes.map((fix,i) => `
        <div class="fix-step">
          <span style="color:var(--blue);font-family:var(--font-mono);font-weight:700;margin-right:8px">${i+1}.</span>
          <span style="font-size:12.5px;color:var(--text2)">${esc(fix).replace(/`([^`]+)`/g,"<code>$1</code>")}</span>
        </div>`).join("")}
    </div>` : ""}

    ${checklist.length ? `
    <div class="detail-block" style="border-color:#8b5cf6">
      <div class="detail-label" style="color:#8b5cf6">🔎 Verifikasi Manual</div>
      ${checklist.map(c => `<div style="font-size:12px;color:var(--text2);padding:4px 0;border-bottom:1px solid var(--border)">→ ${esc(c)}</div>`).join("")}
    </div>` : ""}

    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px">
      <button class="btn btn-success btn-sm" onclick="updateFinding('${f.id}','fixed');closeModal()">✅ Tandai Fixed</button>
      <button class="btn btn-ghost btn-sm" onclick="copyDetail(${jsA(f)})">📋 Copy Detail</button>
    </div>
  `);
}

function copyDetail(f) {
  const text = `[${(f.severity||"").toUpperCase()}] ${f.title}\nLokasi: ${f.hostname||f.target}\nEvidence: ${f.evidence||"—"}\nFix: ${f.recommendation||"—"}`;
  navigator.clipboard.writeText(text).then(()=>toast("Copied!","success")).catch(()=>toast("Gagal","error"));
}

async function updateFinding(id, status) {
  try {
    await apiFetch(`/api/findings/${id}`,{method:"PUT",body:JSON.stringify({status})});
    toast(`Status → ${status}`,"success");
    navigateTo("vulnerabilities");
  } catch(e) { toast(e.message,"error"); }
}

/* ══════════════════════════════════════════════════════
   FIX GUIDE
══════════════════════════════════════════════════════ */
async function fixGuide() {
  const cats = await apiFetch("/api/fix-categories");
  return `
  <div class="page-header"><h1>Fix Guide</h1><p>Panduan perbaikan per kategori kerentanan — tanpa AI, langsung dari database best practices</p></div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;margin-bottom:24px">
    ${cats.map(c => `
    <div class="fix-category-card" onclick="loadFixCat('${c.key}')">
      <div class="fix-icon">${c.icon}</div>
      <div class="fix-title">${esc(c.title)}</div>
      <div class="fix-count">${c.fixCount} langkah</div>
    </div>`).join("")}
  </div>
  <div id="fixCatDetail"></div>`;
}

async function loadFixCat(key) {
  const el = document.getElementById("fixCatDetail");
  el.innerHTML = `<div class="card"><div style="padding:20px;text-align:center;color:var(--text3)">Memuat...</div></div>`;
  try {
    const cat = await apiFetch(`/api/fix-categories/${key}`);
    el.innerHTML = `
    <div class="card">
      <div class="card-header"><h2>${cat.icon} ${esc(cat.title)}</h2><button class="btn btn-ghost btn-sm" onclick="document.getElementById('fixCatDetail').innerHTML=''">✕</button></div>
      ${cat.fixes.map((fix,i) => `
        <div class="fix-step">
          <span style="color:var(--blue);font-family:var(--font-mono);font-weight:700;margin-right:8px">${i+1}.</span>
          ${esc(fix).replace(/`([^`]+)`/g,"<code>$1</code>")}
        </div>`).join("")}
    </div>`;
    el.scrollIntoView({behavior:"smooth",block:"start"});
  } catch(e) { el.innerHTML = `<div class="alert alert-danger">${esc(e.message)}</div>`; }
}

/* ══════════════════════════════════════════════════════
   CODE SCANNER
══════════════════════════════════════════════════════ */
async function codeScanner() {
  return `
  <div class="page-header"><h1>Code Scanner</h1><p>Scan kode website Anda — deteksi SQL injection, XSS, hardcoded secrets, path traversal, dan lebih banyak lagi</p></div>
  <div class="card">
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Nama File</label>
        <input class="form-input" id="cs-fn" placeholder="app.js, routes/auth.php, models/user.py">
      </div>
      <div class="form-group">
        <label class="form-label">Framework</label>
        <input class="form-input" id="cs-fw" placeholder="Node.js, Laravel, Django, Rails">
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Paste Kode</label>
      <textarea class="form-textarea code-area" id="cs-code" style="min-height:300px;font-size:12.5px" placeholder="// Paste kode Anda di sini...&#10;// Scanner akan cari: SQL injection, XSS output, hardcoded secrets,&#10;// path traversal, file upload vuln, eval(), unsafe deserialize, dll."></textarea>
    </div>
    <div style="display:flex;gap:8px">
      <button class="btn btn-primary" id="runCodeScanBtn">🔍 Scan Kode</button>
      <button class="btn btn-ghost" id="projectScanBtn">📁 Scan Project</button>
    </div>
  </div>
  <div id="codeScanResult"></div>`;
}

/* ══════════════════════════════════════════════════════
   AUDIT LOG
══════════════════════════════════════════════════════ */
async function auditLog() {
  const logs = await apiFetch("/api/audit-logs");
  const rows = logs.map(l => `
    <tr>
      <td class="td-muted text-mono" style="font-size:11px">${fmt(l.timestamp)}</td>
      <td><span class="badge badge-info">${esc(l.action)}</span></td>
      <td class="td-muted" style="font-size:12px">${esc(l.detail)}</td>
    </tr>`).join("") || `<tr><td colspan="3" style="text-align:center;padding:20px;color:var(--text3)">Belum ada log</td></tr>`;
  return `
  <div class="page-header"><h1>Audit Log</h1><p>Semua aktivitas scan tercatat</p></div>
  <div class="card"><div class="table-wrap"><table><thead><tr><th>Waktu</th><th>Aksi</th><th>Detail</th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
}

/* ══════════════════════════════════════════════════════
   SETTINGS
══════════════════════════════════════════════════════ */
async function settings() {
  const res = await apiFetch("/api/settings");
  const providers = ["openai","anthropic","gemini","groq","openrouter","local"];
  const cfg = res.ai?.configured || {};
  const provider = res.settings?.ai_provider || "openai";
  const model = res.settings?.ai_model || "";
  return `
  <div class="page-header"><h1>Settings</h1></div>
  <div class="alert alert-info">🔒 API key dibaca dari backend .env saja. Isi di <code style="font-family:var(--font-mono);background:var(--panel2);padding:1px 5px">backend/.env</code></div>
  <div class="card">
    <div class="card-header"><h2>AI Provider (opsional — hanya untuk Fix Guide tambahan)</h2></div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Provider</label>
        <select class="form-select" id="set-provider">
          ${providers.map(p=>`<option value="${p}" ${provider===p?"selected":""}>${p}</option>`).join("")}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Model</label>
        <input class="form-input" id="set-model" value="${esc(model)}" placeholder="gpt-4o-mini">
      </div>
    </div>
    <button class="btn btn-primary" id="saveSettingsBtn">Simpan</button>
  </div>
  <div class="card">
    <div class="card-header"><h2>Status API Keys</h2></div>
    ${providers.map(p=>`
    <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)">
      <strong style="font-family:var(--font-mono);font-size:12px">${p}</strong>
      <span class="badge ${cfg[p]?"badge-low":"badge-open"}">${cfg[p]?"✓ OK":"✗ Missing"}</span>
    </div>`).join("")}
  </div>`;
}

/* ══════════════════════════════════════════════════════
   RENDER SCAN RESULT
══════════════════════════════════════════════════════ */
function openBatchScanResult(index) {
  const entry = _lastScan?.results?.[index];
  if (entry?.ok && entry.result) renderScanResult(entry.result);
}

function renderBatchScanResult(data) {
  _lastScan = data;
  const results = data.results || [];
  const okRows = results.filter(r => r.ok);
  const totalFindings = okRows.reduce((sum, r) => sum + Number(r.findingsCount || 0), 0);
  const avgScore = okRows.length
    ? Math.round(okRows.reduce((sum, r) => sum + Number(r.score || 0), 0) / okRows.length)
    : 0;
  const col = scoreClass(avgScore);
  const deg = Math.round(avgScore / 100 * 360);

  const cards = results.map((row, index) => {
    if (!row.ok) {
      return `<div class="alert alert-danger" style="margin-top:12px"><strong>${esc(row.target)}</strong><br>${esc(row.error || "Scan gagal.")}</div>`;
    }

    const result = row.result || {};
    const findings = result.analysis?.findings || [];
    const groups = { critical:0, high:0, medium:0, low:0, info:0 };
    for (const f of findings) {
      const sev = (f.severity || "info").toLowerCase();
      groups[sev] = (groups[sev] || 0) + 1;
    }
    const topFindings = findings.slice(0, 8)
      .map(f => renderScanFindingCard(f, result.target?.hostname || row.hostname))
      .join("");
    const hiddenCount = Math.max(0, findings.length - 8);

    return `
      <div class="card" style="margin-top:16px">
        <div class="card-header">
          <h2 style="font-family:var(--font-display)">${esc(row.hostname || row.target)}</h2>
          <span style="font-size:12px;color:${scoreClass(row.score || 0)};font-family:var(--font-mono);font-weight:700">Score ${row.score ?? "-"}/100</span>
        </div>
        <div class="scan-stats-row">
          <div class="scan-stat"><div class="scan-stat-num" style="color:${scoreClass(row.score || 0)}">${row.score ?? "-"}</div><div class="scan-stat-label">Score</div></div>
          <div class="scan-stat"><div class="scan-stat-num" style="color:var(--amber)">${findings.length}</div><div class="scan-stat-label">Temuan</div></div>
          ${Object.entries(groups).filter(([,v]) => v > 0).map(([sev, count]) => `
            <div class="scan-stat"><div class="scan-stat-num" style="color:${sevColor(sev)}">${count}</div><div class="scan-stat-label">${sev}</div></div>
          `).join("")}
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin:10px 0 12px">
          <button class="btn btn-primary btn-sm" onclick="openBatchScanResult(${index})">Buka detail scan</button>
          <button class="btn btn-ghost btn-sm" onclick="navigateTo('vulnerabilities')">Lihat di Vulnerabilities</button>
        </div>
        ${findings.length
          ? `${topFindings}${hiddenCount ? `<div class="form-hint">+${hiddenCount} temuan lagi. Buka detail scan atau halaman Vulnerabilities untuk melihat semuanya.</div>` : ""}`
          : `<div class="alert alert-success">Tidak ada temuan otomatis untuk target ini.</div>`}
      </div>`;
  }).join("");

  document.getElementById("scanResult").innerHTML = `
    <div class="scan-summary-new">
      <div class="scan-score-col">
        <div class="scan-score-ring" style="background:radial-gradient(circle,var(--panel) 60%,transparent 61%),conic-gradient(${col} ${deg}deg,var(--border) 0deg)">
          <div>
            <div style="font-family:var(--font-display);font-size:36px;font-weight:800;color:${col};line-height:1">${avgScore}</div>
            <div style="font-size:11px;color:${col};text-align:center">avg</div>
          </div>
        </div>
      </div>
      <div class="scan-info-col">
        <h2 style="font-family:var(--font-display);font-size:20px;font-weight:800;margin-bottom:6px">Batch Scan Selesai</h2>
        <div style="font-size:12px;color:var(--text3);margin-bottom:10px">${data.successCount || 0} sukses, ${data.failureCount || 0} gagal dari ${data.total || results.length} target</div>
        <div class="scan-sev-grid">
          <div class="scan-sev-stat"><div style="font-family:var(--font-display);font-size:22px;font-weight:800;color:var(--green)">${okRows.length}</div><div style="font-size:10px;font-family:var(--font-mono);text-transform:uppercase;color:var(--green)">sukses</div></div>
          <div class="scan-sev-stat"><div style="font-family:var(--font-display);font-size:22px;font-weight:800;color:var(--red)">${data.failureCount || 0}</div><div style="font-size:10px;font-family:var(--font-mono);text-transform:uppercase;color:var(--red)">gagal</div></div>
          <div class="scan-sev-stat"><div style="font-family:var(--font-display);font-size:22px;font-weight:800;color:var(--amber)">${totalFindings}</div><div style="font-size:10px;font-family:var(--font-mono);text-transform:uppercase;color:var(--amber)">temuan</div></div>
        </div>
      </div>
    </div>
    ${cards}`;
}

function renderScanResult(data) {
  _lastScan = data;
  const findings = data.analysis?.findings || [];
  const score = data.analysis?.score ?? 0;
  const col = scoreClass(score);
  const deg = Math.round(score / 100 * 360);

  // Group by severity
  const groups = { critical:[], high:[], medium:[], low:[], info:[] };
  for (const f of findings) groups[f.severity]?.push(f);

  const sevCounts = Object.fromEntries(Object.entries(groups).map(([k,v])=>[k,v.length]));
  const frameworks = (data.refs?.frameworks||[]).map(fw =>
    `<span class="fw-tag">${esc(fw)}</span>`).join("");

  // Build finding cards by severity order
  const findingHTML = ["critical","high","medium","low","info"].flatMap(sev =>
    groups[sev].map(f => renderScanFindingCard(f, data.target?.hostname))
  ).join("");

  document.getElementById("scanResult").innerHTML = `
    <div class="scan-summary-new">
      <div class="scan-score-col">
        <div class="scan-score-ring" style="background:radial-gradient(circle,var(--panel) 60%,transparent 61%),conic-gradient(${col} ${deg}deg,var(--border) 0deg)">
          <div>
            <div style="font-family:var(--font-display);font-size:36px;font-weight:800;color:${col};line-height:1">${score}</div>
            <div style="font-size:11px;color:${col};text-align:center">/100</div>
          </div>
        </div>
        <div style="text-align:center;margin-top:8px">
          <div style="font-weight:700;color:${col}">${scoreLabelText(score)}</div>
          <div style="font-size:11px;color:var(--text3);font-family:var(--font-mono)">${findings.length} temuan</div>
        </div>
      </div>
      <div class="scan-info-col">
        <h2 style="font-family:var(--font-display);font-size:20px;font-weight:800;margin-bottom:6px">${esc(data.target?.hostname||"")}</h2>
        <div style="font-size:12px;color:var(--text3);margin-bottom:10px">${fmt(data.scannedAt)}</div>
        ${frameworks?`<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:12px">${frameworks}</div>`:""}
        <div class="scan-sev-grid">
          ${Object.entries(sevCounts).filter(([,v])=>v>0).map(([sev,cnt])=>`
            <div class="scan-sev-stat">
              <div style="font-family:var(--font-display);font-size:22px;font-weight:800;color:${sevColor(sev)}">${cnt}</div>
              <div style="font-size:10px;font-family:var(--font-mono);text-transform:uppercase;color:${sevColor(sev)}">${sev}</div>
            </div>`).join("")}
        </div>
        <div style="margin-top:10px">
          <button class="btn btn-primary btn-sm" onclick="navigateTo('vulnerabilities')">⚠ Lihat Semua di Vulnerabilities</button>
        </div>
      </div>
    </div>

    ${findings.length ? `
    <div class="card-header" style="margin:16px 0 10px;padding:0">
      <h2 style="font-family:var(--font-display)">Temuan — Klik untuk Detail & Lokasi Bug</h2>
      <span style="font-size:12px;color:var(--text3)">${findings.filter(f=>f.status==="open"||!f.status).length} terbuka</span>
    </div>
    ${findingHTML}` : `<div class="alert alert-success" style="margin-top:16px">✅ Tidak ada temuan otomatis. Website terlihat aman dari scan pasif!</div>`}`;
}

function renderScanFindingCard(f, hostname) {
  const sev = (f.severity||"info").toLowerCase();
  const loc = buildLocation({...f, hostname: hostname});
  const fixRec = f.fixRecommendations;

  return `
  <div class="finding-card sev-${sev}" style="cursor:pointer" onclick="openFindingModal(${jsA({...f,hostname:hostname})})">
    <div class="finding-left">
      <div class="finding-sev-box ${sev}">${sev.toUpperCase()}</div>
    </div>
    <div class="finding-body">
      <div class="finding-title">${esc(f.title)}</div>
      ${loc ? `<div class="bug-location">📍 <strong>Lokasi:</strong> ${loc}</div>` : ""}
      <div class="finding-meta-row">
        <span class="cat-tag">${esc(f.category||"General")}</span>
        ${fixRec?`<span style="font-size:10px;color:var(--green);font-family:var(--font-mono)">${fixRec.icon} Fix tersedia</span>`:""}
      </div>
      ${f.evidence ? `<div class="evidence-box">${esc(f.evidence.slice(0,200))}</div>` : ""}
    </div>
  </div>`;
}

/* ══════════════════════════════════════════════════════
   PAGE LISTENERS
══════════════════════════════════════════════════════ */
function attachPageListeners(page) {
  if (page === "domains") {
    document.getElementById("addDomainBtn")?.addEventListener("click", async () => {
      const domain = document.getElementById("d-domain").value.trim();
      if (!domain) { toast("Domain wajib diisi","error"); return; }
      try {
        await apiFetch("/api/my-domains",{method:"POST",body:JSON.stringify({domain,label:document.getElementById("d-label").value.trim()})});
        toast(`Domain ${domain} terdaftar!`,"success");
        navigateTo("domains");
      } catch(e) { toast(e.message,"error"); }
    });
  }

  if (page === "scanner") {
    document.getElementById("runScanBtn")?.addEventListener("click", async () => {
      const targets = parseScanTargets(document.getElementById("scanTarget").value);
      if (!targets.length) { toast("Masukkan domain target","error"); return; }
      if (targets.length > MAX_SCAN_TARGETS) { toast(`Maksimal ${MAX_SCAN_TARGETS} target per scan`,"error"); return; }
      const targetLabel = targets.length === 1 ? targets[0] : `${targets.length} target`;
      const btn = document.getElementById("runScanBtn");
      btn.disabled = true;
      btn.innerHTML = `<span class="spinner"></span> Scanning ${esc(targetLabel)}...`;

      document.getElementById("scanResult").innerHTML = `
        <div class="card">
          <div style="padding:40px;text-align:center">
            <div style="font-size:32px;margin-bottom:12px;animation:shieldPulse 1.5s infinite">🔍</div>
            <div style="font-family:var(--font-display);font-size:16px;font-weight:700;margin-bottom:8px">Scanning ${esc(targetLabel)}</div>
            ${targets.length > 1 ? `<div style="display:flex;gap:6px;justify-content:center;flex-wrap:wrap;margin-bottom:12px">${targets.map(t => `<code>${esc(t)}</code>`).join("")}</div>` : ""}
            <div style="font-size:12px;color:var(--text3);font-family:var(--font-mono)">
              Cek DNS · TLS/SSL · 30+ Headers · CORS · Cookies · 305 Sensitive Paths · JS Analysis · API Endpoints · Subdomains
            </div>
            <div style="margin-top:16px;font-size:11px;color:var(--text3)">Mohon tunggu, batch scan diproses berurutan...</div>
          </div>
        </div>`;

      try {
        const payload = targets.length === 1
          ? { target: targets[0], authorized:true }
          : { targets, authorized:true };
        const res = await apiFetch("/api/scan",{method:"POST",body:JSON.stringify(payload)});
        if (res.batch) renderBatchScanResult(res);
        else renderScanResult(res);
      } catch(e) {
        document.getElementById("scanResult").innerHTML = `<div class="alert alert-danger">❌ ${esc(e.message)}</div>`;
      }
      btn.disabled = false;
      btn.innerHTML = "⚡ Mulai Scan";
    });
  }

  if (page === "vulnerabilities") {
    function applyFilters() {
      const sev  = document.getElementById("severityFilter")?.value||"all";
      const stat = document.getElementById("statusFilter")?.value||"all";
      const dom  = (document.getElementById("domainFilter")?.value||"").toLowerCase();
      const cat  = (document.getElementById("catFilter")?.value||"").toLowerCase();
      const cards = document.querySelectorAll(".finding-card");
      let n = 0;
      cards.forEach(c => {
        const show = (sev==="all"||c.dataset.sev===sev)
          && (stat==="all"||c.dataset.status===stat)
          && (!dom||(c.dataset.domain||"").toLowerCase().includes(dom))
          && (!cat||(c.dataset.cat||"").toLowerCase().includes(cat));
        c.style.display = show?"":"none";
        if (show) n++;
      });
      const fc = document.getElementById("filterCount");
      if (fc) fc.textContent = n+" findings";
    }
    ["severityFilter","statusFilter","domainFilter","catFilter"].forEach(id =>
      document.getElementById(id)?.addEventListener("change", applyFilters)
    );
    document.getElementById("clearFilters")?.addEventListener("click", () => {
      ["severityFilter","statusFilter","domainFilter","catFilter"].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = el.options[0]?.value||"";
      });
      applyFilters();
    });
  }

  if (page === "code-scanner") {
    document.getElementById("runCodeScanBtn")?.addEventListener("click", async () => {
      const code = document.getElementById("cs-code")?.value;
      const fn   = document.getElementById("cs-fn")?.value||"unknown";
      if (!code?.trim()) { toast("Paste kode dulu","error"); return; }
      try {
        const res = await apiFetch("/api/code-scan",{method:"POST",body:JSON.stringify({code,filename:fn})});
        renderCodeResult(res, fn);
      } catch(e) { toast(e.message,"error"); }
    });
    document.getElementById("projectScanBtn")?.addEventListener("click", async () => {
      const btn = document.getElementById("projectScanBtn");
      btn.disabled = true; btn.textContent = "Scanning...";
      document.getElementById("codeScanResult").innerHTML = `<div class="card"><div style="padding:20px;text-align:center;color:var(--text3)">Scanning project...</div></div>`;
      try {
        const res = await apiFetch("/api/code-scan/project",{method:"POST",body:"{}"});
        renderCodeResult({filename:"project",findings:res.findings,scannedFiles:res.scannedFiles},"project");
      } catch(e) { document.getElementById("codeScanResult").innerHTML=`<div class="alert alert-danger">${esc(e.message)}</div>`; }
      btn.disabled = false; btn.textContent = "📁 Scan Project";
    });
  }

  if (page === "settings") {
    document.getElementById("saveSettingsBtn")?.addEventListener("click", async () => {
      try {
        await apiFetch("/api/settings",{method:"PUT",body:JSON.stringify({
          ai_provider:document.getElementById("set-provider").value,
          ai_model:document.getElementById("set-model").value
        })});
        toast("Settings disimpan!","success");
      } catch(e) { toast(e.message,"error"); }
    });
  }
}

function renderCodeResult(data, fn) {
  const findings = data.findings || [];
  if (!findings.length) {
    document.getElementById("codeScanResult").innerHTML = `<div class="alert alert-success">✅ Tidak ada masalah terdeteksi di ${esc(fn)}</div>`;
    return;
  }
  const cards = findings.map(f => {
    const sev = (f.severity||"info").toLowerCase();
    return `
    <div class="finding-card sev-${sev}">
      <div class="finding-left"><div class="finding-sev-box ${sev}">${sev.toUpperCase()}</div></div>
      <div class="finding-body">
        <div class="finding-title">${esc(f.title)}</div>
        <div class="bug-location">📍 <strong>File:</strong> <code>${esc(f.file||fn)}</code>${f.line?` — Line <code>${f.line}</code>`:""}</div>
        ${f.evidence?`<div class="evidence-box">${esc(f.evidence)}</div>`:""}
        <div class="rec-box">💡 ${esc(f.recommendation||"")}</div>
        ${f.fixRecommendations?`<div class="fix-preview">${f.fixRecommendations.icon} <strong>${esc(f.fixRecommendations.title)}</strong>: ${esc(f.fixRecommendations.fixes[0]||"")}</div>`:""}
        <div class="finding-actions">
          <button class="btn btn-primary btn-sm" onclick="openFindingModal(${jsA(f)})">Detail Fix</button>
        </div>
      </div>
    </div>`;
  }).join("");

  document.getElementById("codeScanResult").innerHTML = `
  <div class="card">
    <div class="card-header">
      <h2>📋 ${esc(fn)} — ${findings.length} masalah${data.scannedFiles?` · ${data.scannedFiles.length} files`:""}</h2>
    </div>
    ${cards}
  </div>`;
}

navigateTo("dashboard");
