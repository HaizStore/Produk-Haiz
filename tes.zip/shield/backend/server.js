/**
 * WebShield - Security Scanner for Website Owners
 * Port: 4000
 */

try {
  const fs = require("fs"), path = require("path");
  const envPath = path.join(__dirname, ".env");
  if (fs.existsSync(envPath)) {
    for (const line of fs.readFileSync(envPath, "utf8").split("\n")) {
      const t = line.trim();
      if (!t || t.startsWith("#")) continue;
      const [key, ...rest] = t.split("=");
      const val = rest.join("=").replace(/^["']|["']$/g, "");
      if (key && !process.env[key]) process.env[key] = val;
    }
  }
} catch {}

const http = require("http");
const path = require("path");
const { domainToASCII } = require("url");

const HOST = process.env.HOST || "127.0.0.1";
const PORT = Number(process.env.PORT || 4000);

const store    = require("./data/store");
const { runScan } = require("./utils/scanner");
const { scanCode, scanDotEnvLeak, scanProject } = require("./utils/codeScanner");
const { rateLimit, sanitizeString, addSecurityHeaders } = require("./middleware/index");
const { getFixRecommendations, getAllCategories, getCategoryFix } = require("./utils/fixAdvisor");

const scanLimiter    = rateLimit(Number(process.env.SCAN_RATE_LIMIT_PER_MINUTE  || 10));
const generalLimiter = rateLimit(120);
const MAX_SCAN_BATCH = Math.max(1, Math.min(25, Number(process.env.MAX_SCAN_BATCH || 10)));

const AI_PROVIDERS = new Set(["openai","anthropic","gemini","groq","openrouter","local"]);
const FRONTEND_ORIGINS = new Set([
  "http://localhost:3000","http://127.0.0.1:3000",
  process.env.FRONTEND_ORIGIN
].filter(Boolean));

// ─── Helpers ─────────────────────────────────────────────────────────────────
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on("data", c => { size += c.length; if (size > 2*1024*1024) { req.destroy(); reject(new Error("Request terlalu besar.")); return; } chunks.push(c); });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}
function sendJson(res, status, data) {
  addSecurityHeaders(res);
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(data));
}
function sendError(res, status, msg) { sendJson(res, status, { error: msg }); }

async function applyMw(mws, req, res) {
  return new Promise(resolve => {
    let i = 0;
    function next() { if (i < mws.length) mws[i++](req, res, next); else resolve(true); }
    next();
  });
}

function setCors(req, res) {
  const origin = req.headers.origin;
  const allow  = origin && FRONTEND_ORIGINS.has(origin) ? origin : [...FRONTEND_ORIGINS][0];
  res.setHeader("Access-Control-Allow-Origin", allow||"*");
  res.setHeader("Vary", "Origin");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
}

function normalizeHostname(input) {
  if (!input || typeof input !== "string") return "";
  const raw = input.trim();
  try {
    const url = /^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? new URL(raw) : new URL(`https://${raw}`);
    let h = domainToASCII(url.hostname||"").toLowerCase();
    if (h.endsWith(".")) h = h.slice(0,-1);
    return h;
  } catch { return domainToASCII(raw.split("/")[0].split(":")[0]||"").toLowerCase(); }
}

function isValidDomain(h) {
  if (!h || h.length > 253 || !h.includes(".")) return false;
  return h.split(".").every(l => l.length>=1 && l.length<=63 && /^[a-z0-9-]+$/.test(l) && !l.startsWith("-") && !l.endsWith("-"));
}

function checkOwnerDomain(hostname) {
  const domains = store.listCollection("my_domains");
  if (!domains.length) return { allowed: false, reason: "Belum ada domain terdaftar. Daftarkan domain di My Domains terlebih dahulu." };
  const h = normalizeHostname(hostname);
  for (const d of domains) {
    const reg = normalizeHostname(d.domain||"");
    if (h === reg || h.endsWith(`.${reg}`)) return { allowed: true, domain: d };
    if (reg.startsWith("*.")) { const base = reg.slice(2); if (h.endsWith(`.${base}`)) return { allowed: true, domain: d }; }
  }
  return { allowed: false, reason: `Domain "${h}" belum terdaftar. Daftarkan di My Domains terlebih dahulu.` };
}

function extractScanTargets(data) {
  const raw = [];
  if (Array.isArray(data.targets)) raw.push(...data.targets);
  else if (typeof data.targets === "string") raw.push(data.targets);
  if (typeof data.target === "string") raw.push(data.target);

  const targets = [];
  const seen = new Set();
  for (const item of raw) {
    for (const part of String(item || "").split(/[\s,;]+/)) {
      const target = part.trim();
      if (!target) continue;
      const key = scanTargetKey(target);
      if (seen.has(key)) continue;
      seen.add(key);
      targets.push(target);
    }
  }
  return targets;
}

function scanTargetKey(input) {
  const raw = String(input || "").trim();
  try {
    const url = /^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? new URL(raw) : new URL(`https://${raw}`);
    let hostname = domainToASCII(url.hostname || "").toLowerCase();
    if (hostname.endsWith(".")) hostname = hostname.slice(0, -1);
    return `${hostname}:${url.port || ""}`;
  } catch {
    return normalizeHostname(raw) || raw.toLowerCase();
  }
}

function persistScanResult(targetInput, ownerDomain, result) {
  const findings = result.analysis?.findings || [];
  const enriched = findings.map(f => ({ ...f, fixRecommendations: getFixRecommendations(f) }));
  result.analysis = { ...(result.analysis || {}), findings: enriched };

  const scanRecord = store.insertItem("scans", {
    target: targetInput, hostname: result.target.hostname,
    domainId: ownerDomain?.id || "", score: result.analysis.score,
    scoreLabel: scoreLabel(result.analysis.score), findingsCount: findings.length,
    criticalCount: findings.filter(f => f.severity === "critical").length,
    highCount: findings.filter(f => f.severity === "high").length,
    mediumCount: findings.filter(f => f.severity === "medium").length,
    frameworks: result.refs?.frameworks || [], scannedAt: result.scannedAt
  });

  for (const f of enriched) {
    store.insertItem("findings", {
      scanId: scanRecord.id, domainId: ownerDomain?.id || "",
      target: targetInput, hostname: result.target.hostname,
      ...f, status: "open"
    });
  }

  store.addAuditLog("scan.run", `${result.target.hostname}: score=${result.analysis.score}, findings=${findings.length}`);
  return { ...result, scanId: scanRecord.id };
}

function compactScanResult(result) {
  return {
    scanId: result.scanId,
    scannedAt: result.scannedAt,
    target: result.target,
    refs: { frameworks: result.refs?.frameworks || [] },
    analysis: result.analysis,
    disclaimer: result.disclaimer
  };
}

function scoreLabel(score) {
  if (score >= 85) return "Aman";
  if (score >= 70) return "Cukup Aman";
  if (score >= 50) return "Perlu Perhatian";
  if (score >= 30) return "Rentan";
  return "Kritis";
}

// ─── Router ──────────────────────────────────────────────────────────────────
async function router(req, res) {
  const url    = new URL(req.url, `http://${HOST}`);
  const method = req.method.toUpperCase();
  const p      = url.pathname;

  setCors(req, res);
  if (method === "OPTIONS") { res.writeHead(204); res.end(); return; }

  // Health
  if (p === "/api/health" && method === "GET") {
    sendJson(res, 200, { ok: true, service: "WebShield", timestamp: new Date().toISOString() });
    return;
  }

  // ── MY DOMAINS ────────────────────────────────────────────────────────────
  if (p === "/api/my-domains" && method === "GET") {
    const domains   = store.listCollection("my_domains");
    const scans     = store.listCollection("scans");
    const findings  = store.listCollection("findings");
    const enriched  = domains.map(d => {
      const reg = normalizeHostname(d.domain||"");
      const domScans = scans.filter(s => { const h=normalizeHostname(s.target||""); return h===reg||h.endsWith(`.${reg}`); })
        .sort((a,b) => new Date(b.scannedAt||b.createdAt)-new Date(a.scannedAt||a.createdAt));
      const lastScan = domScans[0];
      const open = findings.filter(f => { const h=normalizeHostname(f.hostname||f.target||""); return (h===reg||h.endsWith(`.${reg}`))&&f.status==="open"; });
      return { ...d, lastScore:lastScan?.score, lastScoreLabel:lastScan?scoreLabel(lastScan.score):null,
        lastScanAt:lastScan?.scannedAt||lastScan?.createdAt||null, totalScans:domScans.length,
        openFindings:open.length, criticalFindings:open.filter(f=>f.severity==="critical").length,
        highFindings:open.filter(f=>f.severity==="high").length };
    });
    sendJson(res, 200, enriched);
    return;
  }

  if (p === "/api/my-domains" && method === "POST") {
    const body = await readBody(req);
    let data; try { data = JSON.parse(body); } catch { sendError(res,400,"JSON tidak valid."); return; }
    const domain = sanitizeString(data.domain||"").toLowerCase().trim();
    if (!domain) { sendError(res,400,"Domain wajib diisi."); return; }
    const h = normalizeHostname(domain);
    if (!isValidDomain(h.startsWith("*.")?h.slice(2):h)) { sendError(res,400,"Format domain tidak valid."); return; }
    if (store.listCollection("my_domains").find(d=>normalizeHostname(d.domain)===h)) { sendError(res,409,"Domain sudah terdaftar."); return; }
    const item = store.insertItem("my_domains",{ domain:h, label:sanitizeString(data.label||""), addedAt:new Date().toISOString() });
    store.addAuditLog("domain.add",`Registered: ${h}`);
    sendJson(res,201,item);
    return;
  }

  if (p.startsWith("/api/my-domains/") && method === "DELETE") {
    const id = p.split("/")[3];
    if (!store.deleteItem("my_domains",id)) { sendError(res,404,"Tidak ditemukan."); return; }
    store.addAuditLog("domain.delete",`Deleted: ${id}`);
    sendJson(res,200,{ok:true});
    return;
  }

  if (p.startsWith("/api/my-domains/") && method === "PUT") {
    const id = p.split("/")[3];
    const body = await readBody(req);
    let data; try { data = JSON.parse(body); } catch { sendError(res,400,"JSON tidak valid."); return; }
    const updated = store.updateItem("my_domains",id,{ label:sanitizeString(data.label||"") });
    if (!updated) { sendError(res,404,"Tidak ditemukan."); return; }
    sendJson(res,200,updated);
    return;
  }

  // ── SCAN ──────────────────────────────────────────────────────────────────
  if (p === "/api/scan" && method === "POST") {
    const ok = await applyMw([scanLimiter], req, res); if (!ok) return;
    const body = await readBody(req);
    let data; try { data = JSON.parse(body); } catch { sendError(res,400,"JSON tidak valid."); return; }
    const targets = extractScanTargets(data);
    if (!targets.length) { sendError(res,400,"Target wajib diisi."); return; }
    if (targets.length > MAX_SCAN_BATCH) { sendError(res,400,`Maksimal ${MAX_SCAN_BATCH} target per batch.`); return; }
    const wantsBatch = Array.isArray(data.targets) || typeof data.targets === "string" || targets.length > 1;

    try {
      if (!wantsBatch) {
        const ownerCheck = checkOwnerDomain(targets[0]);
        if (!ownerCheck.allowed) { sendError(res,403,ownerCheck.reason); return; }
        const result = await runScan(targets[0]);
        sendJson(res, 200, persistScanResult(targets[0], ownerCheck.domain, result));
        return;
      }

      const results = [];
      for (const target of targets) {
        const ownerCheck = checkOwnerDomain(target);
        if (!ownerCheck.allowed) {
          results.push({ target, ok: false, error: ownerCheck.reason });
          continue;
        }

        try {
          const result = persistScanResult(target, ownerCheck.domain, await runScan(target));
          results.push({
            target, ok: true, scanId: result.scanId,
            hostname: result.target?.hostname || target,
            score: result.analysis?.score,
            scoreLabel: scoreLabel(result.analysis?.score),
            findingsCount: result.analysis?.findings?.length || 0,
            result: compactScanResult(result)
          });
        } catch (err) {
          results.push({ target, ok: false, error: err.message });
        }
      }

      const successCount = results.filter(r => r.ok).length;
      store.addAuditLog("scan.batch", `${successCount}/${targets.length} targets completed`);
      sendJson(res, 200, {
        batch: true,
        maxTargets: MAX_SCAN_BATCH,
        total: targets.length,
        successCount,
        failureCount: targets.length - successCount,
        results
      });
    } catch(err) { sendError(res,400,err.message); }
    return;
  }

  // ── SCANS ─────────────────────────────────────────────────────────────────
  if (p === "/api/scans" && method === "GET") {
    sendJson(res,200,store.listCollection("scans").slice().reverse());
    return;
  }
  if (p.startsWith("/api/scans/") && method === "DELETE") {
    store.deleteItem("scans",p.split("/")[3]);
    sendJson(res,200,{ok:true});
    return;
  }

  // ── FINDINGS ──────────────────────────────────────────────────────────────
  if (p === "/api/findings" && method === "GET") {
    let items = store.listCollection("findings");
    const df = url.searchParams.get("domain");
    const sf = url.searchParams.get("status");
    if (df) { const h=normalizeHostname(df); items=items.filter(f=>normalizeHostname(f.hostname||f.target||"").includes(h)); }
    if (sf) items = items.filter(f=>f.status===sf);
    sendJson(res,200,items.slice().reverse());
    return;
  }

  if (p.startsWith("/api/findings/") && method === "PUT") {
    const id = p.split("/")[3];
    const body = await readBody(req);
    let data; try { data=JSON.parse(body); } catch { sendError(res,400,"JSON tidak valid."); return; }
    const allowed=["open","fixed","acknowledged","false_positive","in_progress"];
    if (data.status && !allowed.includes(data.status)) { sendError(res,400,"Status tidak valid."); return; }
    const updated = store.updateItem("findings",id,data);
    if (!updated) { sendError(res,404,"Finding tidak ditemukan."); return; }
    if (data.status==="fixed") store.insertItem("fix_history",{ findingId:id, title:updated.title, hostname:updated.hostname, fixedAt:new Date().toISOString() });
    store.addAuditLog("finding.update",`${id} → ${data.status||"updated"}`);
    sendJson(res,200,updated);
    return;
  }

  if (p.startsWith("/api/findings/") && method === "DELETE") {
    store.deleteItem("findings",p.split("/")[3]);
    sendJson(res,200,{ok:true});
    return;
  }

  // ── FIX GUIDE ─────────────────────────────────────────────────────────────
  if (p === "/api/fix-categories" && method === "GET") {
    sendJson(res,200,getAllCategories());
    return;
  }
  if (p.startsWith("/api/fix-categories/") && method === "GET") {
    const cat = getCategoryFix(p.split("/")[3]);
    if (!cat) { sendError(res,404,"Kategori tidak ditemukan."); return; }
    sendJson(res,200,cat);
    return;
  }

  // ── CODE SCAN ─────────────────────────────────────────────────────────────
  if (p === "/api/code-scan" && method === "POST") {
    const body = await readBody(req);
    let data; try { data=JSON.parse(body); } catch { sendError(res,400,"JSON tidak valid."); return; }
    if (!data.code) { sendError(res,400,"Code wajib diisi."); return; }
    const filename = sanitizeString(data.filename||"unknown.js");
    const code = String(data.code||"").slice(0,100000);
    const findings = [...scanCode(code,filename), ...scanDotEnvLeak(code,filename)];
    const enriched = findings.map(f=>({...f, fixRecommendations:getFixRecommendations(f)}));
    for (const f of enriched) store.insertItem("findings",{...f,source:"code",target:filename,hostname:"code-scan",status:"open"});
    store.addAuditLog("code-scan",`${filename}: ${findings.length} issues`);
    sendJson(res,200,{ filename, findings:enriched });
    return;
  }

  if (p === "/api/code-scan/project" && method === "POST") {
    const ok = await applyMw([scanLimiter],req,res); if (!ok) return;
    const projectRoot = path.resolve(__dirname,"..");
    const result = scanProject(projectRoot,{maxFiles:120});
    const enriched = result.findings.map(f=>({...f,fixRecommendations:getFixRecommendations(f)}));
    const scanRecord = store.insertItem("scans",{
      target:"project-code",hostname:"code-scan",source:"code",
      score:Math.max(0,100-result.findings.length*3),
      findingsCount:result.findings.length,scannedAt:new Date().toISOString()
    });
    for (const f of enriched) store.insertItem("findings",{scanId:scanRecord.id,...f,source:"code",target:f.file,hostname:"code-scan",status:"open"});
    store.addAuditLog("code-scan.project",`${result.scannedFiles?.length||0} files, ${result.findings.length} issues`);
    sendJson(res,200,{...result,findings:enriched});
    return;
  }

  // ── STATS ─────────────────────────────────────────────────────────────────
  if (p === "/api/stats" && method === "GET") {
    const domains    = store.listCollection("my_domains");
    const scans      = store.listCollection("scans");
    const findings   = store.listCollection("findings");
    const fixHistory = store.listCollection("fix_history");
    const open = findings.filter(f=>f.status==="open");
    const bySev = {critical:0,high:0,medium:0,low:0,info:0};
    for (const f of open) bySev[f.severity] = (bySev[f.severity]||0)+1;
    const domainScores = domains.map(d => {
      const reg = normalizeHostname(d.domain||"");
      const ds = scans.filter(s=>{ const h=normalizeHostname(s.target||""); return h===reg||h.endsWith(`.${reg}`); })
        .sort((a,b)=>new Date(b.scannedAt||b.createdAt)-new Date(a.scannedAt||a.createdAt));
      return { domain:d.domain, label:d.label, score:ds[0]?.score, scoreLabel:ds[0]?scoreLabel(ds[0].score):null };
    });
    const scored = domainScores.filter(d=>d.score!=null);
    const avgScore = scored.length ? Math.round(scored.reduce((s,d)=>s+d.score,0)/scored.length) : null;
    sendJson(res,200,{
      totalDomains:domains.length, totalScans:scans.length,
      totalOpenFindings:open.length, totalFixed:fixHistory.length,
      findingsBySeverity:bySev, avgSecurityScore:avgScore,
      avgScoreLabel:avgScore!=null?scoreLabel(avgScore):null, domainScores,
      recentScans:scans.slice().reverse().slice(0,5),
      recentFindings:open.slice().reverse().slice(0,8),
      fixHistory:fixHistory.slice().reverse().slice(0,5)
    });
    return;
  }

  // ── FIX HISTORY ───────────────────────────────────────────────────────────
  if (p === "/api/fix-history" && method === "GET") {
    sendJson(res,200,store.listCollection("fix_history").slice().reverse());
    return;
  }

  // ── AUDIT LOGS ────────────────────────────────────────────────────────────
  if (p === "/api/audit-logs" && method === "GET") {
    sendJson(res,200,store.listCollection("audit_logs").slice(0,100));
    return;
  }

  // ── SETTINGS ──────────────────────────────────────────────────────────────
  if (p === "/api/settings" && method === "GET") {
    const db = store.getDb();
    const keys = {
      openai:  Boolean(process.env.OPENAI_API_KEY),
      anthropic: Boolean(process.env.ANTHROPIC_API_KEY),
      gemini:  Boolean(process.env.GEMINI_API_KEY),
      groq:    Boolean(process.env.GROQ_API_KEY),
      openrouter: Boolean(process.env.OPENROUTER_API_KEY),
      local:   Boolean(process.env.LOCAL_AI_BASE_URL)
    };
    sendJson(res,200,{ settings:db.settings||{}, ai:{ configured:keys, provider:db.settings?.ai_provider, model:db.settings?.ai_model } });
    return;
  }

  if (p === "/api/settings" && method === "PUT") {
    const body = await readBody(req);
    let data; try { data=JSON.parse(body); } catch { sendError(res,400,"JSON tidak valid."); return; }
    const provider = sanitizeString(data.ai_provider||data.provider||"").toLowerCase();
    const model = sanitizeString(data.ai_model||data.model||"",120);
    if (!AI_PROVIDERS.has(provider)) { sendError(res,400,"Provider tidak valid."); return; }
    const db = store.getDb();
    db.settings = { ...(db.settings||{}), ai_provider:provider, ai_model:model||db.settings?.ai_model||"" };
    store.save();
    store.addAuditLog("settings.update",`${provider}/${db.settings.ai_model}`);
    sendJson(res,200,{ settings:db.settings });
    return;
  }

  sendError(res,404,"Endpoint tidak ditemukan.");
}

// ─── Server ───────────────────────────────────────────────────────────────────
const server = http.createServer(async (req, res) => {
  try { await router(req, res); }
  catch(err) {
    console.error("Server error:", err.message);
    try { res.writeHead(500,{"Content-Type":"application/json"}); res.end(JSON.stringify({error:"Internal server error."})); } catch {}
  }
});

function start(port) {
  server.once("error", err => {
    if (err.code === "EADDRINUSE" && port < PORT+10) { start(port+1); return; }
    console.error(err); process.exit(1);
  });
  server.listen(port, HOST, () => {
    console.log(`\n🛡️  WebShield - Security Scanner`);
    console.log(`   Backend: http://${HOST}:${port}`);
    console.log(`   Frontend: npm start di folder /frontend\n`);
  });
}

start(PORT);
