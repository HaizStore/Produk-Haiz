/**
 * Passive Security Scanner - Enhanced Edition
 * Checks: DNS, TLS, headers, cookies, CORS, JS analysis, path recon,
 *         redirect chain, form detection, API discovery, version disclosure,
 *         open redirect hints, error pages, meta recon, content analysis
 *
 * RULES:
 * - No exploit payloads
 * - No brute force or credential stuffing
 * - No auth bypass attempts
 * - No unrestricted mass scanning; batch scans must be owner-verified and capped
 * - Rate limited between requests
 * - All findings labeled "indikasi awal, wajib diverifikasi manual"
 */

const http  = require("http");
const https = require("https");
const tls   = require("tls");
const dns   = require("dns").promises;
const net   = require("net");
const { URL, domainToASCII } = require("url");

const USER_AGENT    = "WebShield/2.0 passive-defender-scanner";
const DISCLAIMER    = "Temuan WebShield - passive scan. Wajib diverifikasi manual dan ditindaklanjuti dengan fix yang sesuai.";
const REQUEST_DELAY = Number(process.env.SCAN_REQUEST_DELAY_MS || 80);

// ─── Domain validation ────────────────────────────────────────────────────────

function normalizeTarget(input) {
  if (!input || typeof input !== "string") throw new Error("Masukkan domain target.");
  const trimmed = input.trim();
  if (trimmed.length > 2048) throw new Error("Input terlalu panjang.");
  const withScheme = /^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  const parsed = new URL(withScheme);
  if (!["https:", "http:"].includes(parsed.protocol)) throw new Error("Skema URL harus http atau https.");
  let hostname = domainToASCII(parsed.hostname || "").toLowerCase();
  if (hostname.endsWith(".")) hostname = hostname.slice(0, -1);
  if (!hostname) throw new Error("Domain target tidak valid.");

  const port = parsed.port || "";
  const proto = parsed.protocol;

  // Allow private IP addresses (for local server testing)
  if (net.isIP(hostname)) {
    const parts = hostname.split(".").map(Number);
    const isPrivate = hostname === "127.0.0.1" ||
      parts[0] === 10 ||
      (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) ||
      (parts[0] === 192 && parts[1] === 168);
    if (!isPrivate) throw new Error("Masukkan domain, bukan IP publik.");
    return { input: trimmed, hostname, protocol: proto || "http:", port, origin: `${proto}//${hostname}${port?":"+port:""}`, display: hostname, isLocal: true };
  }

  // Allow localhost variants
  const isLocal = hostname === "localhost" || hostname.endsWith(".localhost") || hostname.endsWith(".local");

  if (!isLocal && !isValidDomain(hostname)) throw new Error("Format domain tidak valid.");

  return { input: trimmed, hostname, protocol: proto, port, origin: `${proto}//${hostname}${port?":"+port:""}`, display: hostname, isLocal };
}


function isValidDomain(h) {
  if (h.length > 253 || !h.includes(".")) return false;
  return h.split(".").every(l => l.length >= 1 && l.length <= 63 && /^[a-z0-9-]+$/.test(l) && !l.startsWith("-") && !l.endsWith("-"));
}

function isPublicIpv4(address) {
  const parts = address.split(".").map(Number);
  if (parts.length !== 4 || parts.some(p => !Number.isInteger(p))) return false;
  const [a, b, c] = parts;
  if (a === 0 || a === 10 || a === 127) return false;
  if (a === 100 && b >= 64 && b <= 127) return false;
  if (a === 169 && b === 254) return false;
  if (a === 172 && b >= 16 && b <= 31) return false;
  if (a === 192 && (b === 168 || (b === 0 && (c === 0 || c === 2)))) return false;
  if (a === 198 && (b === 18 || b === 19 || (b === 51 && c === 100))) return false;
  if (a === 203 && b === 0 && c === 113) return false;
  if (a >= 224) return false;
  return true;
}

function isPublicIp(address) {
  const family = net.isIP(address);
  if (family === 4) return isPublicIpv4(address);
  if (family === 6) {
    const l = address.toLowerCase();
    if (l === "::" || l === "::1" || l.startsWith("fc") || l.startsWith("fd")) return false;
    if (l.startsWith("fe8") || l.startsWith("fe9") || l.startsWith("fea") || l.startsWith("feb")) return false;
    if (l.startsWith("ff") || l.startsWith("2001:db8")) return false;
    if (l.startsWith("::ffff:")) return isPublicIpv4(l.slice(7));
    return true;
  }
  return false;
}

// ─── DNS ─────────────────────────────────────────────────────────────────────

async function resolveDns(hostname) {
  // Skip DNS for IP addresses
  if (/^\d+\.\d+\.\d+\.\d+$/.test(hostname)) {
    return { addresses: [hostname], mx: [], txt: [], ns: [], caa: [], mail: { spf: null, dmarc: null } };
  }

  const [a, aaaa, mx, txt, ns, caa, dmarc] = await Promise.allSettled([
    dns.resolve4(hostname),
    dns.resolve6(hostname),
    dns.resolveMx(hostname),
    dns.resolveTxt(hostname),
    dns.resolveNs(hostname),
    typeof dns.resolveCaa === "function" ? dns.resolveCaa(hostname) : Promise.resolve([]),
    dns.resolveTxt(`_dmarc.${hostname}`)
  ]);
  let ipv4 = sv(a, []);
  let ipv6 = sv(aaaa, []);
  if (ipv4.length === 0 && ipv6.length === 0) {
    try {
      const fallback = await dns.lookup(hostname, { all: true });
      ipv4 = [...new Set(fallback.filter(i => i.family === 4).map(i => i.address))];
      ipv6 = [...new Set(fallback.filter(i => i.family === 6).map(i => i.address))];
    } catch {}
  }
  const txtRecs  = flatTxt(sv(txt, []));
  const dmarcRecs = flatTxt(sv(dmarc, []));
  const addresses = [...ipv4.map(ip => ({ address: ip, family: 4 })), ...ipv6.map(ip => ({ address: ip, family: 6 }))];
  if (addresses.length === 0) throw new Error("DNS A/AAAA tidak ditemukan untuk domain ini.");
  const privateAddrs = addresses.filter(i => !isPublicIp(i.address));
  if (privateAddrs.length > 0) throw new Error("Domain resolve ke alamat privat/internal, scan dihentikan.");
  return {
    addresses,
    recordChecks: {
      txt: isKnownDnsResult(txt),
      dmarc: isKnownDnsResult(dmarc),
      caa: isKnownDnsResult(caa)
    },
    records: {
      a: ipv4, aaaa: ipv6,
      mx: sv(mx, []).sort((l, r) => l.priority - r.priority),
      ns: sv(ns, []), txt: txtRecs, caa: sv(caa, []), dmarc: dmarcRecs
    },
    mail: {
      spf:   txtRecs.find(r => r.toLowerCase().startsWith("v=spf1")) || "",
      dmarc: dmarcRecs.find(r => r.toLowerCase().startsWith("v=dmarc1")) || ""
    }
  };
}

function sv(r, fb) { return r.status === "fulfilled" ? r.value : fb; }
function flatTxt(recs) { return recs.map(r => r.join("")); }
function isKnownDnsResult(r) {
  return r.status === "fulfilled" || ["ENODATA", "ENOTFOUND", "ENODOMAIN"].includes(r.reason?.code);
}

// ─── HTTP Request ─────────────────────────────────────────────────────────────

function createLookup(addresses) {
  return (_h, opts, cb) => {
    const options = typeof opts === "object" ? opts : {};
    const family = options.family || 0;
    const pool = family ? addresses.filter(i => i.family === family) : addresses;
    const sel  = pool[0] || addresses[0];
    if (!sel) { cb(new Error("No public address")); return; }
    if (options.all) { cb(null, pool.length ? pool : addresses); return; }
    cb(null, sel.address, sel.family);
  };
}

async function fetchUrl(target, pathname, opts = {}) {
  const method     = opts.method || "GET";
  const maxBytes   = opts.maxBytes  ?? 65536;
  const timeoutMs  = opts.timeoutMs ?? opts.timeout ?? 6000;
  const maxRedirects = opts.maxRedirects ?? 3;
  const protocol   = opts.protocol || target.protocol || "https:";
  const headers    = opts.headers || {};
  return fetchWithRedirects({ ...target, protocol }, pathname, { method, maxBytes, timeoutMs, maxRedirects, headers }, 0);
}

async function fetchWithRedirects(target, pathname, opts, redirectCount) {
  // For local/IP targets, skip DNS resolution
  const isIp = target.isLocal && /^\d+\.\d+\.\d+\.\d+$/.test(target.hostname);
  const dnsInfo = isIp ? { addresses: [target.hostname] } : (target.dns || await resolveDns(target.hostname));
  const lookup  = isIp ? undefined : createLookup(dnsInfo.addresses);
  const lib     = target.protocol === "http:" ? http : https;

  const response = await new Promise(resolve => {
    const req = lib.request({
      protocol: target.protocol, hostname: target.hostname,
      port: target.port ? Number(target.port) : (target.protocol === "http:" ? 80 : 443),
      method: opts.method, path: pathname, ...(lookup ? { lookup } : {}),
      timeout: opts.timeoutMs, rejectUnauthorized: false,
      headers: { "User-Agent": USER_AGENT, Accept: "text/html,text/plain,application/json,*/*;q=0.8", ...opts.headers }
    }, res => {
      const chunks = [];
      let bytes = 0;
      let completed = false;
      const finish = extra => {
        if (completed) return;
        completed = true;
        resolve({ ok: true, statusCode: res.statusCode, headers: normalizeHeaders(res.headers), body: Buffer.concat(chunks).toString("utf8"), finalUrl: `${target.protocol}//${target.hostname}${pathname}`, redirected: redirectCount > 0, ...extra });
      };
      res.on("data", chunk => {
        const remaining = Math.max(0, opts.maxBytes - bytes);
        if (remaining > 0) chunks.push(chunk.subarray(0, remaining));
        bytes += chunk.length;
        if (bytes > opts.maxBytes) {
          finish({ truncated: true });
          res.destroy();
        }
      });
      res.on("end",     () => finish({}));
      res.on("aborted", () => finish({ truncated: true }));
      res.on("error",   () => finish({ truncated: true }));
    });
    req.on("timeout", () => req.destroy(new Error("Timeout")));
    req.on("error",   err => resolve({ ok: false, error: err.message, statusCode: 0, headers: {}, body: "", finalUrl: `${target.protocol}//${target.hostname}${pathname}` }));
    req.end();
  });

  const location = response.headers.location;
  const isRedirect = [301, 302, 303, 307, 308].includes(response.statusCode) && location;
  if (isRedirect && redirectCount < opts.maxRedirects) {
    const nextUrl = new URL(location, `${target.protocol}//${target.hostname}`);
    if (nextUrl.hostname.toLowerCase() !== target.hostname.toLowerCase()) {
      return { ...response, redirectBlocked: true, blockedLocation: nextUrl.toString() };
    }
    const nextTarget = normalizeTarget(nextUrl.toString());
    nextTarget.dns   = await resolveDns(nextTarget.hostname);
    return fetchWithRedirects(nextTarget, `${nextUrl.pathname}${nextUrl.search || ""}`, opts, redirectCount + 1);
  }
  return response;
}

function normalizeHeaders(headers) {
  const out = {};
  for (const [k, v] of Object.entries(headers || {})) {
    out[k.toLowerCase()] = Array.isArray(v) ? v.join(", ") : v;
  }
  return out;
}

// ─── TLS ─────────────────────────────────────────────────────────────────────

async function checkTls(hostname, dnsInfo) {
  const sel = dnsInfo.addresses.find(i => i.family === 4) || dnsInfo.addresses[0];
  return new Promise(resolve => {
    const socket = tls.connect({ host: sel.address, port: 443, servername: hostname, rejectUnauthorized: false, timeout: 10000 });
    socket.once("secureConnect", () => {
      const cert = socket.getPeerCertificate();
      const validTo   = cert?.valid_to   ? new Date(cert.valid_to)   : null;
      const validFrom = cert?.valid_from ? new Date(cert.valid_from) : null;
      const daysRemaining = validTo ? Math.ceil((validTo.getTime() - Date.now()) / 86400000) : null;
      const proto = socket.getProtocol() || "";
      resolve({
        ok: true, authorized: socket.authorized, authorizationError: socket.authorizationError || "",
        protocol: proto, cipher: socket.getCipher(),
        weakProtocol: /TLSv1\.0|TLSv1\.1|SSLv/i.test(proto),
        certificate: {
          subject: cert.subject || {}, issuer: cert.issuer || {},
          validFrom: validFrom?.toISOString() || "", validTo: validTo?.toISOString() || "",
          daysRemaining, subjectAltName: cert.subjectaltname || "",
          selfSigned: cert.issuer?.CN === cert.subject?.CN
        }
      });
      socket.end();
    });
    socket.once("timeout", () => socket.destroy(new Error("TLS timeout")));
    socket.once("error",   err => resolve({ ok: false, authorized: false, authorizationError: err.message, protocol: "", cipher: null, certificate: null }));
  });
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function redact(value) {
  return String(value || "")
    .replace(/(api[_-]?key|token|secret|password|authorization|session|cookie)(\s*[:=]\s*)["']?[^"'\s&]{6,}/gi, "$1$2[REDACTED]")
    .replace(/\b(sk-[a-z0-9_-]{8,}|gh[pousr]_[a-z0-9_]{8,}|xox[baprs]-[a-z0-9-]{8,}|AIza[a-z0-9_-]{8,}|gsk_[a-z0-9_]{8,})\b/gi, "[REDACTED_TOKEN]")
    .slice(0, 600);
}

function getHeaderValues(headers, key) {
  const value = headers?.[key.toLowerCase()];
  if (!value) return [];
  return Array.isArray(value) ? value : String(value).split(/,\s*(?=[^;]+=)/);
}

// ─── HTML / JS Parsing ────────────────────────────────────────────────────────

function parseHtmlRefs(body, hostname) {
  const html = body || "";
  const scripts = [], links = [], forms = [], inputs = [];

  const scriptRe = /<script\b[^>]*\bsrc=["']([^"']+)["'][^>]*>/gi;
  const hrefRe   = /<(?:a|link)\b[^>]*\bhref=["']([^"']+)["'][^>]*>/gi;
  const formRe   = /<form\b([^>]*)>/gi;
  const inputRe  = /<input\b([^>]*)>/gi;
  const commentRe = /<!--([\s\S]{4,200}?)-->/gi;
  let match;

  while ((match = scriptRe.exec(html)) && scripts.length < 10) {
    const n = normalizeSameOriginPath(match[1], hostname);
    if (n && /\.js(?:[?#].*)?$/i.test(n)) scripts.push(n);
  }
  while ((match = hrefRe.exec(html)) && links.length < 20) {
    const n = normalizeSameOriginPath(match[1], hostname);
    if (n && !/\.(png|jpe?g|gif|svg|webp|css|ico|woff2?)(?:[?#].*)?$/i.test(n)) links.push(n);
  }
  while ((match = formRe.exec(html)) && forms.length < 10) {
    const attr  = match[1];
    const action = (/action=["']([^"']*)["']/i.exec(attr) || [])[1] || "";
    const method = (/method=["']([^"']*)["']/i.exec(attr) || [])[1] || "GET";
    forms.push({ action: action.slice(0, 200), method: method.toUpperCase() });
  }
  while ((match = inputRe.exec(html)) && inputs.length < 20) {
    const attr = match[1];
    const name = (/name=["']([^"']*)["']/i.exec(attr) || [])[1] || "";
    const type = (/type=["']([^"']*)["']/i.exec(attr) || [])[1] || "text";
    if (name) inputs.push({ name: name.slice(0, 80), type: type.toLowerCase() });
  }

  // Extract HTML comments that might contain dev notes
  const comments = [];
  while ((match = commentRe.exec(html)) && comments.length < 5) {
    const text = match[1].trim();
    if (/todo|fixme|debug|password|api|key|hack|secret|internal|admin/i.test(text)) {
      comments.push(text.slice(0, 150));
    }
  }

  // Meta tags for tech detection
  const metas = [];
  const metaRe = /<meta\b[^>]*>/gi;
  while ((match = metaRe.exec(html)) && metas.length < 15) metas.push(match[0]);

  // Generator/framework hints
  const generator = (/name=["']generator["'][^>]*content=["']([^"']{1,80})["']/i.exec(html) || [])[1] || "";
  const wpLogin   = /wp-login|wp-content|wp-includes/i.test(html);
  const laravelToken = /__token|csrf-token|laravel_session/i.test(html);
  const nextJs    = /__NEXT_DATA__|_next\/static/i.test(html);
  const nuxtJs    = /__NUXT__|_nuxt\//i.test(html);
  const angularJs = /ng-app|ng-controller|ng-model/i.test(html);
  const reactApp  = /react-root|__reactFiber|data-reactroot/i.test(html);
  const jqueryUse = /jquery[.-][0-9]|jquery\.min\.js/i.test(html);

  const frameworks = [];
  if (wpLogin) frameworks.push("WordPress");
  if (laravelToken) frameworks.push("Laravel/PHP");
  if (nextJs) frameworks.push("Next.js");
  if (nuxtJs) frameworks.push("Nuxt.js");
  if (angularJs) frameworks.push("AngularJS");
  if (reactApp) frameworks.push("React");
  if (jqueryUse) frameworks.push("jQuery");
  if (generator) frameworks.push(generator);

  return {
    scripts: [...new Set(scripts)].slice(0, 6),
    links:   [...new Set(links)].slice(0, 15),
    forms,
    inputs,
    comments,
    frameworks: [...new Set(frameworks)],
    metas
  };
}

function normalizeSameOriginPath(raw, hostname) {
  try {
    if (!raw || raw.startsWith("mailto:") || raw.startsWith("tel:") || raw.startsWith("javascript:") || raw.startsWith("#")) return "";
    const url = raw.startsWith("http") ? new URL(raw) : new URL(raw, `https://${hostname}`);
    if (url.hostname.toLowerCase() !== hostname.toLowerCase()) return "";
    return `${url.pathname}${url.search || ""}`;
  } catch { return ""; }
}

// ─── JavaScript Analysis ──────────────────────────────────────────────────────

function extractJsFindings(js, source) {
  const findings = [];

  // API endpoints
  const endpoints = [...new Set([
    ...[...js.matchAll(/["'`](\/api\/[a-z0-9_./?=&:\-]{2,80})["'`]/gi)].map(m => m[1]),
    ...[...js.matchAll(/["'`](\/v\d+\/[a-z0-9_./?=&:\-]{2,80})["'`]/gi)].map(m => m[1]),
    ...[...js.matchAll(/["'`](\/graphql[^"'`\s]{0,40})["'`]/gi)].map(m => m[1]),
    ...[...js.matchAll(/["'`](\/rest\/[a-z0-9_./?=&:\-]{2,60})["'`]/gi)].map(m => m[1]),
  ])].slice(0, 15);

  if (endpoints.length) {
    findings.push({
      severity: "info",
      title: `${endpoints.length} Endpoint API ditemukan di JavaScript`,
      evidence: endpoints.join(", "),
      recommendation: "Uji setiap endpoint: coba akses tanpa auth, ganti ID user (IDOR), coba method berbeda (GET/POST/PUT/DELETE), dan perhatikan response error yang bocor info.",
      category: "JavaScript Recon",
      source,
      huntingHints: endpoints.map(ep => ({
        endpoint: ep,
        checks: ["Akses tanpa Authorization header", "Ganti ID di path/param", "Coba method HTTP berbeda", "Lihat response error untuk info bocor"]
      }))
    });
  }

  // Hardcoded secrets / tokens
  const keyPatterns = [
    { re: /\b(sk-[A-Za-z0-9]{20,})\b/g, label: "OpenAI key" },
    { re: /\b(gsk_[A-Za-z0-9]{20,})\b/g, label: "Groq key" },
    { re: /\b(AIza[A-Za-z0-9_-]{35})\b/g, label: "Google API key" },
    { re: /\b(gh[ousr]_[A-Za-z0-9]{36,})\b/g, label: "GitHub token" },
    { re: /["']([A-Za-z0-9]{32,64})["']\s*[,}]?\s*\/\/\s*(key|secret|token|pass)/gi, label: "hardcoded secret" },
    { re: /(?:apiKey|clientSecret|accessToken|authToken|jwtSecret)\s*[:=]\s*["']([^"']{8,80})["']/gi, label: "assigned secret" },
  ];
  for (const { re, label } of keyPatterns) {
    const matches = [...js.matchAll(re)].slice(0, 3);
    if (matches.length) {
      findings.push({
        severity: "high",
        title: `Kemungkinan secret/token hardcoded di JS publik (${label})`,
        evidence: redact(matches.map(m => m[0]).join("; ")),
        recommendation: "Revoke token ini segera jika ini real. Secret tidak boleh ada di frontend JavaScript.",
        category: "JavaScript Recon",
        source
      });
    }
  }

  // Environment strings
  const envStrings = [...js.matchAll(/\b(NODE_ENV|DEBUG|STAGING|DEVELOPMENT|INTERNAL|localhost|127\.0\.0\.1|192\.168\.|10\.\d+\.\d+\.\d+)\b/gi)].slice(0, 8);
  if (envStrings.length) {
    findings.push({
      severity: "low",
      title: "String environment/internal ditemukan di JavaScript",
      evidence: redact(envStrings.map(m => m[0]).join(", ")),
      recommendation: "Review build process. String environment internal tidak boleh bocor ke production bundle.",
      category: "JavaScript Recon",
      source
    });
  }

  // Hardcoded URLs (internal/staging)
  const internalUrls = [...js.matchAll(/https?:\/\/(?:staging|dev|test|uat|internal|admin|beta|local)[a-z0-9.-]*\/[^\s"'`]{2,80}/gi)].slice(0, 6);
  if (internalUrls.length) {
    findings.push({
      severity: "medium",
      title: "URL staging/internal hardcoded di JavaScript",
      evidence: redact(internalUrls.map(m => m[0]).join(", ")),
      recommendation: "URL environment internal tidak boleh ada di production JS. Cek apakah URL tersebut bisa diakses publik.",
      category: "JavaScript Recon",
      source
    });
  }

  // Developer comments
  const comments = [...js.matchAll(/\/\/\s*(TODO|FIXME|HACK|DEBUG|REMOVE|TEMP|test|bypass|skip auth).{0,100}|\/\*\s*(TODO|FIXME|HACK|DEBUG)[\s\S]{0,200}?\*\//gi)].slice(0, 4);
  if (comments.length) {
    findings.push({
      severity: "info",
      title: "Komentar developer ditemukan di JavaScript publik",
      evidence: redact(comments.map(m => m[0]).join(" | ")),
      recommendation: "Hapus semua komentar TODO/FIXME/debug dari production build. Komentar ini bisa bocorkan logika internal.",
      category: "JavaScript Recon",
      source
    });
  }

  // GraphQL introspection hint
  if (/query\s+IntrospectionQuery|__schema\s*{|__typename/i.test(js)) {
    findings.push({
      severity: "info",
      title: "GraphQL terdeteksi di JavaScript",
      evidence: "Kata kunci GraphQL/introspection ditemukan",
      recommendation: "Coba POST ke /graphql dengan body {query:'{__schema{types{name}}}'}. Jika introspection aktif, semua schema bisa terbaca.",
      category: "JavaScript Recon",
      source
    });
  }

  // WebSocket usage
  if (/new WebSocket|io\.connect|socket\.io/i.test(js)) {
    findings.push({
      severity: "info",
      title: "WebSocket atau Socket.IO terdeteksi",
      evidence: "Koneksi real-time terdeteksi di JavaScript",
      recommendation: "WebSocket perlu auth tersendiri. Cek apakah WS endpoint menerapkan autentikasi dan validasi message.",
      category: "JavaScript Recon",
      source
    });
  }

  // S3/cloud storage URLs
  const s3Urls = [...js.matchAll(/https?:\/\/[a-z0-9.-]+\.(?:s3|s3-[a-z0-9-]+)\.amazonaws\.com\/[^\s"'`]{2,100}/gi)].slice(0, 5);
  if (s3Urls.length) {
    findings.push({
      severity: "medium",
      title: "URL S3/cloud storage ditemukan di JavaScript",
      evidence: redact(s3Urls.map(m => m[0]).join(", ")),
      recommendation: "Cek apakah S3 bucket publik atau private. Bucket publik bisa diakses tanpa auth. Coba akses langsung URL tersebut.",
      category: "JavaScript Recon",
      source
    });
  }

  return findings;
}

// ─── Form Analysis ────────────────────────────────────────────────────────────

function analyzeFormsAndInputs(forms, inputs, hostname) {
  const findings = [];

  // Login / auth forms
  const hasPasswordField = inputs.some(i => i.type === "password");
  const hasLoginForm     = forms.some(f => /login|signin|auth|account/i.test(f.action || "")) || hasPasswordField;

  if (hasLoginForm) {
    findings.push({
      severity: "info",
      title: "Form login/autentikasi terdeteksi",
      evidence: `Input password ditemukan. Forms: ${forms.map(f => f.action || "(root)").join(", ")}`,
      recommendation: "Area untuk cek manual: rate limiting login (coba salah password 10x), CSRF token presence, autocomplete=off, account enumeration (bedakan response untuk user valid vs invalid).",
      category: "Form Analysis",
      huntingChecklist: [
        "Coba login salah 10x — apakah ada lockout atau rate limit?",
        "Inspect request: apakah ada CSRF token?",
        "Coba username valid vs invalid — apakah response berbeda? (account enumeration)",
        "Cek apakah password dikirim lewat HTTPS",
        "Coba forgot password flow — apakah link reset bisa direuse?"
      ]
    });
  }

  // Search / query inputs
  const searchInputs = inputs.filter(i => /search|query|q\b|keyword|term/i.test(i.name));
  if (searchInputs.length) {
    findings.push({
      severity: "info",
      title: `Input pencarian terdeteksi (${searchInputs.length} field)`,
      evidence: `Fields: ${searchInputs.map(i => i.name).join(", ")}`,
      recommendation: "Input search adalah target XSS dan SQLi. Cek secara manual: apakah input di-reflect ke halaman? Apakah bisa inject karakter <>\\'\".",
      category: "Form Analysis",
      huntingChecklist: [
        `Coba masukkan <script>alert(1)</script> ke field: ${searchInputs.map(i => i.name).join(", ")}`,
        "Cek apakah input direflect ke HTML response",
        "Coba karakter ' dan \" — perhatikan response atau error",
        "Cek parameter di URL — apakah nilai parameter muncul di halaman?"
      ]
    });
  }

  // File upload
  const fileInputs = inputs.filter(i => i.type === "file");
  if (fileInputs.length) {
    findings.push({
      severity: "medium",
      title: `File upload terdeteksi (${fileInputs.length} input)`,
      evidence: `Input file: ${fileInputs.map(i => i.name || "(unnamed)").join(", ")}`,
      recommendation: "File upload adalah area bug bounty tinggi. Cek: tipe file apa yang diterima? Apakah bisa upload .php/.js? Di mana file disimpan? Apakah bisa diakses publik?",
      category: "Form Analysis",
      huntingChecklist: [
        "Upload file dengan ekstensi berbeda (.txt, .svg, .html) — apakah diblok?",
        "Cek header Content-Type dari file yang diupload",
        "Temukan URL file yang diupload — apakah bisa diakses langsung?",
        "Upload file SVG dengan payload XSS di dalamnya",
        "Cek apakah ukuran file dibatasi"
      ]
    });
  }

  // Hidden fields
  const hiddenInputs = inputs.filter(i => i.type === "hidden");
  if (hiddenInputs.length > 0) {
    findings.push({
      severity: "info",
      title: `${hiddenInputs.length} hidden field ditemukan`,
      evidence: `Names: ${hiddenInputs.map(i => i.name).join(", ")}`,
      recommendation: "Hidden fields sering berisi ID, token, atau nilai yang dipakai server. Review apakah nilainya bisa dimanipulasi (mass assignment, IDOR).",
      category: "Form Analysis",
      huntingChecklist: [
        "Intercept request form — coba ubah nilai hidden field",
        "Jika ada ID di hidden field, coba ubah ke ID user lain (IDOR)",
        "Perhatikan apakah ada price/amount di hidden field yang bisa dimanipulasi"
      ]
    });
  }

  // CSRF check heuristic
  const csrfInputs = inputs.filter(i => /csrf|token|_token|nonce/i.test(i.name));
  if (forms.length > 0 && csrfInputs.length === 0 && hasPasswordField) {
    findings.push({
      severity: "medium",
      title: "Form aksi tanpa CSRF token terlihat",
      evidence: `${forms.length} form, tapi tidak ada input CSRF terdeteksi di HTML`,
      recommendation: "Verifikasi manual: intercept request dan coba kirim tanpa/ganti token. Jika server tidak memvalidasi, ini bisa jadi CSRF vulnerability.",
      category: "Form Analysis",
      huntingChecklist: [
        "Intercept request form menggunakan browser DevTools / Burp",
        "Hapus atau ubah nilai token — apakah request masih diterima?",
        "Buat PoC HTML form yang submit ke endpoint dari domain berbeda"
      ]
    });
  }

  return findings;
}

// ─── Redirect Chain Analysis ──────────────────────────────────────────────────

async function checkRedirectChain(target) {
  // Probe with redirect-sensitive parameters
  const probes = [
    { path: "/?redirect=https://evil.com", label: "redirect param" },
    { path: "/?next=https://evil.com",     label: "next param" },
    { path: "/?url=https://evil.com",      label: "url param" },
    { path: "/?return=https://evil.com",   label: "return param" },
    { path: "/?to=https://evil.com",       label: "to param" },
    { path: "/?goto=https://evil.com",     label: "goto param" },
    { path: "/?redir=https://evil.com",    label: "redir param" },
    { path: "/?continue=https://evil.com", label: "continue param" },
    { path: "/?forward=https://evil.com",  label: "forward param" },
  ];
  const results = [];
  for (const probe of probes) {
    await sleep(REQUEST_DELAY);
    const r = await fetchUrl(target, probe.path, { protocol: "https:", method: "GET", maxBytes: 2048, maxRedirects: 0 });
    const loc = r.headers?.location || "";
    if ([301, 302, 303, 307, 308].includes(r.statusCode) && /evil\.com/i.test(loc)) {
      results.push({ path: probe.path, label: probe.label, location: loc, statusCode: r.statusCode });
    }
  }
  return results;
}

// ─── Common sensitive paths ───────────────────────────────────────────────────

const SENSITIVE_PATHS = [
  // ── Config & Secrets ──────────────────────────────────────────────────────
  { path: "/.env",                        label: ".env file",                      severity: "critical" },
  { path: "/.env.local",                  label: ".env.local",                     severity: "critical" },
  { path: "/.env.production",             label: ".env.production",                severity: "critical" },
  { path: "/.env.staging",                label: ".env.staging",                   severity: "critical" },
  { path: "/.env.development",            label: ".env.development",               severity: "high"     },
  { path: "/.env.backup",                 label: ".env.backup",                    severity: "critical" },
  { path: "/.env.example",               label: ".env.example",                   severity: "medium"   },
  { path: "/.env.old",                    label: ".env.old",                       severity: "critical" },
  { path: "/.env.bak",                    label: ".env.bak",                       severity: "critical" },
  { path: "/.env.save",                   label: ".env.save",                      severity: "critical" },
  { path: "/env.js",                      label: "env.js",                         severity: "high"     },
  { path: "/config.json",                 label: "config.json",                    severity: "high"     },
  { path: "/config.yml",                  label: "config.yml",                     severity: "high"     },
  { path: "/config.yaml",                 label: "config.yaml",                    severity: "high"     },
  { path: "/config.php",                  label: "config.php (direct)",            severity: "high"     },
  { path: "/config.xml",                  label: "config.xml",                     severity: "high"     },
  { path: "/configuration.json",          label: "configuration.json",             severity: "high"     },
  { path: "/configuration.php",           label: "configuration.php",              severity: "high"     },
  { path: "/settings.json",               label: "settings.json",                  severity: "high"     },
  { path: "/settings.py",                 label: "settings.py",                    severity: "high"     },
  { path: "/app.config.js",              label: "app.config.js",                  severity: "medium"   },
  { path: "/web.config",                  label: "web.config (IIS config)",        severity: "high"     },
  { path: "/appsettings.json",           label: "appsettings.json (.NET)",        severity: "high"     },
  { path: "/appsettings.production.json",label: "appsettings.production.json",    severity: "critical" },
  { path: "/application.yml",            label: "application.yml (Spring)",       severity: "high"     },
  { path: "/application.properties",     label: "application.properties",         severity: "high"     },
  { path: "/secrets.json",               label: "secrets.json",                   severity: "critical" },
  { path: "/credentials.json",           label: "credentials.json",               severity: "critical" },
  { path: "/keys.json",                  label: "keys.json",                      severity: "critical" },
  { path: "/.htpasswd",                  label: ".htpasswd",                      severity: "critical" },
  { path: "/.htaccess",                  label: ".htaccess",                      severity: "medium"   },
  { path: "/private.key",               label: "private.key",                    severity: "critical" },
  { path: "/server.key",                label: "server.key",                     severity: "critical" },
  { path: "/id_rsa",                    label: "SSH private key",                severity: "critical" },
  { path: "/id_dsa",                    label: "DSA private key",                severity: "critical" },
  { path: "/.ssh/id_rsa",              label: ".ssh/id_rsa",                    severity: "critical" },
  { path: "/serviceaccount.json",       label: "GCP service account JSON",       severity: "critical" },
  { path: "/firebase.json",             label: "firebase.json",                  severity: "high"     },
  { path: "/.firebase",                 label: ".firebase directory",            severity: "medium"   },
  { path: "/google-services.json",      label: "google-services.json",           severity: "high"     },

  // ── Git / VCS ─────────────────────────────────────────────────────────────
  { path: "/.git/config",               label: ".git/config",                    severity: "high"     },
  { path: "/.git/HEAD",                 label: ".git/HEAD",                      severity: "high"     },
  { path: "/.git/index",               label: ".git/index",                     severity: "high"     },
  { path: "/.git/logs/HEAD",           label: ".git/logs/HEAD",                 severity: "medium"   },
  { path: "/.git/COMMIT_EDITMSG",      label: ".git commit message",            severity: "medium"   },
  { path: "/.git/description",         label: ".git/description",               severity: "low"      },
  { path: "/.git/packed-refs",         label: ".git/packed-refs",               severity: "medium"   },
  { path: "/.git/refs/heads/master",   label: ".git master branch ref",         severity: "medium"   },
  { path: "/.git/refs/heads/main",     label: ".git main branch ref",           severity: "medium"   },
  { path: "/.svn/entries",             label: ".svn/entries",                   severity: "high"     },
  { path: "/.svn/wc.db",              label: ".svn/wc.db",                     severity: "high"     },
  { path: "/.hg/hgrc",               label: ".hg/hgrc (Mercurial)",           severity: "high"     },
  { path: "/.bzr/README",             label: ".bzr (Bazaar VCS)",              severity: "medium"   },

  // ── Backup Files ──────────────────────────────────────────────────────────
  { path: "/backup.sql",               label: "SQL dump file",                  severity: "critical" },
  { path: "/dump.sql",                 label: "dump.sql",                       severity: "critical" },
  { path: "/database.sql",             label: "database.sql",                   severity: "critical" },
  { path: "/db.sql",                   label: "db.sql",                         severity: "critical" },
  { path: "/db.sqlite",                label: "SQLite database",                severity: "critical" },
  { path: "/db.sqlite3",               label: "SQLite3 database",               severity: "critical" },
  { path: "/database.sqlite",          label: "database.sqlite",                severity: "critical" },
  { path: "/backup.zip",               label: "backup.zip",                     severity: "critical" },
  { path: "/backup.tar.gz",            label: "backup.tar.gz",                  severity: "critical" },
  { path: "/backup.tar",               label: "backup.tar",                     severity: "critical" },
  { path: "/site.zip",                 label: "site.zip backup",                severity: "critical" },
  { path: "/website.zip",              label: "website.zip backup",             severity: "critical" },
  { path: "/backup",                   label: "backup directory",               severity: "high"     },
  { path: "/backups",                  label: "backups directory",              severity: "high"     },
  { path: "/old",                      label: "old directory",                  severity: "medium"   },
  { path: "/archive",                  label: "archive directory",              severity: "medium"   },
  { path: "/bak",                      label: "bak directory",                  severity: "high"     },
  { path: "/index.php.bak",            label: "index.php.bak",                  severity: "high"     },
  { path: "/index.html.bak",           label: "index.html.bak",                severity: "medium"   },
  { path: "/wp-config.php.bak",        label: "wp-config.php.bak",             severity: "critical" },

  // ── Admin & Debug Panels ──────────────────────────────────────────────────
  { path: "/admin",                    label: "Admin panel /admin",             severity: "high"     },
  { path: "/admin/",                   label: "Admin panel /admin/",            severity: "high"     },
  { path: "/admin.php",                label: "admin.php",                      severity: "high"     },
  { path: "/admin.html",               label: "admin.html",                     severity: "high"     },
  { path: "/admin/login",              label: "Admin login",                    severity: "high"     },
  { path: "/admin/dashboard",          label: "Admin dashboard",                severity: "high"     },
  { path: "/administrator",            label: "/administrator",                 severity: "high"     },
  { path: "/administrator/",           label: "/administrator/",                severity: "high"     },
  { path: "/manager",                  label: "/manager panel",                 severity: "high"     },
  { path: "/panel",                    label: "/panel",                         severity: "high"     },
  { path: "/control",                  label: "/control panel",                 severity: "medium"   },
  { path: "/controlpanel",             label: "/controlpanel",                  severity: "high"     },
  { path: "/cp",                       label: "/cp (control panel)",            severity: "medium"   },
  { path: "/backend",                  label: "/backend",                       severity: "high"     },
  { path: "/backend/",                 label: "/backend/",                      severity: "high"     },
  { path: "/manage",                   label: "/manage",                        severity: "medium"   },
  { path: "/management",               label: "/management",                    severity: "medium"   },
  { path: "/dashboard",                label: "/dashboard",                     severity: "medium"   },
  { path: "/superadmin",               label: "/superadmin",                    severity: "critical" },
  { path: "/root",                     label: "/root",                          severity: "high"     },
  { path: "/debug",                    label: "/debug endpoint",                severity: "high"     },
  { path: "/debug/",                   label: "/debug/",                        severity: "high"     },
  { path: "/_debug",                   label: "/_debug",                        severity: "high"     },
  { path: "/__debug",                  label: "/__debug",                       severity: "high"     },
  { path: "/console",                  label: "/console",                       severity: "high"     },
  { path: "/server-status",            label: "Apache /server-status",          severity: "high"     },
  { path: "/server-info",              label: "Apache /server-info",            severity: "high"     },

  // ── Framework Admin & Debug ───────────────────────────────────────────────
  { path: "/actuator",                 label: "Spring Actuator root",           severity: "high"     },
  { path: "/actuator/env",             label: "Spring Actuator /env",           severity: "critical" },
  { path: "/actuator/health",          label: "Spring Actuator /health",        severity: "low"      },
  { path: "/actuator/beans",           label: "Spring Actuator /beans",         severity: "high"     },
  { path: "/actuator/mappings",        label: "Spring Actuator /mappings",      severity: "high"     },
  { path: "/actuator/httptrace",       label: "Spring Actuator /httptrace",     severity: "high"     },
  { path: "/actuator/heapdump",        label: "Spring Actuator /heapdump",      severity: "critical" },
  { path: "/actuator/threaddump",      label: "Spring Actuator /threaddump",    severity: "high"     },
  { path: "/actuator/loggers",         label: "Spring Actuator /loggers",       severity: "medium"   },
  { path: "/telescope",                label: "Laravel Telescope",              severity: "high"     },
  { path: "/telescope/requests",       label: "Laravel Telescope requests",     severity: "critical" },
  { path: "/horizon",                  label: "Laravel Horizon",                severity: "high"     },
  { path: "/_debugbar",                label: "Laravel Debugbar",               severity: "high"     },
  { path: "/debugbar",                 label: "/debugbar",                      severity: "high"     },
  { path: "/__clockwork",              label: "Clockwork debugger",             severity: "high"     },
  { path: "/clockwork",                label: "/clockwork",                     severity: "high"     },
  { path: "/profiler",                 label: "/profiler (Symfony)",            severity: "high"     },
  { path: "/_profiler",                label: "/_profiler (Symfony)",           severity: "high"     },
  { path: "/rails/info",               label: "Rails /rails/info",              severity: "high"     },
  { path: "/rails/info/properties",    label: "Rails /rails/info/properties",   severity: "high"     },
  { path: "/metrics",                  label: "/metrics endpoint",              severity: "medium"   },
  { path: "/metrics/",                 label: "/metrics/",                      severity: "medium"   },
  { path: "/health",                   label: "/health check",                  severity: "info"     },
  { path: "/healthz",                  label: "/healthz",                       severity: "info"     },
  { path: "/readyz",                   label: "/readyz",                        severity: "info"     },
  { path: "/status",                   label: "/status",                        severity: "info"     },

  // ── Database Admin ────────────────────────────────────────────────────────
  { path: "/phpmyadmin",               label: "phpMyAdmin",                     severity: "critical" },
  { path: "/phpmyadmin/",              label: "phpMyAdmin /",                   severity: "critical" },
  { path: "/pma",                      label: "phpMyAdmin alias /pma",          severity: "critical" },
  { path: "/PMA",                      label: "phpMyAdmin /PMA",                severity: "critical" },
  { path: "/myadmin",                  label: "/myadmin",                       severity: "critical" },
  { path: "/mysql",                    label: "/mysql",                         severity: "high"     },
  { path: "/mysqladmin",               label: "/mysqladmin",                    severity: "critical" },
  { path: "/adminer.php",              label: "Adminer DB UI",                  severity: "critical" },
  { path: "/adminer",                  label: "Adminer (path)",                 severity: "critical" },
  { path: "/db",                       label: "/db endpoint",                   severity: "high"     },
  { path: "/redis",                    label: "Redis UI",                       severity: "critical" },
  { path: "/mongo",                    label: "MongoDB express",                severity: "critical" },
  { path: "/mongoexpress",             label: "mongo-express UI",               severity: "critical" },
  { path: "/pgadmin",                  label: "pgAdmin",                        severity: "critical" },
  { path: "/kibana",                   label: "Kibana UI",                      severity: "high"     },
  { path: "/elasticsearch",            label: "Elasticsearch API",              severity: "critical" },
  { path: "/solr",                     label: "Solr Admin UI",                  severity: "high"     },
  { path: "/neo4j",                    label: "Neo4j browser",                  severity: "high"     },

  // ── DevOps & CI/CD ────────────────────────────────────────────────────────
  { path: "/jenkins",                  label: "Jenkins CI",                     severity: "critical" },
  { path: "/jenkins/",                 label: "Jenkins CI /",                   severity: "critical" },
  { path: "/gitlab",                   label: "GitLab instance",                severity: "high"     },
  { path: "/grafana",                  label: "Grafana dashboard",              severity: "high"     },
  { path: "/prometheus",               label: "Prometheus",                     severity: "high"     },
  { path: "/portainer",                label: "Portainer (Docker UI)",          severity: "critical" },
  { path: "/rancher",                  label: "Rancher UI",                     severity: "critical" },
  { path: "/sonar",                    label: "SonarQube",                      severity: "high"     },
  { path: "/sonarqube",                label: "SonarQube",                      severity: "high"     },
  { path: "/nexus",                    label: "Nexus Repository",               severity: "high"     },
  { path: "/artifactory",              label: "Artifactory",                    severity: "high"     },
  { path: "/drone",                    label: "Drone CI",                       severity: "high"     },
  { path: "/travis",                   label: "Travis CI local",                severity: "high"     },
  { path: "/docker",                   label: "Docker Registry API",            severity: "critical" },
  { path: "/v2/",                      label: "Docker Registry API /v2/",       severity: "high"     },
  { path: "/kubernetes",               label: "Kubernetes dashboard",           severity: "critical" },
  { path: "/k8s",                      label: "Kubernetes shortpath",           severity: "critical" },
  { path: "/etcd",                     label: "etcd cluster UI",                severity: "critical" },

  // ── API Documentation ─────────────────────────────────────────────────────
  { path: "/swagger",                  label: "Swagger UI",                     severity: "medium"   },
  { path: "/swagger/",                 label: "Swagger UI /",                   severity: "medium"   },
  { path: "/swagger-ui.html",          label: "Swagger UI (HTML)",              severity: "medium"   },
  { path: "/swagger-ui",               label: "Swagger UI path",                severity: "medium"   },
  { path: "/swagger.json",             label: "swagger.json schema",            severity: "high"     },
  { path: "/swagger.yaml",             label: "swagger.yaml schema",            severity: "high"     },
  { path: "/openapi.json",             label: "OpenAPI JSON schema",            severity: "high"     },
  { path: "/openapi.yaml",             label: "OpenAPI YAML schema",            severity: "high"     },
  { path: "/openapi/v3",               label: "OpenAPI v3",                     severity: "medium"   },
  { path: "/api-docs",                 label: "API docs",                       severity: "medium"   },
  { path: "/api/docs",                 label: "API /api/docs",                  severity: "medium"   },
  { path: "/api/swagger",              label: "API Swagger",                    severity: "medium"   },
  { path: "/api/schema",               label: "API schema",                     severity: "medium"   },
  { path: "/api/spec",                 label: "API spec",                       severity: "medium"   },
  { path: "/v1/api-docs",              label: "v1 API docs",                    severity: "medium"   },
  { path: "/v2/api-docs",              label: "v2 API docs",                    severity: "medium"   },
  { path: "/docs",                     label: "/docs",                          severity: "info"     },
  { path: "/api/redoc",                label: "ReDoc API UI",                   severity: "medium"   },
  { path: "/redoc",                    label: "ReDoc",                          severity: "medium"   },

  // ── GraphQL ───────────────────────────────────────────────────────────────
  { path: "/graphql",                  label: "GraphQL endpoint",               severity: "medium"   },
  { path: "/graphql/",                 label: "GraphQL /",                      severity: "medium"   },
  { path: "/api/graphql",              label: "GraphQL at /api/graphql",        severity: "medium"   },
  { path: "/graphiql",                 label: "GraphiQL IDE",                   severity: "high"     },
  { path: "/graphql/console",          label: "GraphQL Console",                severity: "high"     },
  { path: "/graphql-playground",       label: "GraphQL Playground",             severity: "high"     },
  { path: "/playground",               label: "GraphQL Playground /playground", severity: "high"     },
  { path: "/voyager",                  label: "GraphQL Voyager",                severity: "medium"   },

  // ── API Endpoints ─────────────────────────────────────────────────────────
  { path: "/api",                      label: "API root",                       severity: "info"     },
  { path: "/api/v1",                   label: "API v1",                         severity: "info"     },
  { path: "/api/v2",                   label: "API v2",                         severity: "info"     },
  { path: "/api/v3",                   label: "API v3",                         severity: "info"     },
  { path: "/api/v1/users",             label: "Users API endpoint",             severity: "medium"   },
  { path: "/api/v1/admin",             label: "Admin API v1",                   severity: "high"     },
  { path: "/api/admin",                label: "Admin API",                      severity: "high"     },
  { path: "/api/internal",             label: "Internal API",                   severity: "high"     },
  { path: "/api/private",              label: "Private API",                    severity: "high"     },
  { path: "/api/debug",                label: "Debug API",                      severity: "high"     },
  { path: "/api/test",                 label: "Test API",                       severity: "medium"   },
  { path: "/api/user",                 label: "User API",                       severity: "medium"   },
  { path: "/api/users",                label: "Users list API",                 severity: "medium"   },
  { path: "/api/me",                   label: "Current user API /me",           severity: "medium"   },
  { path: "/api/config",               label: "Config API",                     severity: "high"     },
  { path: "/api/settings",             label: "Settings API",                   severity: "medium"   },
  { path: "/api/health",               label: "Health API",                     severity: "info"     },
  { path: "/internal",                 label: "/internal endpoint",             severity: "high"     },
  { path: "/private",                  label: "/private",                       severity: "high"     },
  { path: "/secret",                   label: "/secret",                        severity: "critical" },
  { path: "/hidden",                   label: "/hidden",                        severity: "high"     },
  { path: "/test",                     label: "/test endpoint",                 severity: "medium"   },
  { path: "/dev",                      label: "/dev endpoint",                  severity: "high"     },
  { path: "/staging",                  label: "/staging",                       severity: "high"     },

  // ── WordPress ─────────────────────────────────────────────────────────────
  { path: "/wp-admin",                 label: "WordPress /wp-admin",            severity: "high"     },
  { path: "/wp-admin/",               label: "WordPress /wp-admin/",            severity: "high"     },
  { path: "/wp-login.php",             label: "WordPress login",                severity: "high"     },
  { path: "/wp-config.php",            label: "wp-config.php (DB credentials)", severity: "critical" },
  { path: "/xmlrpc.php",               label: "WordPress XML-RPC",              severity: "high"     },
  { path: "/wp-json/wp/v2/users",      label: "WP REST API users enum",         severity: "high"     },
  { path: "/wp-json/",                 label: "WordPress REST API root",        severity: "medium"   },
  { path: "/wp-content/debug.log",     label: "WordPress debug.log",            severity: "critical" },
  { path: "/?author=1",               label: "WordPress user enum (?author=1)", severity: "medium"   },
  { path: "/wp-content/uploads/",     label: "WordPress uploads directory",    severity: "medium"   },

  // ── Logs & Reports ────────────────────────────────────────────────────────
  { path: "/logs",                     label: "Logs directory",                 severity: "high"     },
  { path: "/log",                      label: "Log file/directory",             severity: "high"     },
  { path: "/error.log",                label: "error.log",                      severity: "critical" },
  { path: "/access.log",               label: "access.log",                     severity: "critical" },
  { path: "/app.log",                  label: "app.log",                        severity: "high"     },
  { path: "/debug.log",                label: "debug.log",                      severity: "high"     },
  { path: "/laravel.log",              label: "Laravel laravel.log",            severity: "critical" },
  { path: "/storage/logs/laravel.log", label: "Laravel storage/logs",           severity: "critical" },
  { path: "/application.log",          label: "application.log",                severity: "high"     },
  { path: "/server.log",               label: "server.log",                     severity: "high"     },
  { path: "/php_error.log",            label: "PHP error log",                  severity: "high"     },
  { path: "/php-error.log",            label: "PHP error log (dash)",           severity: "high"     },
  { path: "/error_log",               label: "error_log",                      severity: "high"     },
  { path: "/report",                   label: "/report directory",              severity: "medium"   },
  { path: "/reports",                  label: "/reports directory",             severity: "medium"   },

  // ── Package & Build Files ─────────────────────────────────────────────────
  { path: "/package.json",             label: "package.json (dep versions)",    severity: "medium"   },
  { path: "/package-lock.json",        label: "package-lock.json",              severity: "low"      },
  { path: "/composer.json",            label: "composer.json (PHP deps)",       severity: "medium"   },
  { path: "/composer.lock",            label: "composer.lock",                  severity: "low"      },
  { path: "/Gemfile",                  label: "Gemfile (Ruby)",                 severity: "medium"   },
  { path: "/Gemfile.lock",             label: "Gemfile.lock",                   severity: "low"      },
  { path: "/requirements.txt",         label: "requirements.txt (Python)",      severity: "medium"   },
  { path: "/yarn.lock",                label: "yarn.lock",                      severity: "low"      },
  { path: "/Pipfile",                  label: "Pipfile",                        severity: "low"      },
  { path: "/pom.xml",                  label: "pom.xml (Maven)",                severity: "medium"   },
  { path: "/build.gradle",             label: "build.gradle",                   severity: "medium"   },
  { path: "/Dockerfile",               label: "Dockerfile",                     severity: "high"     },
  { path: "/docker-compose.yml",       label: "docker-compose.yml",             severity: "high"     },
  { path: "/docker-compose.yaml",      label: "docker-compose.yaml",            severity: "high"     },
  { path: "/.dockerenv",               label: ".dockerenv (container detect)",  severity: "low"      },
  { path: "/Makefile",                 label: "Makefile",                       severity: "medium"   },
  { path: "/.github/workflows",        label: "GitHub Actions workflows",       severity: "medium"   },
  { path: "/.travis.yml",              label: ".travis.yml (CI config)",        severity: "medium"   },
  { path: "/.circleci/config.yml",     label: "CircleCI config",                severity: "medium"   },
  { path: "/Jenkinsfile",              label: "Jenkinsfile",                    severity: "medium"   },
  { path: "/.gitlab-ci.yml",           label: "GitLab CI config",               severity: "medium"   },
  { path: "/terraform.tfstate",        label: "Terraform state (has secrets!)", severity: "critical" },
  { path: "/terraform.tfvars",         label: "Terraform vars",                 severity: "critical" },
  { path: "/ansible.cfg",             label: "Ansible config",                 severity: "high"     },

  // ── Source Map / Code Disclosure ──────────────────────────────────────────
  { path: "/app.js.map",               label: "Source map app.js.map",          severity: "high"     },
  { path: "/main.js.map",              label: "Source map main.js.map",         severity: "high"     },
  { path: "/bundle.js.map",            label: "Source map bundle.js.map",       severity: "high"     },
  { path: "/vendor.js.map",            label: "Source map vendor.js.map",       severity: "medium"   },
  { path: "/index.js.map",             label: "Source map index.js.map",        severity: "medium"   },
  { path: "/static/js/main.chunk.js.map", label: "React main chunk source map",severity: "high"     },

  // ── Info Files ────────────────────────────────────────────────────────────
  { path: "/robots.txt",               label: "robots.txt (path disclosure)",   severity: "info"     },
  { path: "/sitemap.xml",              label: "sitemap.xml",                    severity: "info"     },
  { path: "/crossdomain.xml",          label: "crossdomain.xml",                severity: "low"      },
  { path: "/clientaccesspolicy.xml",   label: "clientaccesspolicy.xml",         severity: "low"      },
  { path: "/.well-known/security.txt", label: "security.txt",                   severity: "info"     },
  { path: "/.well-known/change-password", label: "Change password URL",         severity: "info"     },
  { path: "/security.txt",             label: "security.txt (root)",            severity: "info"     },
  { path: "/humans.txt",               label: "humans.txt",                     severity: "info"     },
  { path: "/CHANGELOG.md",             label: "CHANGELOG.md (version leak)",    severity: "low"      },
  { path: "/CHANGELOG",               label: "CHANGELOG",                      severity: "low"      },
  { path: "/VERSION",                  label: "VERSION file",                   severity: "low"      },
  { path: "/README.md",               label: "README.md",                      severity: "low"      },
  { path: "/LICENSE",                  label: "LICENSE file",                   severity: "info"     },

  // ── Cloud / CDN ───────────────────────────────────────────────────────────
  { path: "/.aws/credentials",         label: "AWS credentials file",           severity: "critical" },
  { path: "/.aws/config",              label: "AWS config file",                severity: "high"     },
  { path: "/aws.json",                 label: "aws.json",                       severity: "critical" },
  { path: "/s3.json",                  label: "s3.json",                        severity: "high"     },
  { path: "/cloud.json",               label: "cloud.json",                     severity: "high"     },
  { path: "/.gcp",                     label: "GCP config",                     severity: "high"     },
  { path: "/azure.json",               label: "azure.json",                     severity: "high"     },

  // ── CMS & Ecommerce ───────────────────────────────────────────────────────
  { path: "/typo3",                    label: "TYPO3 backend",                  severity: "high"     },
  { path: "/typo3/",                   label: "TYPO3 backend /",                severity: "high"     },
  { path: "/joomla",                   label: "Joomla admin",                   severity: "high"     },
  { path: "/administrator/index.php",  label: "Joomla administrator",           severity: "high"     },
  { path: "/drupal",                   label: "Drupal path",                    severity: "medium"   },
  { path: "/user/login",               label: "Drupal user login",              severity: "medium"   },
  { path: "/?q=user/login",            label: "Drupal user/login (old)",        severity: "medium"   },
  { path: "/magento",                  label: "Magento admin",                  severity: "high"     },
  { path: "/index.php/admin",          label: "Admin via index.php",            severity: "high"     },
  { path: "/shop/admin",               label: "Shop admin",                     severity: "high"     },

  // ── Security & Monitoring ─────────────────────────────────────────────────
  { path: "/sentry",                   label: "Sentry DSN exposure",            severity: "high"     },
  { path: "/bugsnag",                  label: "Bugsnag config",                 severity: "medium"   },
  { path: "/newrelic",                 label: "New Relic config",               severity: "medium"   },
  { path: "/datadog",                  label: "Datadog config",                 severity: "medium"   },
  { path: "/logstash",                 label: "Logstash API",                   severity: "high"     },
  { path: "/jaeger",                   label: "Jaeger tracing UI",              severity: "high"     },
  { path: "/zipkin",                   label: "Zipkin tracing UI",              severity: "high"     },
];;

async function checkSensitivePaths(target, maxPaths = 305, protocol = "https:", baselineBody = "") {
  const hits = [];
  const seenBodies = new Set();
  const paths = SENSITIVE_PATHS.slice(0, maxPaths);
  const CONCURRENCY = 10; // 10 parallel requests
  const TIMEOUT_PER_REQ = 6000;

  // Process in batches of CONCURRENCY
  for (let i = 0; i < paths.length; i += CONCURRENCY) {
    const batch = paths.slice(i, i + CONCURRENCY);
    const results = await Promise.allSettled(
      batch.map(item =>
        fetchUrl(target, item.path, { protocol, method: "GET", maxBytes: 8192, maxRedirects: 0, timeout: TIMEOUT_PER_REQ })
          .then(r => ({ item, r }))
          .catch(() => null)
      )
    );

    for (const res of results) {
      if (res.status !== "fulfilled" || !res.value) continue;
      const { item, r } = res.value;
      const body = r.body || "";

      if (r.statusCode === 200) {
        if (body && baselineBody && baselineBody.startsWith(body)) continue;
        // Filter out: same-as-homepage (soft 404), empty, or obvious redirect pages
        const isHomepage = body.length > 500 && /<!DOCTYPE html>|<html/i.test(body) &&
          !/(repositoryformatversion|DB_HOST|APP_KEY|SECRET|TOKEN|PASSWORD|PRIVATE_KEY|BEGIN RSA|BEGIN EC|\[mysqld\]|\[client\]|Index of \/)/i.test(body) &&
          !/(swagger|openapi|graphql|actuator|phpmyadmin|adminer|jenkins|kibana)/i.test(item.path);

        if (!isHomepage) {
          // Extra signal: body contains sensitive keywords = real hit
          const hasSensitiveContent = /(DB_HOST|DB_PASS|APP_KEY|SECRET_KEY|API_KEY|PASSWORD|PRIVATE_KEY|BEGIN RSA|BEGIN EC PRIVATE|\[mysqld\]|repositoryformatversion|"swagger"|"openapi"|"graphql"|actuator|Index of \/)/i.test(body);
          const isKnownSensitivePath = /\.env|\.git|phpmyadmin|adminer|actuator|telescope|horizon|swagger|openapi|graphql|backup\.sql|dump\.sql|\.sqlite|id_rsa|\.(key|pem)|terraform|docker-compose|credentials\.json/i.test(item.path);

          if (hasSensitiveContent || isKnownSensitivePath || body.length < 500) {
            const bodyKey = `${body.length}:${body}`;
            if (seenBodies.has(bodyKey)) continue;
            seenBodies.add(bodyKey);
            hits.push({ ...item, statusCode: r.statusCode, bodyPreview: redact(body.slice(0, 300)), bodyLength: body.length });
          }
        }
      }
    }
    // Small delay between batches to avoid overwhelming server
    if (i + CONCURRENCY < paths.length) await sleep(200);
  }
  return hits;
}

// ─── Version / Tech Disclosure ────────────────────────────────────────────────

function analyzeVersionDisclosure(headers, body, tlsInfo) {
  const findings = [];

  // Server header version
  const server = headers.server || "";
  const versionMatch = /(\d+\.\d+[\.\d]*)/.exec(server);
  if (server && versionMatch) {
    findings.push({
      severity: "info",
      title: "Versi server terekspos di header",
      evidence: `Server: ${server}`,
      recommendation: "Hapus nomor versi dari header Server. Versi yang diketahui bisa dicocokkan ke CVE database.",
      category: "Version Disclosure"
    });
  }

  // X-Powered-By with version
  const poweredBy = headers["x-powered-by"] || "";
  if (poweredBy) {
    findings.push({
      severity: "info",
      title: "Teknologi backend terekspos (X-Powered-By)",
      evidence: `X-Powered-By: ${poweredBy}`,
      recommendation: "Hapus header X-Powered-By.",
      category: "Version Disclosure"
    });
  }

  // X-AspNet-Version
  if (headers["x-aspnet-version"] || headers["x-aspnetmvc-version"]) {
    findings.push({
      severity: "low",
      title: "Versi ASP.NET terekspos",
      evidence: `X-AspNet-Version: ${headers["x-aspnet-version"] || headers["x-aspnetmvc-version"]}`,
      recommendation: "Set <httpRuntime enableVersionHeader='false'> di web.config.",
      category: "Version Disclosure"
    });
  }

  // PHP version via content-type or body
  if (/PHP\/\d+\.\d+/i.test(server) || /PHP\/\d+\.\d+/i.test(body.slice(0, 500))) {
    findings.push({
      severity: "low",
      title: "Versi PHP terekspos",
      evidence: (server.match(/PHP\/[\d.]+/) || body.match(/PHP\/[\d.]+/) || [""])[0],
      recommendation: "Set expose_php = Off di php.ini.",
      category: "Version Disclosure"
    });
  }

  // TLS weak protocol
  if (tlsInfo?.weakProtocol) {
    findings.push({
      severity: "high",
      title: `Protokol TLS lemah digunakan: ${tlsInfo.protocol}`,
      evidence: `Protokol: ${tlsInfo.protocol}`,
      recommendation: "Nonaktifkan TLS 1.0 dan TLS 1.1. Gunakan TLS 1.2+ saja.",
      category: "TLS"
    });
  }

  // Self-signed cert
  if (tlsInfo?.certificate?.selfSigned) {
    findings.push({
      severity: "medium",
      title: "Sertifikat self-signed terdeteksi",
      evidence: `Issuer: ${JSON.stringify(tlsInfo.certificate.issuer)}`,
      recommendation: "Gunakan sertifikat dari CA tepercaya (Let's Encrypt, dll).",
      category: "TLS"
    });
  }

  return findings;
}

// ─── CORS Deep Check ──────────────────────────────────────────────────────────

async function checkCorsDeep(target, protocol = "https:") {
  const probes = [
    { origin: "https://attacker.com",                    label: "external origin" },
    { origin: `https://evil.${target.hostname}`,          label: "subdomain of target" },
    { origin: `https://${target.hostname}.attacker.com`,  label: "target-prefix attacker" },
    { origin: "null",                                     label: "null origin" },
    { origin: "https://attacker.com",                     label: "API path", path: "/api" },
    { origin: "https://attacker.com",                     label: "API v1", path: "/api/v1" },
  ];
  const results = await Promise.allSettled(
    probes.map(probe =>
      fetchUrl(target, probe.path || "/", {
        protocol: "https:", method: "GET", maxBytes: 2048, maxRedirects: 0,
        headers: { Origin: probe.origin }, timeout: 6000
      }).then(r => ({ probe, r })).catch(() => null)
    )
  );
  const findings = [];
  for (const res of results) {
    if (res.status !== "fulfilled" || !res.value) continue;
    const { probe, r } = res.value;
    const acao = r.headers?.["access-control-allow-origin"] || "";
    const acac = r.headers?.["access-control-allow-credentials"] || "";
    if (acao && (acao === probe.origin || acao === "*" || acao === "null")) {
      findings.push({
        probe: probe.label, origin: probe.origin, acao, acac,
        path: probe.path || "/", withCredentials: /true/i.test(acac)
      });
    }
  }
  return findings;
}

// ─── WAF / CDN Detection ─────────────────────────────────────────────────────

function detectWafCdn(headers, body) {
  const h = headers || {};
  const b = (body || "").toLowerCase();
  const detections = [];

  const signatures = [
    // CDNs
    { name: "Cloudflare",    keys: ["cf-ray","cf-cache-status","cf-request-id"], headerVal: {} },
    { name: "Akamai",        keys: ["x-check-cacheable","x-akamai-transformed","akamai-origin-hop"], headerVal: {} },
    { name: "Fastly",        keys: ["x-fastly-request-id","fastly-io-info"], headerVal: {} },
    { name: "Varnish",       keys: ["x-varnish","x-varnish-cache"], headerVal: {} },
    { name: "AWS CloudFront",keys: ["x-amz-cf-id","x-amz-cf-pop"], headerVal: {} },
    { name: "Azure CDN",     keys: ["x-azure-ref"], headerVal: {} },
    { name: "Vercel",        keys: ["x-vercel-id","x-vercel-cache"], headerVal: {} },
    { name: "Netlify",       keys: ["x-nf-request-id","netlify-cache-control"], headerVal: {} },
    { name: "BunnyCDN",      keys: ["cdn-pullzone","cdn-requestid"], headerVal: {} },
    { name: "Sucuri WAF",    keys: ["x-sucuri-id","x-sucuri-cache"], headerVal: {} },
    // WAFs
    { name: "ModSecurity",   keys: [], headerVal: { server: /mod_security/i } },
    { name: "Imperva",       keys: ["x-iinfo","x-cdn"], headerVal: { "set-cookie": /incap_ses|visid_incap/i } },
    { name: "F5 BIG-IP",     keys: ["x-cnection"], headerVal: { "set-cookie": /BIGipServer/i } },
    { name: "Barracuda WAF", keys: [], headerVal: { "set-cookie": /barra_counter_session/i } },
    { name: "AWS WAF",       keys: ["x-amzn-requestid","x-amzn-trace-id"], headerVal: {} },
    { name: "Nginx",         keys: [], headerVal: { server: /nginx/i } },
    { name: "Apache",        keys: [], headerVal: { server: /apache/i } },
    { name: "Caddy",         keys: [], headerVal: { server: /caddy/i } },
    { name: "IIS",           keys: [], headerVal: { server: /iis|microsoft-iis/i } },
    { name: "LiteSpeed",     keys: ["x-litespeed-cache"], headerVal: { server: /litespeed/i } },
  ];

  for (const sig of signatures) {
    let found = false;
    for (const key of sig.keys) {
      if (h[key] !== undefined) { found = true; break; }
    }
    if (!found) {
      for (const [key, re] of Object.entries(sig.headerVal)) {
        if (h[key] && re.test(h[key])) { found = true; break; }
      }
    }
    if (found) detections.push(sig.name);
  }

  // Cache headers analysis
  const cacheControl = h["cache-control"] || "";
  const xCache       = h["x-cache"] || h["x-cache-status"] || h["cf-cache-status"] || "";
  const vary         = h["vary"] || "";
  const age          = h["age"];
  const etag         = h["etag"] || "";

  return { detections: [...new Set(detections)], cacheControl, xCache, vary, age, etag };
}

// ─── HTTP Method Enumeration (OPTIONS) ───────────────────────────────────────

async function checkHttpMethods(target) {
  await sleep(REQUEST_DELAY);
  const r = await fetchUrl(target, "/", { protocol: "https:", method: "OPTIONS", maxBytes: 1024, maxRedirects: 0 });
  const allowed = r.headers?.["allow"] || r.headers?.["access-control-allow-methods"] || "";
  const publicMethods = [];
  if (/TRACE/i.test(allowed))  publicMethods.push("TRACE");
  if (/PUT/i.test(allowed))    publicMethods.push("PUT");
  if (/DELETE/i.test(allowed)) publicMethods.push("DELETE");
  if (/CONNECT/i.test(allowed))publicMethods.push("CONNECT");
  return { statusCode: r.statusCode, allowed, dangerousMethods: publicMethods };
}

// ─── Subdomain Enumeration (passive DNS only) ─────────────────────────────────

const COMMON_SUBDOMAINS = [
  "www","api","mail","smtp","ftp","dev","staging","test","qa","uat",
  "admin","dashboard","portal","app","mobile","m","static","assets","cdn",
  "img","images","media","upload","uploads","files","docs","help","support",
  "blog","shop","store","payment","pay","checkout","auth","login","sso",
  "vpn","remote","webmail","jenkins","gitlab","github","jira","confluence",
  "kibana","grafana","prometheus","sentry","status","monitor","metrics",
  "db","database","mysql","redis","mongo","postgres","es","elastic","solr",
  "s3","backup","old","legacy","v1","v2","beta","alpha","sandbox","internal",
  "intranet","corp","employee","hr","crm","erp","inventory","api2","ws",
];

async function enumerateSubdomains(hostname) {
  // Only probe apex domain subdomains
  const parts = hostname.split(".");
  if (parts.length < 2) return [];
  const apex = parts.slice(-2).join(".");
  const results = [];

  // Batch DNS lookups
  const checks = COMMON_SUBDOMAINS.map(sub => {
    const fqdn = `${sub}.${apex}`;
    if (fqdn === hostname) return null; // skip self
    return { sub, fqdn };
  }).filter(Boolean);

  for (const { sub, fqdn } of checks) {
    try {
      const addrs = await dns.resolve4(fqdn);
      if (addrs.length) {
        const isPublic = addrs.some(isPublicIpv4);
        results.push({ subdomain: fqdn, sub, ips: addrs, isPublic });
      }
    } catch { /* NXDOMAIN - normal */ }
    await sleep(80); // lighter delay for DNS
  }
  return results;
}

// ─── Certificate Transparency (crt.sh passive) ───────────────────────────────

async function queryCertTransparency(hostname) {
  // Query crt.sh JSON API - fully passive, no scanning
  const apex = hostname.split(".").slice(-2).join(".");
  return new Promise(resolve => {
    const req = https.request({
      hostname: "crt.sh",
      path: `/?q=%.${encodeURIComponent(apex)}&output=json`,
      method: "GET",
      headers: { "User-Agent": USER_AGENT, Accept: "application/json" },
      timeout: 12000,
      rejectUnauthorized: true
    }, res => {
      const chunks = [];
      let bytes = 0;
      res.on("data", c => { bytes += c.length; if (bytes < 200000) chunks.push(c); });
      res.on("end", () => {
        try {
          const data = JSON.parse(Buffer.concat(chunks).toString("utf8"));
          const names = new Set();
          for (const entry of (Array.isArray(data) ? data : [])) {
            const cn = entry.common_name || "";
            const ni = entry.name_value  || "";
            for (const n of [cn, ...ni.split("\n")]) {
              const clean = n.trim().toLowerCase().replace(/^\*\./, "");
              if (clean.endsWith(`.${apex}`) || clean === apex) names.add(clean);
            }
          }
          resolve([...names].slice(0, 80));
        } catch { resolve([]); }
      });
      res.on("error", () => resolve([]));
    });
    req.on("timeout", () => { req.destroy(); resolve([]); });
    req.on("error",   () => resolve([]));
    req.end();
  });
}

// ─── Subdomain Takeover Detection ─────────────────────────────────────────────

const TAKEOVER_SIGNATURES = [
  { service: "GitHub Pages",      re: /there isn't a github pages site here/i },
  { service: "Heroku",            re: /no such app|herokucdn\.com.*app not found/i },
  { service: "Shopify",           re: /sorry, this shop is currently unavailable/i },
  { service: "Fastly",            re: /fastly error: unknown domain/i },
  { service: "Ghost",             re: /the thing you were looking for is no longer here/i },
  { service: "Pantheon",          re: /the site you are looking for couldn't be found/i },
  { service: "Surge.sh",          re: /project not found/i },
  { service: "Bitbucket",         re: /repository not found|pull requests .* bitbucket/i },
  { service: "Amazon S3",         re: /nosuchbucket|the specified bucket does not exist/i },
  { service: "Azure",             re: /404 web site not found.*azure/i },
  { service: "Tumblr",            re: /whatever you were looking for doesn.*t live here/i },
  { service: "WordPress.com",     re: /do you want to register/i },
  { service: "Helpjuice",         re: /we could not find what you.re looking for/i },
  { service: "HelpScout",         re: /no settings were found for this company/i },
  { service: "Zendesk",           re: /help center closed/i },
  { service: "UserVoice",         re: /this uservoice subdomain is currently available/i },
  { service: "Intercom",          re: /this page is reserved for artistic*|uh oh. that page doesn't exist/i },
  { service: "Unbounce",          re: /the requested url was not found on this server.*unbounce/i },
  { service: "Strikingly",        re: /this domain is available on strikingly/i },
  { service: "Pingdom",           re: /public report not available/i },
  { service: "Campaign Monitor",  re: /double check the url or try searching/i },
];

async function checkSubdomainTakeover(subdomains) {
  const vulnerable = [];
  for (const { subdomain, ips } of subdomains.slice(0, 20)) {
    await sleep(200);
    try {
      // Check CNAME for classic takeover pattern
      let cname = "";
      try { const cnames = await dns.resolveCname(subdomain); cname = cnames[0] || ""; } catch {}

      const r = await new Promise(resolve => {
        const req = https.request({
          hostname: subdomain, path: "/", method: "GET",
          headers: { "User-Agent": USER_AGENT }, timeout: 6000, rejectUnauthorized: false
        }, res => {
          const chunks = [];
          res.on("data", c => chunks.push(c));
          res.on("end", () => resolve({ statusCode: res.statusCode, body: Buffer.concat(chunks).toString("utf8").slice(0, 3000) }));
          res.on("error", () => resolve({ statusCode: 0, body: "" }));
        });
        req.on("timeout", () => { req.destroy(); resolve({ statusCode: 0, body: "" }); });
        req.on("error",   () => resolve({ statusCode: 0, body: "" }));
        req.end();
      });

      for (const sig of TAKEOVER_SIGNATURES) {
        if (sig.re.test(r.body)) {
          vulnerable.push({ subdomain, cname, service: sig.service, statusCode: r.statusCode });
          break;
        }
      }
    } catch { /* continue */ }
  }
  return vulnerable;
}

// ─── Cache / CDN Poisoning Surface ───────────────────────────────────────────

async function checkCacheSurface(target) {
  const probes = [
    // Host header injection
    { headers: { Host: `${target.hostname}.attacker.com` }, label: "Host header injection" },
    // X-Forwarded-Host
    { headers: { "X-Forwarded-Host": "attacker.com" }, label: "X-Forwarded-Host injection" },
    // X-Original-URL path override
    { headers: { "X-Original-URL": "/admin" }, label: "X-Original-URL override" },
    // X-Rewrite-URL
    { headers: { "X-Rewrite-URL": "/admin" }, label: "X-Rewrite-URL override" },
    // X-Forwarded-For
    { headers: { "X-Forwarded-For": "127.0.0.1" }, label: "X-Forwarded-For: 127.0.0.1" },
  ];

  const findings = [];
  for (const probe of probes) {
    await sleep(REQUEST_DELAY);
    const r = await fetchUrl(target, "/", {
      protocol: "https:", method: "GET", maxBytes: 4096, maxRedirects: 0,
      headers: probe.headers
    });
    // Look for reflection of injected header in response body or Location
    const body = r.body || "";
    const loc  = r.headers?.location || "";
    if (/attacker\.com/i.test(body) || /attacker\.com/i.test(loc)) {
      findings.push({ label: probe.label, evidence: `Injected value reflected in response`, statusCode: r.statusCode });
    }
  }
  return findings;
}

// ─── API Version Probe ────────────────────────────────────────────────────────

async function probeApiVersions(target, protocol = "https:") {
  const paths = [
    "/api", "/api/v1", "/api/v2", "/api/v3", "/api/v4",
    "/v1", "/v2", "/v3",
    "/graphql", "/graphiql", "/graph",
    "/rest", "/rest/v1", "/rest/v2",
    "/swagger", "/swagger-ui", "/swagger-ui.html", "/swagger.json", "/swagger.yaml",
    "/openapi.json", "/openapi.yaml", "/api-docs", "/api/docs",
    "/docs", "/redoc",
    "/.well-known/openid-configuration",
    "/oauth/token", "/oauth2/token",
    "/api/health", "/api/status", "/api/version", "/api/ping",
    "/api/users", "/api/user", "/api/me", "/api/profile",
    "/api/admin", "/api/internal",
  ];

  const hits = [];
  const CONCURRENCY = 8;
  for (let i = 0; i < paths.length; i += CONCURRENCY) {
    const batch = paths.slice(i, i + CONCURRENCY);
    const results = await Promise.allSettled(
      batch.map(path =>
        fetchUrl(target, path, {
          protocol, method: "GET", maxBytes: 8192, maxRedirects: 0,
          headers: { Accept: "application/json, text/plain, */*" }, timeout: 6000
        }).then(r => ({ path, r })).catch(() => null)
      )
    );
    for (const res of results) {
      if (res.status !== "fulfilled" || !res.value) continue;
      const { path, r } = res.value;
      if (r.statusCode > 0 && r.statusCode !== 404) {
        const ct = r.headers?.["content-type"] || "";
        const isJson = /application\/json/i.test(ct) || (r.body||"").trimStart().startsWith("{") || (r.body||"").trimStart().startsWith("[");
        hits.push({
          path, statusCode: r.statusCode, contentType: ct, isJson,
          bodyPreview: redact((r.body || "").slice(0, 200).trim()),
          size: (r.body || "").length
        });
      }
    }
    if (i + CONCURRENCY < paths.length) await sleep(150);
  }
  return hits;
}

// ─── Content-Type & Response Analysis ────────────────────────────────────────

function analyzeContentType(headers, body, path) {
  const findings = [];
  const ct = (headers?.["content-type"] || "").toLowerCase();
  const bodyStart = (body || "").trimStart().slice(0, 500);

  // JSON served without Content-Type: application/json
  if (!ct.includes("application/json") && (bodyStart.startsWith("{") || bodyStart.startsWith("["))) {
    findings.push({
      path, finding: "JSON body tanpa Content-Type: application/json",
      detail: `Content-Type: ${ct || "(missing)"}`, severity: "low"
    });
  }

  // HTML in response to JSON-requesting endpoint
  if (path.startsWith("/api") && ct.includes("text/html")) {
    findings.push({
      path, finding: "API endpoint mengembalikan HTML (kemungkinan error/debug page)",
      detail: ct, severity: "medium"
    });
  }

  // X-Content-Type-Options missing
  if (!headers?.["x-content-type-options"]) {
    findings.push({ path, finding: "X-Content-Type-Options nosniff tidak ada", detail: "", severity: "low" });
  }

  return findings;
}

// ─── Sitemap Deep Parse ───────────────────────────────────────────────────────

async function parseSitemap(target) {
  await sleep(REQUEST_DELAY);
  const r = await fetchUrl(target, "/sitemap.xml", { protocol: "https:", method: "GET", maxBytes: 65536, maxRedirects: 1 });
  if (r.statusCode !== 200) return { paths: [], sitemapIndex: false };

  const xml = r.body || "";
  const sitemapIndex = /<sitemapindex/i.test(xml);
  const locs = [...xml.matchAll(/<loc>\s*(https?:\/\/[^\s<]+)\s*<\/loc>/gi)].map(m => m[1]);

  const paths = locs
    .filter(url => {
      try { return new URL(url).hostname.toLowerCase().includes(target.hostname); }
      catch { return false; }
    })
    .map(url => { try { const u = new URL(url); return `${u.pathname}${u.search||""}`; } catch { return ""; } })
    .filter(p => p && p.length > 1)
    .slice(0, 40);

  return { paths: [...new Set(paths)], sitemapIndex, total: locs.length };
}

// ─── Cookie Deep Analysis ─────────────────────────────────────────────────────

function analyzeCookiesDeep(rawCookies) {
  const findings = [];
  for (const raw of (rawCookies || []).slice(0, 10)) {
    const name = (raw.split("=")[0] || "").trim();
    if (!name) continue;

    // Session/auth cookie heuristics
    const looksLikeSession = /sess|session|auth|token|jwt|sid|uid|user|remember/i.test(name);

    // Decode value to check if it's JWT
    const valuePart = (raw.split("=")[1] || "").split(";")[0].trim();
    const isJwt = /^eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*$/.test(valuePart);

    if (isJwt) {
      // Decode JWT header+payload (no signature verification needed - passive)
      try {
        const [headerB64, payloadB64] = valuePart.split(".");
        const header  = JSON.parse(Buffer.from(headerB64,  "base64url").toString());
        const payload = JSON.parse(Buffer.from(payloadB64, "base64url").toString());
        findings.push({
          name, type: "JWT",
          algorithm: header.alg || "unknown",
          claims: Object.keys(payload),
          hasExp: !!payload.exp,
          expiresAt: payload.exp ? new Date(payload.exp * 1000).toISOString() : null,
          payload: redact(JSON.stringify(payload).slice(0, 300))
        });
      } catch { /* invalid JWT */ }
    }

    // Long-lived cookie check
    const maxAgeMatch = /max-age=(\d+)/i.exec(raw);
    if (maxAgeMatch && Number(maxAgeMatch[1]) > 86400 * 90) {
      findings.push({ name, type: "long-lived", maxAgeDays: Math.round(Number(maxAgeMatch[1]) / 86400) });
    }

    // prefix security (__Host-, __Secure-)
    if (looksLikeSession && !name.startsWith("__Host-") && !name.startsWith("__Secure-")) {
      findings.push({ name, type: "no-prefix", note: "Cookie sesi tanpa __Host- atau __Secure- prefix" });
    }
  }
  return findings;
}

// ─── Dependency File Analysis ─────────────────────────────────────────────────

async function checkDependencyFiles(target) {
  const depPaths = [
    { path: "/package.json",    label: "package.json (Node.js)" },
    { path: "/composer.json",   label: "composer.json (PHP)" },
    { path: "/Gemfile",         label: "Gemfile (Ruby)" },
    { path: "/requirements.txt",label: "requirements.txt (Python)" },
    { path: "/go.mod",          label: "go.mod (Go)" },
    { path: "/Cargo.toml",      label: "Cargo.toml (Rust)" },
    { path: "/pom.xml",         label: "pom.xml (Java/Maven)" },
    { path: "/build.gradle",    label: "build.gradle (Java/Gradle)" },
    { path: "/pyproject.toml",  label: "pyproject.toml (Python)" },
  ];

  const hits = [];
  for (const { path, label } of depPaths) {
    await sleep(REQUEST_DELAY);
    const r = await fetchUrl(target, path, { protocol: "https:", method: "GET", maxBytes: 32768, maxRedirects: 0 });
    if (r.statusCode === 200 && r.body && r.body.length > 20) {
      // Extract version info
      const versions = [];
      const body = r.body;
      // Package.json
      const pkgName    = (/"name"\s*:\s*"([^"]+)"/.exec(body)||[])[1] || "";
      const pkgVersion = (/"version"\s*:\s*"([^"]+)"/.exec(body)||[])[1] || "";
      const nodeVersion= (/"node"\s*:\s*"([^"]+)"/.exec(body)||[])[1] || "";
      // Composer
      const phpVersion = (/"php"\s*:\s*"([^"]+)"/.exec(body)||[])[1] || "";
      if (pkgVersion)  versions.push(`app v${pkgVersion}`);
      if (nodeVersion) versions.push(`node ${nodeVersion}`);
      if (phpVersion)  versions.push(`php ${phpVersion}`);

      hits.push({ path, label, statusCode: 200, versions, bodyPreview: redact(body.slice(0, 400)) });
    }
  }
  return hits;
}

// ─── Analysis Engine ──────────────────────────────────────────────────────────

const HEADER_CHECKS = [
  { key: "strict-transport-security",   label: "HSTS",                     severity: "medium", recommendation: "Set Strict-Transport-Security dengan max-age minimal 15552000." },
  { key: "content-security-policy",     label: "Content Security Policy",  severity: "medium", recommendation: "Tambahkan CSP yang membatasi script, object, frame, dan connect sources." },
  { key: "x-frame-options",             label: "Clickjacking Guard (X-Frame-Options)", severity: "low", recommendation: "Set X-Frame-Options: DENY atau SAMEORIGIN." },
  { key: "x-content-type-options",      label: "MIME Sniffing Guard",      severity: "low",    recommendation: "Set X-Content-Type-Options: nosniff." },
  { key: "referrer-policy",             label: "Referrer Policy",          severity: "low",    recommendation: "Set Referrer-Policy untuk membatasi bocornya URL sensitif." },
  { key: "permissions-policy",          label: "Permissions Policy",       severity: "low",    recommendation: "Set Permissions-Policy untuk menonaktifkan fitur browser yang tidak dipakai." },
];

function analyze(scan) {
  const findings = [];
  const h    = scan.homepage.headers || {};
  const mail = scan.dns.mail || { spf: null, dmarc: null };
  const dns  = scan.dns.records || {};
  const homepageEvaluable = scan.homepage.ok && scan.homepage.statusCode >= 200 && scan.homepage.statusCode < 400;
  // Skip DNS/email checks for local/IP scans
  const isLocalScan = scan.target?.isLocal;

  // ── TLS checks ────────────────────────────────────────────────────────────
  if (!scan.tls.ok) {
    findings.push({ severity: "high", title: "HTTPS tidak bisa dinegosiasikan", evidence: scan.tls.authorizationError || "Koneksi TLS gagal.", recommendation: "Periksa konfigurasi HTTPS dan sertifikat.", category: "TLS" });
  } else if (!scan.tls.authorized) {
    findings.push({ severity: "high", title: "Validasi sertifikat TLS bermasalah", evidence: scan.tls.authorizationError, recommendation: "Gunakan sertifikat valid dari CA tepercaya.", category: "TLS" });
  }
  const rem = scan.tls.certificate?.daysRemaining;
  if (typeof rem === "number" && rem <= 14) {
    findings.push({ severity: rem <= 0 ? "high" : "medium", title: "Sertifikat TLS hampir kedaluwarsa", evidence: `Sisa hari: ${rem}`, recommendation: "Perbarui sertifikat segera.", category: "TLS" });
  }

  // Version/tech disclosure
  findings.push(...analyzeVersionDisclosure(h, scan.homepage.body || "", scan.tls));

  // ── HTTPS redirect ────────────────────────────────────────────────────────
  if (scan.httpRedirect.ok && scan.httpRedirect.statusCode > 0 && ![301, 302, 307, 308].includes(scan.httpRedirect.statusCode)) {
    findings.push({ severity: "medium", title: "HTTP tidak redirect ke HTTPS", evidence: `Status HTTP: ${scan.httpRedirect.statusCode}`, recommendation: "Redirect semua HTTP ke HTTPS dengan 301/308.", category: "HTTPS" });
  }

  // ── Security headers ──────────────────────────────────────────────────────
  for (const chk of HEADER_CHECKS) {
    if (homepageEvaluable && !h[chk.key]) {
      findings.push({ severity: chk.severity, title: `${chk.label} belum terpasang`, evidence: `Header ${chk.key} tidak ditemukan.`, recommendation: chk.recommendation, category: "Security Headers" });
    }
  }
  const csp = h["content-security-policy"] || "";
  if (homepageEvaluable && csp && /unsafe-inline|unsafe-eval|\*/i.test(csp)) {
    findings.push({ severity: "low", title: "CSP terlalu longgar", evidence: "CSP mengandung unsafe-inline, unsafe-eval, atau wildcard.", recommendation: "Persempit directive CSP secara bertahap.", category: "Security Headers" });
  }
  const hsts = h["strict-transport-security"] || "";
  const maxAge = /max-age=(\d+)/i.exec(hsts);
  if (homepageEvaluable && hsts && maxAge && Number(maxAge[1]) < 15552000) {
    findings.push({ severity: "low", title: "Durasi HSTS terlalu pendek", evidence: `max-age=${maxAge[1]}`, recommendation: "Gunakan max-age minimal 15552000 detik.", category: "Security Headers" });
  }

  // ── Cookies ───────────────────────────────────────────────────────────────
  const cookies = getHeaderValues(scan.homepage.headers, "set-cookie");
  const cookieNames = new Set();
  for (const cookie of cookies.slice(0, 8)) {
    const name = cookie.split("=")[0]?.trim() || "cookie";
    if (cookieNames.has(name)) continue;
    cookieNames.add(name);
    if (!/;\s*secure\b/i.test(cookie))   findings.push({ severity: "low", title: "Cookie tanpa flag Secure",   evidence: redact(name), recommendation: "Tambahkan flag Secure pada cookie yang dipakai di HTTPS.", category: "Cookie Security" });
    if (!/;\s*httponly\b/i.test(cookie))  findings.push({ severity: "low", title: "Cookie tanpa flag HttpOnly", evidence: redact(name), recommendation: "Tambahkan HttpOnly untuk cookie sesi agar tidak bisa diakses JavaScript.", category: "Cookie Security" });
    if (!/;\s*samesite=(strict|lax|none)\b/i.test(cookie)) findings.push({ severity: "low", title: "Cookie tanpa SameSite", evidence: redact(name), recommendation: "Set SameSite=Lax atau Strict, kecuali butuh cross-site.", category: "Cookie Security" });
    const maxAgeC  = /max-age=(\d+)/i.exec(cookie);
    const expiresC = /expires=([^;]+)/i.exec(cookie);
    if (!maxAgeC && !expiresC) {
      findings.push({ severity: "info", title: "Cookie sesi (non-persistent) terdeteksi", evidence: redact(name), recommendation: "Pastikan cookie sesi di-invalidate saat logout server-side.", category: "Cookie Security" });
    }
  }

  // ── CORS ──────────────────────────────────────────────────────────────────
  for (const hit of scan.corsDeep || []) {
    const sev = hit.withCredentials ? "high" : (hit.acao === "*" ? "low" : "medium");
    findings.push({
      severity: sev,
      title: `CORS misconfiguration: ${hit.probe}`,
      evidence: `Origin: ${hit.origin} → ACAO: ${hit.acao}${hit.acac ? `, credentials: ${hit.acac}` : ""} [path: ${hit.path}]`,
      recommendation: hit.withCredentials
        ? "CRITICAL: CORS memantulkan arbitrary origin dengan credentials=true. Ini memungkinkan aksi atas nama user yang login."
        : "Batasi CORS hanya ke domain yang dipercaya. Jangan reflect Origin request tanpa allowlist.",
      category: "CORS",
      huntingChecklist: hit.withCredentials ? [
        "Buat PoC HTML: fetch ke endpoint dengan credentials:include dari domain attacker",
        "Verifikasi apakah cookie ikut dikirim",
        "Test endpoint sensitif (profile, settings, payment) dengan teknik yang sama"
      ] : []
    });
  }

  // ── Open redirect ─────────────────────────────────────────────────────────
  for (const redir of scan.openRedirects || []) {
    findings.push({
      severity: "medium",
      title: `Open Redirect terindikasi: parameter ${redir.label}`,
      evidence: `GET ${redir.path} → ${redir.statusCode} Location: ${redir.location}`,
      recommendation: "Open redirect sering dipakai untuk phishing dan OAuth token theft. Validasi server-side: allowlist domain yang boleh jadi tujuan redirect.",
      category: "Open Redirect",
      huntingChecklist: [
        `Uji: GET ${redir.path} — server redirect ke evil.com?`,
        "Coba bypass: ///evil.com, /\\evil.com, @evil.com, evil.com%2F%2F",
        "Cari parameter redirect lain di URL aplikasi saat browse normal",
        "Cek OAuth flow: apakah redirect_uri bisa dimanipulasi?"
      ]
    });
  }

  // ── Sensitive paths ───────────────────────────────────────────────────────
  for (const item of scan.sensitivePaths || []) {
    const fullUrl = `https://${scan.target.hostname}${item.path}`;
    if (item.statusCode === 200) {
      findings.push({
        severity: item.severity,
        title: `Exposed: ${item.label}`,
        evidence: `GET ${fullUrl} → 200 OK\nPreview: ${item.bodyPreview || "(response kosong)"}\nSize: ${item.bodyLength || 0} bytes`,
        location: fullUrl,
        recommendation: item.severity === "critical"
          ? `KRITIS: ${fullUrl} bisa diakses publik! Blokir segera di web server. Jika ini .env/config/SQL dump, rotasi semua credential yang ada di dalamnya.`
          : `Blokir akses ke ${fullUrl}. Tambahkan rule di Nginx/Apache atau hapus file dari web root.`,
        category: "Sensitive Path Exposure",
        huntingChecklist: [
          `Buka langsung di browser: ${fullUrl}`,
          item.severity === "critical" ? "Download dan baca isi penuh — cari credential, DB password, API key" : "Verifikasi isi file",
          "Cek apakah ada file serupa dengan ekstensi berbeda (.bak, .old, .1, ~)"
        ]
      });
    } else if (item.statusCode === 403 || item.statusCode === 401) {
      findings.push({
        severity: item.severity === "critical" ? "high" : "medium",
        title: `Endpoint sensitif terdeteksi (${item.statusCode}): ${item.label}`,
        evidence: `${item.statusCode === 403 ? "GET" : "GET"} ${fullUrl} → ${item.statusCode}\nEndpoint ADA tapi akses ditolak`,
        location: fullUrl,
        recommendation: `${fullUrl} mengembalikan ${item.statusCode} — endpoint ini ADA. Verifikasi apakah bisa dibypass dengan method/header berbeda.`,
        category: "Sensitive Path Exposure",
        huntingChecklist: [
          `Coba: curl -X POST ${fullUrl}`,
          `Coba: curl -H "X-Original-URL: ${item.path}" https://${scan.target.hostname}/`,
          `Coba: curl -H "X-Forwarded-For: 127.0.0.1" ${fullUrl}`,
          `Coba path variation: ${fullUrl}/ atau ${fullUrl}.php`
        ]
      });
    }
  }

  // ── Forms & inputs ────────────────────────────────────────────────────────
  findings.push(...(scan.formFindings || []));

  // ── JavaScript ────────────────────────────────────────────────────────────
  for (const jf of scan.javascriptFindings || []) findings.push(jf);

  // ── Frameworks ────────────────────────────────────────────────────────────
  if (scan.refs?.frameworks?.length) {
    findings.push({
      severity: "info",
      title: `Teknologi/framework terdeteksi: ${scan.refs.frameworks.join(", ")}`,
      evidence: scan.refs.frameworks.join(", "),
      recommendation: "Gunakan informasi ini untuk fokus pada CVE, default credential, dan path yang umum untuk framework tersebut.",
      category: "Technology Stack",
      huntingChecklist: scan.refs.frameworks.flatMap(fw => {
        if (/wordpress/i.test(fw)) return ["Cek /wp-admin, /wp-login.php, XML-RPC (/xmlrpc.php)", "Cek versi plugin yang terekspos", "Cek user enumeration via /?author=1"];
        if (/laravel/i.test(fw)) return ["Cek apakah APP_DEBUG=true (verbose error)", "Cek /.env publik", "Test path /telescope, /horizon, /_debugbar"];
        if (/next\.js/i.test(fw)) return ["Cek /_next/static/ untuk bundle JS", "Cari endpoint di _buildManifest.js", "Test /api/ routes untuk unprotected endpoints"];
        if (/spring/i.test(fw)) return ["Cek /actuator/env, /actuator/beans", "Cek /actuator/mappings untuk semua route"];
        return [`Cari CVE terbaru untuk ${fw}`, `Cek default path/endpoint ${fw}`];
      })
    });
  }

  // ── HTML comments ─────────────────────────────────────────────────────────
  if (scan.refs?.comments?.length) {
    findings.push({
      severity: "low",
      title: "Komentar developer sensitif di HTML",
      evidence: redact(scan.refs.comments.join(" | ")),
      recommendation: "Hapus semua komentar TODO/debug/password dari HTML production.",
      category: "Information Disclosure"
    });
  }

  // ── Body content analysis ─────────────────────────────────────────────────
  const body = scan.homepage.body || "";
  if (/Index of \//i.test(body)) {
    findings.push({ severity: "medium", title: "Indikasi directory listing aktif", evidence: "Halaman berisi pola 'Index of /'.", recommendation: "Matikan directory listing di web server config.", category: "Exposure Check" });
  }
  if (/(stack trace|traceback|exception in thread|fatal error|warning: .*php|debug mode|sql syntax error|mongodb|pg_connect|mysql_connect)/i.test(body)) {
    findings.push({ severity: "medium", title: "Indikasi debug/error page publik", evidence: redact((body.match(/.{0,100}(stack trace|traceback|exception|fatal error|warning:|debug mode|sql syntax).{0,100}/i) || ["Debug keyword ditemukan"])[0]), recommendation: "Tampilkan error generic ke user dan log detail di server-side.", category: "Exposure Check" });
  }
  const credentialMatch = body.match(/(?:api[_-]?key|access[_-]?token|client[_-]?secret|private[_-]?key)\s*[:=]\s*["']?([a-z0-9._-]{10,})|bearer\s+([a-z0-9._-]{20,})/i);
  const credentialValue = (credentialMatch?.[1] || credentialMatch?.[2] || "").toLowerCase();
  const isPlaceholderCredential = /^(?:meow)+$/.test(credentialValue) || /(example|sample|placeholder|dummy|replace|your[_-]?)/i.test(credentialValue);
  if (credentialMatch && !isPlaceholderCredential) {
    findings.push({ severity: "medium", title: "Indikasi credential di halaman publik", evidence: redact(credentialMatch[0]), recommendation: "Pastikan halaman publik tidak membocorkan credential atau konfigurasi.", category: "Exposure Check" });
  }

  // ── Email security ────────────────────────────────────────────────────────
  if (!isLocalScan) {
    if (scan.dns.recordChecks?.txt !== false && !mail.spf) findings.push({ severity: "medium", title: "SPF tidak ditemukan", evidence: "TXT v=spf1 tidak ditemukan.", recommendation: "Tambahkan SPF record untuk mencegah email spoofing.", category: "Email Security" });
    if (scan.dns.recordChecks?.dmarc !== false && !mail.dmarc) {
      findings.push({ severity: "medium", title: "DMARC tidak ditemukan", evidence: `_dmarc.${scan.target.hostname} tidak ada.`, recommendation: "Tambahkan DMARC record.", category: "Email Security" });
    } else if (/p=none/i.test(mail.dmarc)) {
      findings.push({ severity: "low", title: "DMARC masih mode monitoring (p=none)", evidence: mail.dmarc, recommendation: "Naikkan DMARC policy ke quarantine atau reject.", category: "Email Security" });
    }
    if (scan.dns.recordChecks?.caa !== false && (!dns.caa || dns.caa.length === 0)) {
      findings.push({ severity: "low", title: "CAA record tidak ditemukan", evidence: "DNS CAA kosong.", recommendation: "Tambahkan CAA record untuk membatasi CA yang boleh menerbitkan sertifikat.", category: "DNS Security" });
    }
  }

  // ── robots.txt deep check ─────────────────────────────────────────────────
  if (scan.robotsTxt?.statusCode === 200) {
    const disallowed = (scan.robotsTxt.body || "").match(/Disallow:\s*.+/g) || [];
    const sensitive  = disallowed.filter(d => /admin|dashboard|internal|api\/v|\bapi\b|\\.env|backup|debug|private|config|manage|panel/i.test(d));
    if (sensitive.length) {
      findings.push({
        severity: "info",
        title: "robots.txt mengungkap path sensitif",
        evidence: sensitive.join(", "),
        recommendation: "Path di Disallow sering menjadi target. Verifikasi akses ke path tersebut — proteksi harus dari auth, bukan hanya robots.txt.",
        category: "Information Disclosure",
        huntingChecklist: sensitive.map(d => `Coba akses: ${d.replace("Disallow:", "").trim()}`)
      });
    }
  }

  // ── Link checks (from HTML) ───────────────────────────────────────────────
  for (const link of scan.linkChecks || []) {
    if ([401, 403].includes(link.statusCode) && /admin|dashboard|internal|manage|debug|config/i.test(link.path)) {
      findings.push({ severity: "info", title: "Endpoint sensitif terlihat tetapi terlindungi", evidence: `${link.path} returned ${link.statusCode}`, recommendation: "Endpoint ada tapi diblokir. Cek bypass: trailing slash, metod berbeda, header X-Original-URL.", category: "Endpoint Review" });
    }
    if (link.statusCode >= 500) {
      findings.push({ severity: "medium", title: "Endpoint mengembalikan error server (5xx)", evidence: `${link.path} returned ${link.statusCode}`, recommendation: "Error 5xx saat akses normal bisa mengindikasikan bug logic atau unhandled exception.", category: "Endpoint Review" });
    }
  }

  // ── WAF / CDN ─────────────────────────────────────────────────────────────
  const waf = scan.wafCdn || {};
  if (waf.detections?.length) {
    findings.push({ severity: "info", title: `Infrastruktur terdeteksi: ${waf.detections.join(", ")}`, evidence: `CDN/WAF: ${waf.detections.join(", ")}`, recommendation: "Informasi ini membantu menentukan teknik bypass yang relevan. CDN bisa menyembunyikan IP asli origin.", category: "Technology Stack" });
  }
  if (waf.xCache) {
    findings.push({ severity: "info", title: "Cache layer aktif terdeteksi", evidence: `X-Cache/CF-Cache-Status: ${waf.xCache}`, recommendation: "Cek apakah endpoint sensitif (API, auth) ikut di-cache. Response cache tanpa auth bisa bocorkan data.", category: "Cache Analysis" });
  }

  // ── Cache poisoning surface ───────────────────────────────────────────────
  for (const hit of scan.cacheSurface || []) {
    findings.push({
      severity: "medium",
      title: `Potensi header injection: ${hit.label}`,
      evidence: hit.evidence,
      recommendation: "Jika nilai header injection direflect ke response dan ikut di-cache, ini bisa jadi cache poisoning. Verifikasi manual dengan Burp Suite.",
      category: "Cache Poisoning"
    });
  }

  // ── HTTP methods ──────────────────────────────────────────────────────────
  const methods = scan.httpMethods || {};
  if (methods.dangerousMethods?.length) {
    findings.push({
      severity: methods.dangerousMethods.includes("TRACE") ? "low" : "medium",
      title: `Method HTTP berbahaya diizinkan: ${methods.dangerousMethods.join(", ")}`,
      evidence: `Allow: ${methods.allowed}`,
      recommendation: `Method ${methods.dangerousMethods.join(", ")} seharusnya dinonaktifkan. TRACE bisa dipakai untuk XST attack. PUT/DELETE tanpa auth bisa hapus/overwrite konten.`,
      category: "HTTP Methods"
    });
  }

  // ── Subdomain takeover ────────────────────────────────────────────────────
  for (const vuln of scan.takeoverVulnerable || []) {
    findings.push({
      severity: "high",
      title: `Indikasi subdomain takeover: ${vuln.subdomain}`,
      evidence: `${vuln.subdomain} mengarah ke ${vuln.service} yang tidak aktif${vuln.cname ? ` (CNAME: ${vuln.cname})` : ""}`,
      recommendation: `Subdomain ${vuln.subdomain} kemungkinan bisa di-takeover via ${vuln.service}. Daftarkan resource di ${vuln.service} dengan nama yang sama untuk memverifikasi. Jika valid, ini adalah High severity bug bounty finding.`,
      category: "Subdomain Takeover"
    });
  }

  // ── Subdomains found ──────────────────────────────────────────────────────
  if ((scan.subdomains || []).length > 0) {
    const pubSubs = scan.subdomains.filter(s => s.isPublic);
    findings.push({
      severity: "info",
      title: `${pubSubs.length} subdomain aktif ditemukan (passive DNS)`,
      evidence: pubSubs.slice(0, 15).map(s => `${s.subdomain} (${s.ips[0]})`).join(", "),
      recommendation: "Setiap subdomain adalah target terpisah. Cek subdomain yang tidak dikenal seperti staging/dev/internal — sering lebih longgar keamanannya.",
      category: "Subdomain Recon"
    });
  }

  // ── Cert transparency ─────────────────────────────────────────────────────
  const ctNames = scan.certTransparency || [];
  if (ctNames.length > 0) {
    const interesting = ctNames.filter(n => /dev|staging|test|admin|internal|api|beta|old|legacy|backup/i.test(n));
    if (interesting.length) {
      findings.push({
        severity: "info",
        title: `Subdomain menarik di Certificate Transparency: ${interesting.slice(0,5).join(", ")}`,
        evidence: `crt.sh: ${interesting.slice(0, 8).join(", ")}`,
        recommendation: "Subdomain dari CT log sering mengekspos environment non-production. Akses manual untuk cek apakah lebih lemah dari main domain.",
        category: "Subdomain Recon"
      });
    }
    findings.push({
      severity: "info",
      title: `${ctNames.length} domain/subdomain ditemukan di Certificate Transparency log`,
      evidence: `Total dari crt.sh: ${ctNames.length}. Sample: ${ctNames.slice(0, 6).join(", ")}`,
      recommendation: "Daftar lengkap subdomain dari CT log berguna untuk memperluas scope hunting.",
      category: "Subdomain Recon"
    });
  }

  // ── API endpoints found ───────────────────────────────────────────────────
  const apiHits = (scan.apiProbe || []).filter(h => h.statusCode !== 404);
  const apiOpen = apiHits.filter(h => h.statusCode === 200 && h.isJson);
  const apiAuth = apiHits.filter(h => [401, 403].includes(h.statusCode));
  const apiErr  = apiHits.filter(h => h.statusCode >= 500);

  if (apiOpen.length) {
    findings.push({
      severity: "medium",
      title: `${apiOpen.length} API endpoint terbuka tanpa auth terdeteksi`,
      evidence: apiOpen.slice(0,8).map(h => `${h.path} (${h.statusCode})`).join(", "),
      recommendation: "Endpoint API yang return 200 tanpa auth perlu diverifikasi: apakah data yang dikembalikan sensitif? Apakah bisa POST/PUT/DELETE?",
      category: "API Discovery"
    });
  }
  if (apiAuth.length) {
    findings.push({
      severity: "info",
      title: `${apiAuth.length} probe API menerima 401/403 (belum terverifikasi)`,
      evidence: apiAuth.slice(0,8).map(h => `${h.path} (${h.statusCode})`).join(", "),
      recommendation: "Respons 401/403 dapat berasal dari WAF atau auth generik dan tidak membuktikan endpoint ada.",
      category: "API Discovery"
    });
  }
  if (apiErr.length) {
    findings.push({
      severity: "medium",
      title: `${apiErr.length} API endpoint return error 5xx`,
      evidence: apiErr.slice(0,5).map(h => `${h.path} (${h.statusCode})`).join(", "),
      recommendation: "Error 5xx pada endpoint API bisa mengindikasikan unhandled exception, verbose error, atau logika yang bisa dieksploitasi.",
      category: "API Discovery"
    });
  }

  // ── Swagger/OpenAPI/GraphQL ───────────────────────────────────────────────
  const docsHit = (scan.apiProbe || []).find(h => h.statusCode === 200 && /swagger|openapi|graphi?ql|redoc|api-docs/i.test(h.path));
  if (docsHit) {
    findings.push({
      severity: "medium",
      title: `Dokumentasi API publik ditemukan: ${docsHit.path}`,
      evidence: `${docsHit.path} → 200 OK (${docsHit.contentType})`,
      recommendation: "Dokumentasi API publik mengekspos semua endpoint, parameter, dan schema. Gunakan untuk mapping serangan: cari endpoint yang belum di-test, parameter tidak terduga, dan endpoint yang tidak ada di frontend.",
      category: "API Discovery"
    });
  }

  // ── JWT cookies ───────────────────────────────────────────────────────────
  for (const cInfo of scan.cookieDeepInfo || []) {
    if (cInfo.type === "JWT") {
      const algSev = /none|hs256/i.test(cInfo.algorithm) ? "medium" : "info";
      findings.push({
        severity: algSev,
        title: `JWT ditemukan di cookie: ${cInfo.name} (alg: ${cInfo.algorithm})`,
        evidence: `Claims: ${cInfo.claims.join(", ")}. Exp: ${cInfo.expiresAt || "tidak ada"}. Payload: ${cInfo.payload}`,
        recommendation: /none/i.test(cInfo.algorithm)
          ? "KRITIS: JWT menggunakan alg=none! Coba bypass dengan JWT tanpa signature."
          : `Verifikasi: apakah server menerima JWT dengan alg=none? Apakah bisa manipulasi claim (role, user_id)? Cek apakah ${cInfo.name} di-invalidate saat logout.`,
        category: "JWT Analysis"
      });
    }
    if (cInfo.type === "long-lived") {
      findings.push({
        severity: "low",
        title: `Cookie bertahan ${cInfo.maxAgeDays} hari: ${cInfo.name}`,
        evidence: `max-age=${cInfo.maxAgeDays * 86400} detik`,
        recommendation: "Cookie sesi dengan umur sangat panjang meningkatkan risiko session hijacking. Pertimbangkan rotasi token dan shorter expiry.",
        category: "Cookie Security"
      });
    }
    if (cInfo.type === "no-prefix") {
      findings.push({
        severity: "info",
        title: `Cookie sesi tanpa security prefix: ${cInfo.name}`,
        evidence: cInfo.note,
        recommendation: "Gunakan __Host- prefix untuk memaksa Secure, no-subdomain, dan exact-path constraints pada cookie sesi.",
        category: "Cookie Security"
      });
    }
  }

  // ── Dependency files ──────────────────────────────────────────────────────
  for (const dep of scan.depFiles || []) {
    findings.push({
      severity: "medium",
      title: `File dependensi publik: ${dep.label}`,
      evidence: `GET ${dep.path} → 200. Versi: ${dep.versions.join(", ") || "tidak terdeteksi"}. Preview: ${dep.bodyPreview.slice(0, 100)}`,
      recommendation: `${dep.path} publik mengekspos nama package dan versi yang dipakai. Gunakan ini untuk mencari CVE pada dependencies yang outdated.`,
      category: "Information Disclosure"
    });
  }

  // ── Sitemap paths ─────────────────────────────────────────────────────────
  const sitemap = scan.sitemapData || {};
  if (sitemap.paths?.length) {
    const sensitiveFromSitemap = sitemap.paths.filter(p => /admin|internal|debug|user|account|setting|config|manage|dashboard/i.test(p));
    if (sensitiveFromSitemap.length) {
      findings.push({
        severity: "info",
        title: `Path menarik ditemukan di sitemap.xml (${sensitiveFromSitemap.length})`,
        evidence: sensitiveFromSitemap.slice(0, 10).join(", "),
        recommendation: "Path dari sitemap yang mengandung kata kunci sensitif perlu diverifikasi manual: apakah ada akses kontrol yang tepat?",
        category: "Information Disclosure"
      });
    }
    findings.push({
      severity: "info",
      title: `sitemap.xml ditemukan: ${sitemap.total} URL`,
      evidence: `Total URL: ${sitemap.total}. Sample: ${sitemap.paths.slice(0, 5).join(", ")}`,
      recommendation: "Daftar URL dari sitemap berguna untuk mapping aplikasi. Gunakan sebagai basis pengujian manual.",
      category: "Recon"
    });
  }

  // ── Deduplicate & score ───────────────────────────────────────────────────
  const seen = new Set();
  const unique = findings.filter(f => {
    const key = `${f.severity}:${f.title}:${String(f.evidence || "").slice(0, 80)}`;
    if (seen.has(key)) return false;
    seen.add(key);
    f.disclaimer = DISCLAIMER;
    return true;
  });

  const order = { high: 0, medium: 1, low: 2, info: 3 };
  unique.sort((a, b) => (order[a.severity] ?? 4) - (order[b.severity] ?? 4));

  const weights = { high: 20, medium: 10, low: 4, info: 1 };
  const penalty = unique.reduce((t, f) => t + (weights[f.severity] || 0), 0);
  const score   = Math.max(0, Math.min(100, 100 - penalty));

  return { findings: unique, score };
}

// ─── Main scan ────────────────────────────────────────────────────────────────

async function runScan(input) {
  const target  = normalizeTarget(input);
  const dnsInfo = await resolveDns(target.hostname);
  target.dns    = dnsInfo;

  const tlsInfo = await checkTls(target.hostname, dnsInfo);
  await sleep(REQUEST_DELAY);

  // Try HTTPS first, fallback to HTTP (for local/development sites)
  let homepage = await fetchUrl(target, "/", { protocol: "https:", method: "GET", maxBytes: 131072 });
  const useHttp = homepage.statusCode === 0 || homepage.error;
  if (useHttp) {
    homepage = await fetchUrl(target, "/", { protocol: "http:", method: "GET", maxBytes: 131072 });
  }
  const scanProtocol = useHttp ? "http:" : "https:";
  await sleep(REQUEST_DELAY);
  const httpRedirect = useHttp ? { statusCode: 0 } : await fetchUrl(target, "/", { protocol: "http:", method: "GET", maxBytes: 4096, maxRedirects: 0 });
  await sleep(REQUEST_DELAY);
  const robotsTxt    = await fetchUrl(target, "/robots.txt", { protocol: "https:", method: "GET", maxBytes: 16384 });
  await sleep(REQUEST_DELAY);

  const refs = parseHtmlRefs(homepage.body || "", target.hostname);

  // WAF/CDN detection (from existing response — no extra request)
  const wafCdn = detectWafCdn(homepage.headers, homepage.body);

  // JS analysis
  const javascriptFindings = [];
  for (const scriptPath of refs.scripts) {
    await sleep(REQUEST_DELAY);
    const r = await fetchUrl(target, scriptPath, { protocol: "https:", method: "GET", maxBytes: 200000, maxRedirects: 0 });
    if (r.statusCode === 200 && r.body) javascriptFindings.push(...extractJsFindings(r.body, scriptPath));
  }

  // Form analysis
  const formFindings = analyzeFormsAndInputs(refs.forms, refs.inputs, target.hostname);

  // Link checks from HTML
  const linkChecks = [];
  for (const path of refs.links.slice(0, 10)) {
    await sleep(REQUEST_DELAY);
    const r = await fetchUrl(target, path, { protocol: "https:", method: "HEAD", maxBytes: 1024, maxRedirects: 0 });
    linkChecks.push({ path, statusCode: r.statusCode || 0 });
  }

  // CORS deep check
  const corsDeep = await checkCorsDeep(target, scanProtocol);

  // Open redirect probing
  const openRedirects = await checkRedirectChain(target);

  // Sensitive path enumeration
  const sensitivePaths = await checkSensitivePaths(target, 305, scanProtocol, homepage.body || "");

  // HTTP method enumeration
  const httpMethods = await checkHttpMethods(target);

  // Cache poisoning surface
  const cacheSurface = await checkCacheSurface(target);

  // API version probe
  const apiProbe = await probeApiVersions(target, scanProtocol);

  // Sitemap deep parse
  const sitemapData = await parseSitemap(target);

  // Dependency files
  const depFiles = await checkDependencyFiles(target);

  // Cookie deep analysis
  const rawCookies = (homepage.headers?.["set-cookie"] || "").split(/,(?=\s*\w+=)/).concat(
    getHeaderValues(homepage.headers, "set-cookie")
  ).filter(Boolean);
  const cookieDeepInfo = analyzeCookiesDeep(rawCookies);

  // Passive subdomain enumeration (DNS only — no HTTP scanning of subdomains)
  const subdomains = await enumerateSubdomains(target.hostname);

  // Certificate transparency (crt.sh)
  const certTransparency = await queryCertTransparency(target.hostname);

  // Subdomain takeover detection (only on discovered subdomains)
  const takeoverVulnerable = subdomains.length > 0 ? await checkSubdomainTakeover(subdomains) : [];

  const scan = {
    scannedAt: new Date().toISOString(),
    target: { input: target.input, hostname: target.hostname, origin: target.origin || `https://${target.hostname}`, isLocal: target.isLocal || false },
    dns: dnsInfo,
    tls: tlsInfo,
    homepage,
    httpRedirect,
    robotsTxt,
    refs,
    wafCdn,
    javascriptFindings,
    formFindings,
    linkChecks,
    corsDeep,
    openRedirects,
    sensitivePaths,
    httpMethods,
    cacheSurface,
    apiProbe,
    sitemapData,
    depFiles,
    cookieDeepInfo,
    subdomains,
    certTransparency,
    takeoverVulnerable,
  };

  return { ...scan, analysis: analyze(scan), disclaimer: DISCLAIMER };
}

module.exports = { normalizeTarget, runScan };
