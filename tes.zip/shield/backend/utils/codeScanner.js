/**
 * Own Project Code Scanner
 * Scans code snippets for security issues
 * Only for the user's own code - no external targets
 */

const PATTERNS = [
  // Critical
  { severity: "critical", category: "Secret Exposure", pattern: /api[_-]?key\s*[:=]\s*["']([A-Za-z0-9_\-]{20,})["']/gi, title: "Hardcoded API Key", recommendation: "Pindahkan ke environment variable. Jangan commit ke git." },
  { severity: "critical", category: "Secret Exposure", pattern: /(?:access[_-]?token|auth[_-]?token|bot[_-]?token)\s*[:=]\s*["']([A-Za-z0-9_\-:.]{16,})["']/gi, title: "Hardcoded Access/Bot Token", recommendation: "Revoke token jika ini secret asli, lalu gunakan environment variable atau secret manager." },
  { severity: "critical", category: "Secret Exposure", pattern: /secret\s*[:=]\s*["']([A-Za-z0-9_\-]{10,})["']/gi, title: "Hardcoded Secret", recommendation: "Gunakan environment variable." },
  { severity: "critical", category: "Secret Exposure", pattern: /private[_-]?key\s*[:=]\s*["'][^"']{20,}["']/gi, title: "Hardcoded Private Key", recommendation: "Pindahkan ke file .env atau secret manager." },
  { severity: "critical", category: "Secret Exposure", pattern: /jwt[_-]?secret\s*[:=]\s*["'][^"']{8,}["']/gi, title: "Hardcoded JWT Secret", recommendation: "Gunakan environment variable yang panjang dan acak." },
  { severity: "critical", category: "Secret Exposure", pattern: /password\s*[:=]\s*["'][^"']{3,}["']/gi, title: "Hardcoded Password", recommendation: "Jangan hardcode password. Gunakan environment variable." },
  { severity: "critical", category: "Secret Exposure", pattern: /(sk-[A-Za-z0-9]{20,}|AIza[A-Za-z0-9]{20,})/g, title: "API Token Terekspos", recommendation: "Revoke token ini segera dan generate baru via environment variable." },
  
  // High
  { severity: "high", category: "SQL Injection", pattern: /query\s*\([^)]*\+\s*(req\.|request\.|params|body|query)/gi, title: "Possible SQL Injection (Raw Query + User Input)", recommendation: "Gunakan parameterized query atau ORM." },
  { severity: "high", category: "SQL Injection", pattern: /`SELECT .* \${/gi, title: "SQL dengan Template Literal (Injection Risk)", recommendation: "Gunakan prepared statements." },
  { severity: "high", category: "Auth Missing", pattern: /router\.(get|post|put|delete)\s*\(['"]\/(admin|dashboard|panel|manage)/gi, title: "Route Admin Tanpa Auth Terlihat", recommendation: "Pastikan semua route admin dilindungi middleware autentikasi." },
  { severity: "high", category: "Business Logic", pattern: /router\.(post|put|patch)\s*\(['"][^'"]*(withdraw|payment|transfer|payout|balance|transaction)/gi, title: "Endpoint Finansial/Transaksi Perlu Validasi Kuat", recommendation: "Pastikan endpoint memiliki auth, authorization, validasi amount, idempotency, audit log, dan anti-replay." },
  { severity: "high", category: "File Upload Risk", pattern: /upload|multer|formidable/gi, title: "File Upload Terdeteksi", recommendation: "Pastikan ada validasi tipe file, ukuran maksimal, dan scan malware." },
  { severity: "high", category: "CORS", pattern: /origin\s*[:=]\s*['"][*]['"]|cors\(\)/gi, title: "CORS Wildcard (*) Terdeteksi", recommendation: "Batasi CORS ke domain spesifik yang diperlukan." },
  
  // Medium
  { severity: "medium", category: "Information Disclosure", pattern: /console\.(error|log)\s*\([^)]*err/gi, title: "Error Detail ke Console (Info Disclosure Risk)", recommendation: "Jangan log stack trace ke client. Gunakan error logging server-side." },
  { severity: "medium", category: "Input Validation", pattern: /(req\.body\.|req\.query\.|req\.params\.)\w+(?!\s*(?:&&|\|\||===|!==|trim|slice|replace|parseInt|parseFloat|Number|String|Boolean|validate|sanitize|escape))/gi, title: "Input User Tanpa Validasi Terlihat", recommendation: "Validasi dan sanitasi semua input dari user sebelum diproses." },
  { severity: "medium", category: "Auth", pattern: /verify\s*\(.*token.*\)/gi, title: "Token Verification Terdeteksi", recommendation: "Pastikan error handling pada token verification sudah benar." },
  
  // Low
  { severity: "low", category: "Dependency", pattern: /require\(['"]eval['"]\)|eval\s*\(/gi, title: "Penggunaan eval()", recommendation: "Hindari eval(). Gunakan alternatif yang lebih aman." },
  { severity: "low", category: "Security Config", pattern: /rejectUnauthorized\s*:\s*false/gi, title: "TLS Verification Dimatikan", recommendation: "Jangan matikan rejectUnauthorized di production." },
  { severity: "low", category: "Upload Limit", pattern: /multer\(\s*\{(?![\s\S]{0,400}limits)/gi, title: "Upload Tanpa Limit Size Terlihat", recommendation: "Tambahkan limits.fileSize dan filter tipe file pada upload handler." },
  { severity: "low", category: "Debug", pattern: /debug\s*:\s*true|NODE_ENV\s*!==?\s*['"]production['"]/gi, title: "Debug Mode / Non-Production Check", recommendation: "Pastikan debug mode dimatikan di production." },
  
  // Info
  { severity: "info", category: "Best Practice", pattern: /TODO|FIXME|HACK|XXX/gi, title: "Kode Belum Selesai (TODO/FIXME)", recommendation: "Review dan selesaikan sebelum production." },
  { severity: "info", category: "Info", pattern: /http:\/\/(?!localhost|127\.0\.0\.1)/gi, title: "URL HTTP (Non-HTTPS)", recommendation: "Gunakan HTTPS untuk semua koneksi external." }
];

const fs = require("fs");
const path = require("path");

const TEXT_EXTENSIONS = new Set([
  ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".json", ".env", ".config",
  ".php", ".py", ".rb", ".go", ".java", ".cs", ".rs", ".sql", ".yml", ".yaml",
  ".html", ".css", ".md", ".txt"
]);

const SKIP_DIRS = new Set(["node_modules", ".git", "dist", "build", ".next", "coverage", "vendor"]);
const SKIP_FILES = new Set(["db.json", "package-lock.json", "yarn.lock", "pnpm-lock.yaml"]);

function redactSecrets(value) {
  return String(value || "")
    .replace(/(api[_-]?key|access[_-]?token|auth[_-]?token|bot[_-]?token|jwt[_-]?secret|secret|password|private[_-]?key)(\s*[:=]\s*)["']?[^"'\s,;]{4,}/gi, "$1$2[REDACTED]")
    .replace(/\b(sk-[a-z0-9_-]{8,}|gh[pousr]_[a-z0-9_]{8,}|xox[baprs]-[a-z0-9-]{8,}|AIza[a-z0-9_-]{8,})\b/gi, "[REDACTED_TOKEN]")
    .replace(/-----BEGIN [A-Z ]+PRIVATE KEY-----[\s\S]*?-----END [A-Z ]+PRIVATE KEY-----/g, "[REDACTED_PRIVATE_KEY]");
}

function scanCode(code, filename = "unknown") {
  if (!code || typeof code !== "string") return [];
  
  const findings = [];
  const lines = code.split("\n");
  
  for (const pattern of PATTERNS) {
    const regex = new RegExp(pattern.pattern.source, pattern.pattern.flags);
    let match;
    let matchCount = 0;
    
    while ((match = regex.exec(code)) !== null && matchCount < 5) {
      matchCount++;
      
      // Find line number
      const lineIndex = code.slice(0, match.index).split("\n").length;
      const lineContent = lines[lineIndex - 1] || "";
      
      // Skip if in comment
      const trimmed = lineContent.trim();
      if (trimmed.startsWith("//") || trimmed.startsWith("*") || trimmed.startsWith("#")) continue;
      
      findings.push({
        severity: pattern.severity,
        category: pattern.category,
        title: pattern.title,
        file: filename,
        line: lineIndex,
        evidence: redactSecrets(lineContent.trim()).slice(0, 200),
        reason: `${pattern.category}: ${pattern.title}`,
        recommendation: pattern.recommendation,
        status: "open",
        disclaimer: "Indikasi awal, wajib diverifikasi manual."
      });
      
      if (regex.lastIndex === match.index) regex.lastIndex++;
    }
  }
  
  // Deduplicate by title+line
  const seen = new Set();
  return findings.filter(f => {
    const key = `${f.title}:${f.line}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).sort((a, b) => {
    const order = { critical: 0, high: 1, medium: 2, low: 3, info: 4 };
    return order[a.severity] - order[b.severity];
  });
}

function scanDotEnvLeak(code, filename) {
  const findings = [];
  if (/\.(env|config|secrets?)$/i.test(filename)) {
    findings.push({
      severity: "critical",
      category: "File Sensitive",
      title: "File Environment/Config Terdeteksi",
      file: filename,
      line: 1,
      evidence: filename,
      recommendation: "Pastikan file ini ada di .gitignore. Jangan commit ke repository.",
      status: "open",
      disclaimer: "Indikasi awal, wajib diverifikasi manual."
    });
  }
  return findings;
}

function scanProject(rootDir, options = {}) {
  const maxFiles = Number(options.maxFiles || 80);
  const maxBytes = Number(options.maxBytes || 350000);
  const root = path.resolve(rootDir);
  const findings = [];
  const scannedFiles = [];

  function walk(dir) {
    if (scannedFiles.length >= maxFiles) return;
    let entries = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }

    for (const entry of entries) {
      if (scannedFiles.length >= maxFiles) break;
      const fullPath = path.join(dir, entry.name);
      const rel = path.relative(root, fullPath).replace(/\\/g, "/");
      if (!rel || rel.startsWith("..")) continue;
      if (entry.isDirectory()) {
        if (!SKIP_DIRS.has(entry.name)) walk(fullPath);
        continue;
      }
      if (!entry.isFile()) continue;
      if (SKIP_FILES.has(entry.name)) continue;

      const ext = path.extname(entry.name).toLowerCase();
      const isDotEnv = /^\.env($|\.)/i.test(entry.name);
      if (!TEXT_EXTENSIONS.has(ext) && !isDotEnv) continue;

      let stat;
      try { stat = fs.statSync(fullPath); } catch { continue; }
      if (stat.size > maxBytes) continue;

      let code = "";
      try { code = fs.readFileSync(fullPath, "utf8"); } catch { continue; }
      scannedFiles.push(rel);
      findings.push(...scanCode(code, rel), ...scanDotEnvLeak(code, rel));
    }
  }

  walk(root);

  return {
    root,
    scannedFiles,
    findings: findings.sort((a, b) => {
      const order = { critical: 0, high: 1, medium: 2, low: 3, info: 4 };
      return order[a.severity] - order[b.severity];
    }),
    disclaimer: "Indikasi awal, wajib diverifikasi manual. Scanner ini hanya untuk project sendiri."
  };
}

module.exports = { scanCode, scanDotEnvLeak, scanProject, redactSecrets, PATTERNS };
