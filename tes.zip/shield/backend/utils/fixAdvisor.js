/**
 * WebShield - Fix Advisor
 * Maps vulnerability categories to specific remediation steps
 * Covers all major bug classes from the vulnerability list
 */

const FIX_DATABASE = {
  // ═══════════════════════════════════════════════════════════════
  // AUTHENTICATION & SESSION
  // ═══════════════════════════════════════════════════════════════
  "authentication": {
    title: "Authentication & Session Security",
    icon: "🔐",
    fixes: [
      "Terapkan rate limiting pada endpoint login (max 5 percobaan / menit per IP/account)",
      "Gunakan bcrypt/argon2 untuk hashing password, JANGAN MD5/SHA1",
      "Set session timeout: active = 30 menit, absolute = 8 jam",
      "Regenerate session ID setelah login berhasil (session fixation prevention)",
      "Tolak password di bawah 12 karakter, wajibkan uppercase+lowercase+angka+simbol",
      "Tambahkan CAPTCHA setelah 3x gagal login",
      "Log semua failed login attempt beserta IP dan timestamp",
      "Implementasikan account lockout: 10x gagal → kunci 15 menit"
    ]
  },
  "mfa": {
    title: "Multi-Factor Authentication",
    icon: "📱",
    fixes: [
      "Wajibkan MFA untuk akun admin/privileged",
      "Gunakan TOTP (Google Authenticator) atau hardware key (FIDO2/WebAuthn)",
      "OTP harus expired dalam 5 menit dan single-use (invalidate setelah dipakai)",
      "Backup codes harus di-hash saat disimpan, satu kali pakai, dan bisa direvoke",
      "Jangan kirim OTP via SMS saja — tambahkan TOTP app sebagai opsi lebih aman",
      "Jika MFA bypass via recovery flow, wajibkan verifikasi email + konfirmasi manual"
    ]
  },
  "password_reset": {
    title: "Password Reset Flow",
    icon: "🔑",
    fixes: [
      "Token reset harus cryptographically random (min 32 byte), JANGAN timestamp/ID user",
      "Token expired maksimal 15 menit setelah dikirim",
      "Token single-use: langsung invalidate setelah dipakai atau expired",
      "Kirim notifikasi ke email lama ketika password berhasil direset",
      "Jangan bocorkan apakah email terdaftar atau tidak (gunakan response yang sama)",
      "Rate limit endpoint /forgot-password: max 3 request/jam per IP/email"
    ]
  },
  "jwt": {
    title: "JWT Configuration",
    icon: "🎫",
    fixes: [
      "Gunakan algoritma RS256 atau ES256, BUKAN HS256 dengan secret lemah",
      "Set expiry (exp) maksimal 1 jam untuk access token",
      "Gunakan refresh token rotation: tiap pakai refresh token, buat yang baru dan invalidate yang lama",
      "Validasi semua claim: iss, aud, exp, nbf",
      "Simpan JWT di httpOnly cookie, BUKAN localStorage (mencegah XSS theft)",
      "Implementasikan token blacklist/revocation untuk logout",
      "Tolak JWT dengan alg: none"
    ]
  },
  "oauth": {
    title: "OAuth & SSO Configuration",
    icon: "🔗",
    fixes: [
      "Validasi state parameter untuk mencegah CSRF pada OAuth flow",
      "Whitelist redirect_uri secara eksak, JANGAN wildcard atau open redirect",
      "Gunakan PKCE (Proof Key for Code Exchange) untuk public clients",
      "Set scope seminimal mungkin sesuai kebutuhan",
      "Validasi id_token dari IdP sebelum membuat session",
      "Jangan simpan client_secret di frontend/mobile app"
    ]
  },

  // ═══════════════════════════════════════════════════════════════
  // AUTHORIZATION & ACCESS CONTROL
  // ═══════════════════════════════════════════════════════════════
  "access_control": {
    title: "Broken Access Control",
    icon: "🚪",
    fixes: [
      "Terapkan server-side authorization check di SETIAP endpoint, jangan percaya role dari client",
      "Gunakan principle of least privilege: setiap user hanya bisa akses resource miliknya",
      "Deny by default: kalau role tidak terdaftar → tolak akses",
      "Audit semua endpoint dengan pertanyaan: 'Apakah user A bisa akses data user B?'",
      "Jangan expose internal admin endpoint ke internet tanpa IP whitelist",
      "Log semua access denied event untuk monitoring"
    ]
  },
  "idor": {
    title: "IDOR - Insecure Direct Object Reference",
    icon: "🔢",
    fixes: [
      "Ganti sequential ID (1,2,3) dengan UUID/ULID yang tidak bisa ditebak",
      "SELALU validasi di backend: apakah resource yang diminta milik user yang sedang login?",
      "Contoh check: `if (invoice.userId !== req.user.id) return 403;`",
      "Terapkan resource-based authorization, bukan hanya role-based",
      "Untuk indirect references, gunakan mapping tabel internal (user hanya tahu alias, bukan ID asli)",
      "Audit semua parameter yang menerima ID: /api/orders/{id}, /download?file=, dll"
    ]
  },
  "privilege_escalation": {
    title: "Privilege Escalation",
    icon: "⬆️",
    fixes: [
      "Jangan percaya field 'role' atau 'isAdmin' dari request body — ambil dari database/session",
      "Mass assignment protection: whitelist field yang boleh diupdate, JANGAN pakai spread operator sembarangan",
      "Validasi perubahan role hanya bisa dilakukan oleh super admin yang terautentikasi",
      "Audit endpoint profile update: pastikan user tidak bisa set field role/permission sendiri",
      "Test: kirim {'role': 'admin'} saat update profil — apakah diterima?"
    ]
  },

  // ═══════════════════════════════════════════════════════════════
  // INJECTION VULNERABILITIES
  // ═══════════════════════════════════════════════════════════════
  "sql_injection": {
    title: "SQL Injection Prevention",
    icon: "💉",
    fixes: [
      "WAJIB gunakan parameterized queries / prepared statements, JANGAN string concatenation",
      "Contoh BENAR (Node.js): `db.query('SELECT * FROM users WHERE id = ?', [userId])`",
      "Contoh SALAH: `db.query('SELECT * FROM users WHERE id = ' + userId)`",
      "Gunakan ORM (Sequelize, Prisma, Hibernate) yang otomatis escape input",
      "Principle of least privilege untuk DB user: read-only untuk query SELECT, jangan pakai root",
      "Disable verbose SQL error di production — jangan tampilkan stack trace ke user",
      "Input validation: tolak karakter ; -- ' \" pada field yang tidak butuh karakter tersebut"
    ]
  },
  "xss": {
    title: "Cross-Site Scripting (XSS) Prevention",
    icon: "⚡",
    fixes: [
      "Output encoding: encode semua user input sebelum ditampilkan di HTML",
      "Gunakan framework yang auto-escape: React (JSX), Angular, Vue (template) — jangan pakai innerHTML/dangerouslySetInnerHTML",
      "Implementasikan Content Security Policy (CSP) yang strict",
      "CSP header contoh: `Content-Security-Policy: default-src 'self'; script-src 'self' 'nonce-{random}'`",
      "Validasi input di backend: strip atau reject tag HTML di field yang tidak butuh HTML",
      "Set cookie dengan flag HttpOnly agar tidak bisa diakses via JavaScript",
      "Gunakan sanitizer library: DOMPurify untuk client-side jika butuh render HTML"
    ]
  },
  "csrf": {
    title: "CSRF Prevention",
    icon: "🔄",
    fixes: [
      "Implementasikan CSRF token: random per session, validasi di server untuk setiap state-changing request",
      "Set cookie SameSite=Strict atau SameSite=Lax untuk session cookie",
      "Validasi Origin dan Referer header untuk request penting",
      "Gunakan custom request header (e.g., X-Requested-With: XMLHttpRequest) yang tidak bisa dikirim cross-site",
      "Double submit cookie pattern sebagai alternatif jika stateless",
      "Framework yang sudah built-in CSRF protection: Laravel, Django, Rails — aktifkan dan jangan disable"
    ]
  },
  "ssrf": {
    title: "Server-Side Request Forgery (SSRF) Prevention",
    icon: "🌐",
    fixes: [
      "Whitelist domain/IP yang boleh di-fetch — JANGAN fetch URL dari input user sembarangan",
      "Block request ke internal IP: 127.0.0.1, 10.x.x.x, 172.16-31.x.x, 192.168.x.x, 169.254.x.x",
      "Block akses ke cloud metadata endpoint: 169.254.169.254 (AWS/GCP/Azure)",
      "Resolve hostname ke IP dulu, lalu validasi IP-nya sebelum fetch",
      "Gunakan allowlist scheme: hanya izinkan http/https, blok file://, dict://, gopher://",
      "Untuk fitur fetch URL (webhook, preview): gunakan DNS rebinding protection"
    ]
  },
  "command_injection": {
    title: "Command Injection Prevention",
    icon: "💻",
    fixes: [
      "JANGAN pernah gunakan shell: true atau exec() dengan input user",
      "Jika butuh jalankan command: gunakan execFile() dengan array args, bukan string",
      "Whitelist input yang dipakai sebagai argument: hanya alfanumerik jika memungkinkan",
      "Gunakan library/API native daripada shell command (mis: child_process.execFile vs exec)",
      "Escape semua karakter khusus jika terpaksa: ; | & $ ` \\ ! { }",
      "Jalankan web server dengan user non-root, terapkan principle of least privilege"
    ]
  },
  "ssti": {
    title: "Server-Side Template Injection (SSTI)",
    icon: "📝",
    fixes: [
      "JANGAN render template dari input user secara langsung",
      "Pisahkan template dari data: template harus static, data di-inject via context/variable",
      "Contoh SALAH (Jinja2): `render_template_string(user_input)`",
      "Contoh BENAR: `render_template('email.html', name=user_input)`",
      "Gunakan sandboxed template engine jika butuh dynamic template",
      "Audit semua tempat yang merender string dari database atau user input sebagai template"
    ]
  },
  "xxe": {
    title: "XML External Entity (XXE) Prevention",
    icon: "📄",
    fixes: [
      "Disable external entity processing di XML parser",
      "Java (DocumentBuilderFactory): `factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true)`",
      "PHP (libxml): `libxml_disable_entity_loader(true)`",
      "Python (lxml): gunakan `resolve_entities=False`",
      "Ganti XML dengan JSON jika tidak ada kebutuhan khusus XML",
      "Validasi Content-Type: tolak application/xml dari input yang tidak diharapkan"
    ]
  },

  // ═══════════════════════════════════════════════════════════════
  // SENSITIVE DATA EXPOSURE
  // ═══════════════════════════════════════════════════════════════
  "sensitive_exposure": {
    title: "Sensitive Data Exposure",
    icon: "🔓",
    fixes: [
      "Hapus segera: .env, .git/, backup files, .sql dumps dari public web root",
      "Tambahkan ke .gitignore: .env, *.key, *.pem, config/database.yml, *.log",
      "Pasang rule di web server untuk block akses ke file sensitif",
      "Nginx: `location ~ /\\.(env|git|htaccess|svn) { deny all; }`",
      "Disable directory listing: `Options -Indexes` (Apache) atau `autoindex off` (Nginx)",
      "Scan project secara rutin dengan: `git log --all --full-history -- '**/.env'`",
      "Rotasi semua credential yang sudah pernah ter-expose ke public"
    ]
  },
  "security_headers": {
    title: "Security Headers",
    icon: "🛡️",
    fixes: [
      "Strict-Transport-Security: `max-age=31536000; includeSubDomains; preload`",
      "X-Frame-Options: `DENY` atau `SAMEORIGIN` (mencegah clickjacking)",
      "X-Content-Type-Options: `nosniff` (mencegah MIME sniffing)",
      "Content-Security-Policy: minimal `default-src 'self'`",
      "Referrer-Policy: `strict-origin-when-cross-origin`",
      "Permissions-Policy: disable fitur tidak dipakai: `camera=(), microphone=(), geolocation=()`",
      "Hapus header yang bocorkan info server: X-Powered-By, Server version"
    ]
  },
  "cors": {
    title: "CORS Misconfiguration",
    icon: "🌍",
    fixes: [
      "JANGAN set Access-Control-Allow-Origin: * untuk endpoint yang butuh auth",
      "Whitelist origin secara eksak: `const allowed = ['https://yourdomain.com']`",
      "Jangan mirror Origin header sembarangan tanpa validasi",
      "Access-Control-Allow-Credentials: true hanya boleh berpasangan dengan origin spesifik, BUKAN *",
      "Batasi method: `Access-Control-Allow-Methods: GET, POST`",
      "Audit: apakah API endpoint penting punya CORS yang terlalu longgar?"
    ]
  },
  "tls": {
    title: "TLS/SSL Configuration",
    icon: "🔒",
    fixes: [
      "Disable TLS 1.0 dan TLS 1.1, gunakan TLS 1.2 minimum (TLS 1.3 recommended)",
      "Pastikan sertifikat tidak expired: setup auto-renewal dengan Let's Encrypt/certbot",
      "Implementasikan HSTS agar browser selalu pakai HTTPS",
      "Perbarui sertifikat sebelum < 30 hari sebelum expired",
      "Aktifkan OCSP stapling untuk validasi revocation yang lebih cepat",
      "Gunakan strong cipher: TLS_AES_128_GCM_SHA256, TLS_AES_256_GCM_SHA384"
    ]
  },
  "dns": {
    title: "DNS & Email Security",
    icon: "🌐",
    fixes: [
      "Tambahkan SPF record: `v=spf1 include:_spf.google.com ~all` (sesuaikan dengan mail provider)",
      "Tambahkan DMARC record: `v=DMARC1; p=quarantine; rua=mailto:dmarc@yourdomain.com`",
      "Aktifkan DKIM di mail server untuk signing email",
      "Tambahkan CAA record untuk membatasi CA yang boleh issue sertifikat: `0 issue letsencrypt.org`",
      "Audit subdomain: hapus atau arahkan subdomain yang tidak dipakai (mencegah subdomain takeover)",
      "Monitor DNS record perubahan secara rutin"
    ]
  },

  // ═══════════════════════════════════════════════════════════════
  // INFRASTRUCTURE & CLOUD
  // ═══════════════════════════════════════════════════════════════
  "cloud_storage": {
    title: "Cloud Storage (S3/GCS/Azure Blob)",
    icon: "☁️",
    fixes: [
      "Set bucket ACL ke private: jangan pakai public-read kecuali memang untuk file publik",
      "Enable Block Public Access di AWS S3 bucket settings",
      "Gunakan presigned URLs untuk berbagi file sementara, jangan buka bucket secara publik",
      "Aktifkan versioning dan MFA delete untuk bucket penting",
      "Audit IAM policy: prinsip least privilege untuk akses S3",
      "Enable S3 access logging untuk audit trail",
      "Scan bucket isi secara berkala: apakah ada file sensitif yang ter-upload?"
    ]
  },
  "api_security": {
    title: "API Security",
    icon: "🔌",
    fixes: [
      "Implementasikan authentication di SEMUA endpoint API, kecuali yang memang publik",
      "Rate limiting per endpoint: gunakan token bucket atau sliding window",
      "Disable GraphQL introspection di production: `introspection: process.env.NODE_ENV !== 'production'`",
      "Validasi dan sanitasi semua input: type, length, format, range",
      "Return error generic, jangan bocorkan stack trace atau SQL error",
      "Implementasikan API versioning dan deprecate endpoint lama",
      "Monitor traffic API: alert bila ada lonjakan request yang tidak normal"
    ]
  },
  "subdomain": {
    title: "Subdomain Takeover Prevention",
    icon: "🏴",
    fixes: [
      "Audit semua DNS CNAME record yang mengarah ke layanan pihak ketiga (Heroku, GitHub Pages, dll)",
      "Jika subdomain tidak dipakai, hapus DNS record-nya",
      "Cek apakah layanan yang di-CNAME masih aktif: jika sudah dihapus/expired → rentan takeover",
      "Gunakan monitoring DNS untuk detect perubahan atau dangling record",
      "Sebelum hapus resource di provider (Heroku app, etc): update/hapus DNS dulu",
      "Tools audit: subjack, can-i-take-over-xyz"
    ]
  },
  "path_traversal": {
    title: "Path Traversal & LFI Prevention",
    icon: "📂",
    fixes: [
      "Jangan gunakan input user sebagai file path secara langsung",
      "Canonicalize path dan validasi: `path.resolve(baseDir, filename).startsWith(baseDir)`",
      "Whitelist nama file yang diizinkan: hanya alfanumerik + ekstensi yang dibolehkan",
      "Disable PHP allow_url_include dan allow_url_fopen jika tidak dibutuhkan",
      "Jalankan aplikasi dalam chroot/container untuk membatasi akses filesystem",
      "Audit semua parameter file: ?file=, ?path=, ?include=, ?page="
    ]
  },
  "file_upload": {
    title: "File Upload Security",
    icon: "📁",
    fixes: [
      "Validasi file di server-side: cek magic bytes / content, bukan hanya ekstensi",
      "Whitelist ekstensi yang diizinkan: jpg, png, pdf, dll — tolak .php, .js, .html, .svg",
      "Simpan uploaded file di luar web root, jangan bisa diakses langsung via URL",
      "Rename file saat upload: jangan pakai nama asli dari user",
      "Scan virus/malware pada uploaded file sebelum disimpan",
      "Set Content-Disposition: attachment untuk file yang di-download agar tidak dieksekusi browser",
      "Batasi ukuran file: implementasikan limit di web server dan aplikasi"
    ]
  },

  // ═══════════════════════════════════════════════════════════════
  // BUSINESS LOGIC
  // ═══════════════════════════════════════════════════════════════
  "business_logic": {
    title: "Business Logic Security",
    icon: "🧩",
    fixes: [
      "Validasi semua kalkulasi harga/amount di server-side, JANGAN percaya nilai dari client",
      "Implementasikan idempotency key untuk transaksi finansial (mencegah race condition)",
      "Gunakan database transaction + row locking untuk operasi yang concurrent-sensitive",
      "Audit semua promo/kupon flow: pastikan tidak bisa dipakai berulang atau di-stack melebihi batas",
      "Validasi negative amount: tolak nilai negatif untuk payment/transfer",
      "Log semua transaksi dengan detail lengkap untuk audit trail",
      "Terapkan business rule di backend, jangan hanya di frontend"
    ]
  },
  "race_condition": {
    title: "Race Condition Prevention",
    icon: "⚡",
    fixes: [
      "Gunakan database-level locking: SELECT FOR UPDATE sebelum operasi kritis",
      "Implementasikan idempotency: cek apakah operasi sudah pernah dilakukan sebelum eksekusi",
      "Gunakan atomic operations di database: UPDATE balance SET amount = amount - ? WHERE amount >= ?",
      "Redis distributed lock untuk operasi yang tidak bisa di-lock di DB",
      "Terapkan rate limiting per user per endpoint untuk membatasi concurrent request",
      "Test dengan concurrent requests: kirim 10 request simultan dan cek hasilnya"
    ]
  },

  // ═══════════════════════════════════════════════════════════════
  // COOKIES & CLIENT-SIDE
  // ═══════════════════════════════════════════════════════════════
  "cookies": {
    title: "Cookie Security",
    icon: "🍪",
    fixes: [
      "Set flag Secure: cookie hanya dikirim via HTTPS",
      "Set flag HttpOnly: mencegah JavaScript membaca cookie (mitigasi XSS theft)",
      "Set SameSite=Strict atau Lax: mencegah CSRF",
      "Contoh: `Set-Cookie: session=xxx; Secure; HttpOnly; SameSite=Strict; Path=/`",
      "Set Path dan Domain seminimal mungkin",
      "Set Expires/Max-Age yang reasonable: jangan buat session cookie yang abadi",
      "Rotasi session ID setelah login dan setelah privilege change"
    ]
  },
  "csp": {
    title: "Content Security Policy (CSP)",
    icon: "🛡️",
    fixes: [
      "Mulai dengan CSP report-only mode dulu: `Content-Security-Policy-Report-Only: default-src 'self'`",
      "Gunakan nonce untuk inline scripts yang dibutuhkan: `script-src 'nonce-{random}'`",
      "Hindari 'unsafe-inline' dan 'unsafe-eval' di script-src",
      "Minimal CSP: `default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'`",
      "CSP ketat: `default-src 'none'; script-src 'self' 'nonce-xxx'; style-src 'self'; img-src 'self'`",
      "Tambahkan report-uri untuk memonitor pelanggaran CSP di production"
    ]
  },
  "clickjacking": {
    title: "Clickjacking Prevention",
    icon: "🖱️",
    fixes: [
      "Set X-Frame-Options: DENY (halaman tidak boleh sama sekali di-iframe)",
      "Atau X-Frame-Options: SAMEORIGIN (hanya boleh di-iframe oleh domain yang sama)",
      "CSP frame-ancestors adalah cara modern yang lebih fleksibel: `Content-Security-Policy: frame-ancestors 'self'`",
      "Terapkan di semua halaman yang ada aksi sensitif: payment, delete, form penting",
      "Jangan set X-Frame-Options: ALLOW-FROM (deprecated, tidak didukung Chrome)"
    ]
  },
  "open_redirect": {
    title: "Open Redirect Prevention",
    icon: "↪️",
    fixes: [
      "JANGAN redirect ke URL dari parameter input langsung",
      "Whitelist URL yang boleh dijadikan redirect destination",
      "Untuk internal redirect: gunakan path saja (bukan full URL): `?next=/dashboard`",
      "Validasi: pastikan URL redirect masih di domain yang sama sebelum redirect",
      "Gunakan mapping: `?action=dashboard` → redirect ke /dashboard (bukan URL langsung)",
      "Cek semua parameter: ?redirect=, ?next=, ?url=, ?return=, ?goto="
    ]
  },

  // ═══════════════════════════════════════════════════════════════
  // INFORMATION DISCLOSURE
  // ═══════════════════════════════════════════════════════════════
  "error_disclosure": {
    title: "Error & Stack Trace Disclosure",
    icon: "🚨",
    fixes: [
      "Set environment ke production: `NODE_ENV=production`, `APP_DEBUG=false`",
      "Tampilkan error message generic ke user: 'Something went wrong', bukan stack trace",
      "Log error detail ke server/monitoring (Sentry, Datadog) — BUKAN ke user",
      "Matikan PHP error display: `display_errors = Off`, `log_errors = On`",
      "Handle semua unhandled exception di top-level handler",
      "Jangan expose path sistem di error: `/var/www/html/app/models/User.php:45`",
      "Audit response 4xx/5xx: apakah ada info sensitif yang bocor?"
    ]
  },
  "version_disclosure": {
    title: "Version & Technology Disclosure",
    icon: "ℹ️",
    fixes: [
      "Hapus header X-Powered-By (Express: `app.disable('x-powered-by')`, PHP: `expose_php = Off`)",
      "Customize Server header di web server: `server_tokens off` (Nginx), `ServerTokens Prod` (Apache)",
      "Hapus version dari URL/meta tag framework (WordPress versi, jQuery versi di public)",
      "Jaga framework dan library tetap update untuk patch security vulnerability",
      "Sembunyikan admin path yang khas framework: /wp-admin, /phpmyadmin ganti path-nya"
    ]
  },
  "exposed_endpoints": {
    title: "Exposed Admin & Debug Endpoints",
    icon: "🚪",
    fixes: [
      "Disable debug endpoints di production: /debug, /console, /.well-known/*, /status, /actuator",
      "IP whitelist untuk admin panel: hanya izinkan akses dari IP kantor/VPN",
      "Hapus atau disable phpMyAdmin, Adminer jika sudah tidak dipakai",
      "Jenkins, GitLab, Kibana: pastikan tidak terekspos ke internet tanpa auth",
      "Disable Swagger/OpenAPI UI di production, atau password-protect",
      "Audit dengan Google Dork: `site:yourdomain.com inurl:admin`"
    ]
  }
};

/**
 * Get fix recommendations for a finding based on its category and title
 */
function getFixRecommendations(finding) {
  const text = `${finding.title || ""} ${finding.category || ""} ${finding.evidence || ""}`.toLowerCase();

  const categoryMap = [
    { keys: ["sql", "sqli", "injection"], cat: "sql_injection" },
    { keys: ["xss", "cross-site scripting", "script injection"], cat: "xss" },
    { keys: ["csrf", "cross-site request forgery"], cat: "csrf" },
    { keys: ["ssrf", "server-side request forgery"], cat: "ssrf" },
    { keys: ["ssti", "template injection"], cat: "ssti" },
    { keys: ["xxe", "xml external entity"], cat: "xxe" },
    { keys: ["command injection", "rce", "remote code execution"], cat: "command_injection" },
    { keys: ["idor", "direct object reference", "bola", "bfla"], cat: "idor" },
    { keys: ["access control", "privilege escalation", "mass assignment"], cat: "access_control" },
    { keys: ["privilege", "role", "escalation"], cat: "privilege_escalation" },
    { keys: ["jwt", "token", "bearer"], cat: "jwt" },
    { keys: ["oauth", "saml", "sso", "federation"], cat: "oauth" },
    { keys: ["mfa", "otp", "2fa", "totp", "backup code"], cat: "mfa" },
    { keys: ["password reset", "forgot password", "reset token"], cat: "password_reset" },
    { keys: ["login", "authentication", "session fixation", "session hijack", "brute force"], cat: "authentication" },
    { keys: ["cors", "access-control-allow-origin"], cat: "cors" },
    { keys: ["csp", "content security policy"], cat: "csp" },
    { keys: ["csrf"], cat: "csrf" },
    { keys: ["clickjacking", "x-frame", "iframe"], cat: "clickjacking" },
    { keys: ["open redirect", "redirect"], cat: "open_redirect" },
    { keys: ["cookie", "samesite", "httponly", "secure flag"], cat: "cookies" },
    { keys: ["tls", "ssl", "https", "certificate", "hsts"], cat: "tls" },
    { keys: ["dns", "spf", "dmarc", "dkim", "caa", "mail"], cat: "dns" },
    { keys: ["subdomain", "dangling", "cname"], cat: "subdomain" },
    { keys: ["s3", "firebase", "cloud storage", "bucket"], cat: "cloud_storage" },
    { keys: ["api", "graphql", "introspection", "endpoint"], cat: "api_security" },
    { keys: ["security header", "hsts", "x-content", "x-frame", "referrer-policy", "permissions-policy"], cat: "security_headers" },
    { keys: ["path traversal", "lfi", "rfi", "directory traversal", "local file"], cat: "path_traversal" },
    { keys: ["file upload", "arbitrary file"], cat: "file_upload" },
    { keys: ["env", ".git", "backup", "config", "sensitive file", "leak"], cat: "sensitive_exposure" },
    { keys: ["error", "stack trace", "verbose", "debug", "exception"], cat: "error_disclosure" },
    { keys: ["x-powered-by", "server", "version disclosure", "framework"], cat: "version_disclosure" },
    { keys: ["admin", "panel", "phpmy", "jenkins", "swagger", "openapi", "exposed"], cat: "exposed_endpoints" },
    { keys: ["race condition", "concurrent", "double spend"], cat: "race_condition" },
    { keys: ["business logic", "payment", "price", "coupon", "refund", "wallet"], cat: "business_logic" },
  ];

  for (const { keys, cat } of categoryMap) {
    if (keys.some(k => text.includes(k))) {
      return FIX_DATABASE[cat] || null;
    }
  }
  return null;
}

/**
 * Get all fix categories for the Fix Guide page
 */
function getAllCategories() {
  return Object.entries(FIX_DATABASE).map(([key, val]) => ({
    key,
    title: val.title,
    icon: val.icon,
    fixCount: val.fixes.length
  }));
}

function getCategoryFix(categoryKey) {
  return FIX_DATABASE[categoryKey] || null;
}

module.exports = { getFixRecommendations, getAllCategories, getCategoryFix, FIX_DATABASE };
