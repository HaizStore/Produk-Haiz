/**
 * WebShield - Data Store
 * Schema: my_domains, scans, findings, fix_history, audit_logs, settings
 */
const fs   = require("fs");
const path = require("path");

const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, "db.json");

const DEFAULT_DB = {
  my_domains:    [],
  scans:         [],
  findings:      [],
  fix_history:   [],
  audit_logs:    [],
  settings:      { ai_provider: "openai", ai_model: "gpt-4o-mini" }
};

let _db = null;

function load() {
  if (_db) return _db;
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, "utf8");
      _db = { ...DEFAULT_DB, ...JSON.parse(raw) };
    } else {
      _db = JSON.parse(JSON.stringify(DEFAULT_DB));
      save();
    }
  } catch {
    _db = JSON.parse(JSON.stringify(DEFAULT_DB));
  }
  return _db;
}

function save() {
  try {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(DATA_FILE, JSON.stringify(_db, null, 2), "utf8");
  } catch (e) { console.error("DB save error:", e.message); }
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function getDb()                    { return load(); }
function listCollection(name)       { return load()[name] || []; }
function getById(name, id)          { return (load()[name] || []).find(i => i.id === id) || null; }

function insertItem(name, item) {
  const db = load();
  if (!db[name]) db[name] = [];
  const newItem = { ...item, id: uid(), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
  db[name].push(newItem);
  save();
  return newItem;
}

function updateItem(name, id, patch) {
  const db = load();
  const idx = (db[name] || []).findIndex(i => i.id === id);
  if (idx === -1) return null;
  db[name][idx] = { ...db[name][idx], ...patch, updatedAt: new Date().toISOString() };
  save();
  return db[name][idx];
}

function deleteItem(name, id) {
  const db = load();
  const before = (db[name] || []).length;
  db[name] = (db[name] || []).filter(i => i.id !== id);
  save();
  return db[name].length < before;
}

function addAuditLog(action, detail) {
  const db = load();
  if (!db.audit_logs) db.audit_logs = [];
  db.audit_logs.unshift({ id: uid(), action, detail, timestamp: new Date().toISOString() });
  if (db.audit_logs.length > 500) db.audit_logs = db.audit_logs.slice(0, 500);
  save();
}

module.exports = { getDb, save, listCollection, getById, insertItem, updateItem, deleteItem, addAuditLog, uid };
