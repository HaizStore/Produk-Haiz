/**
 * Middleware utilities for rate limiting, validation, CORS
 */

// Simple in-memory rate limiter
const rateLimitStore = new Map();

function getClientIp(req) {
  const forwarded = req.headers["x-forwarded-for"];
  if (forwarded) return forwarded.split(",")[0].trim();
  return req.socket?.remoteAddress || "unknown";
}

function rateLimit(maxPerMinute, keyFn = (req) => getClientIp(req)) {
  return function (req, res, next) {
    const key = keyFn(req);
    const now = Date.now();
    const windowMs = 60 * 1000;

    const entry = rateLimitStore.get(key) || { count: 0, resetAt: now + windowMs };

    if (now > entry.resetAt) {
      entry.count = 0;
      entry.resetAt = now + windowMs;
    }

    entry.count++;
    rateLimitStore.set(key, entry);

    res.setHeader("X-RateLimit-Limit", maxPerMinute);
    res.setHeader("X-RateLimit-Remaining", Math.max(0, maxPerMinute - entry.count));
    res.setHeader("X-RateLimit-Reset", Math.ceil(entry.resetAt / 1000));

    if (entry.count > maxPerMinute) {
      res.writeHead(429, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ error: "Terlalu banyak request. Coba lagi dalam 1 menit." }));
      return;
    }

    next();
  };
}

function validateBody(required = []) {
  return function (req, res, body, next) {
    let parsed;
    try {
      parsed = JSON.parse(body || "{}");
    } catch {
      res.writeHead(400, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ error: "Request body harus JSON valid." }));
      return;
    }

    for (const field of required) {
      if (!parsed[field] && parsed[field] !== 0) {
        res.writeHead(400, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: `Field '${field}' wajib diisi.` }));
        return;
      }
    }

    req.body = parsed;
    next();
  };
}

function sanitizeString(str, maxLen = 2000) {
  if (typeof str !== "string") return "";
  return str.trim().slice(0, maxLen).replace(/[<>]/g, "");
}

function addSecurityHeaders(res) {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Cache-Control", "no-store");
}

module.exports = { rateLimit, validateBody, sanitizeString, addSecurityHeaders };
