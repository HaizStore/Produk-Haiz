# 🛡️ WebShield — Security Scanner for Website Owners

Scan domain kamu sendiri → Temukan celah keamanan spesifik → Dapatkan panduan fix yang actionable.

**Bukan untuk bug bounty hunting. Untuk melindungi website Anda.**

## Cara Pakai

### 1. Setup Backend
```bash
cd backend
cp .env.example .env
# Edit .env: isi AI_PROVIDER dan API key yang sesuai
node server.js
```

### 2. Setup Frontend
```bash
cd frontend
node serve.js
```

### 3. Buka Browser
Buka http://localhost:3000

---

## Flow Penggunaan

1. **My Domains** — Daftarkan domain website Anda (contoh: example.com)
2. **Scan Domain** — Pilih domain → klik Scan
3. **Vulnerabilities** — Lihat semua celah yang ditemukan dengan panduan fix
4. **Fix Guide** — Panduan perbaikan per kategori kerentanan
5. **AI Advisor** — Tanya AI tentang cara memperbaiki celah spesifik
6. **Code Scanner** — Paste kode website Anda untuk dicek

---

## AI Provider yang Didukung

| Provider   | API Key Env             | Model Default            |
|------------|-------------------------|--------------------------|
| OpenAI     | OPENAI_API_KEY          | gpt-4o-mini              |
| Anthropic  | ANTHROPIC_API_KEY       | claude-sonnet-4-20250514 |
| Gemini     | GEMINI_API_KEY          | gemini-1.5-flash         |
| Groq       | GROQ_API_KEY            | llama-3.1-70b-versatile  |
| OpenRouter | OPENROUTER_API_KEY      | anthropic/claude-3.5-sonnet |
| Local      | LOCAL_AI_BASE_URL       | local-model              |

---

## Kategori Kerentanan Yang Dicek

**Passive Scan (otomatis):**
- DNS & Email Security (SPF, DMARC, DKIM, CAA)
- TLS/SSL Configuration & Certificate
- Security Headers (HSTS, CSP, X-Frame, dll)
- CORS Misconfiguration
- Cookie Security (HttpOnly, Secure, SameSite)
- Sensitive Path Exposure (.env, .git, /admin, dll)
- JavaScript Analysis (hardcoded secrets, API endpoints)
- Version Disclosure (X-Powered-By, Server header)
- Open Redirect Detection
- Form & Input Analysis

**Fix Guide (panduan perbaikan untuk semua jenis serangan dari list):**
ATO, Auth Bypass, IDOR, SQLi, XSS, CSRF, SSRF, RCE, LFI, Path Traversal,
File Upload, JWT/OAuth/SAML, Session, CORS, CSP, Clickjacking, Open Redirect,
Subdomain Takeover, Cloud Storage, API Security, Business Logic, Race Condition,
dan ratusan lainnya sesuai daftar lengkap.
